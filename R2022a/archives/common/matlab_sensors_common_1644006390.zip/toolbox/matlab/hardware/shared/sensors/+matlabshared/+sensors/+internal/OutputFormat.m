
%   Copyright 2019-2020 The MathWorks, Inc.

classdef OutputFormat
    enumeration
        timetable,matrix
    end
end