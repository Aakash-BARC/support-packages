classdef SensorInterfaceEnum
    
    % Copyright 2020 The MathWorks, Inc.
    enumeration
        I2C, Serial
    end
end