
%   Copyright 2019-2020 The MathWorks, Inc.

classdef ReadMode
    enumeration
        latest,oldest
    end
end