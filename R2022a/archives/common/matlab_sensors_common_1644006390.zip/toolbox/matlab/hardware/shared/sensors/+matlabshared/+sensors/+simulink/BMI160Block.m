classdef BMI160Block < matlabshared.sensors.simulink.internal.SensorBlockBase...
        & matlabshared.sensors.simulink.internal.I2CSensorBase
    %Simulink Block class for BMI160 .
    %<a href="https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bmi160-ds000.pdf">Device Datasheet</a>
    %Copyright 2021 The MathWorks, Inc.

    %#codegen
    properties(Nontunable)
        I2CModule = ''
        I2CAddress = '0x69'
        MagnetometerI2CAddress
        AccelerationRange = '+/- 2g'
        AccelerometerODR = '12.5 Hz'
        GyroscopeRange = '125 dps'
        GyroscopeODR = '25 Hz'
        MagnetometerODR = '25 Hz'
        AccelerometerFilterMode = 'Normal'
        GyroscopeFilterMode = 'Normal'
        InterruptPin = 'INT1'
        DataType = 'single'
    end

    properties(Nontunable, Access = protected)
        I2CBus
    end

    properties(Access = protected)
        PeripheralType = 'I2C'
    end

    properties(Dependent, Access = protected)
        ActiveSensorModuleNum
    end

    properties(Hidden, Constant)
        I2CAddressSet = matlab.system.StringSet({'0x68','0x69'});
        MagnetometerI2CAddressSet = matlab.system.StringSet({'0x10','0x11','0x12','0x13'});
        AccelerationRangeSet = matlab.system.StringSet({'+/- 2g', '+/- 4g', '+/- 8g', '+/- 16g'});
        AccelerometerODRSet = matlab.system.StringSet({'12.5 Hz','25 Hz','50 Hz','100 Hz','200 Hz','400 Hz','800 Hz','1600 Hz'});
        GyroscopeODRSet = matlab.system.StringSet({'25 Hz','50 Hz','100 Hz','200 Hz','400 Hz','800 Hz','1600 Hz','3200 Hz'});
        GyroscopeRangeSet = matlab.system.StringSet({'125 dps','250 dps','500 dps','1000 dps','2000 dps'});
        MagnetometerODRSet = matlab.system.StringSet({'0.78125 Hz','1.5625 Hz','3.125 Hz','6.25 Hz','12.5 Hz','25 Hz','50 Hz','100 Hz','200 Hz','400 Hz','800 Hz'});
        AccelerometerFilterModeSet = matlab.system.StringSet({'Normal','OSR2','OSR4'});
        GyroscopeFilterModeSet=matlab.system.StringSet({'Normal','OSR2','OSR4'});
        InterruptPinSet = matlab.system.StringSet({'INT1','INT2'});
        DataTypeSet = matlab.system.StringSet({'single','double'});
    end

    properties(Nontunable)
        IsActiveGyro (1, 1) logical = true;
        IsActiveAccel (1, 1) logical = true;
        IsActiveMag (1, 1) logical = true;
        IsActiveTemperature (1, 1) logical = false;
        IsAccelStatus (1, 1) logical = false;
        IsGyroStatus (1, 1) logical = false;
        IsMagStatus (1, 1) logical = false;
        IsEnableAccelLowPassFilter (1, 1) logical = false;
        IsEnableGyroLowPassFilter (1, 1) logical = false;
        IsActiveInterrupt (1, 1) logical = false;
        EnableSecondaryMag (1, 1) logical = true;
    end

    methods(Access = protected)
        function out = getActiveOutputsImpl(obj)
            out = cell(1,obj.IsActiveGyro + obj.IsActiveAccel+(obj.IsActiveMag && obj.EnableSecondaryMag)+obj.IsActiveTemperature+(obj.IsAccelStatus && ~obj.IsActiveInterrupt)+(obj.IsGyroStatus && ~obj.IsActiveInterrupt)+(obj.IsMagStatus && ~obj.IsActiveInterrupt && obj.EnableSecondaryMag));
            count = 1;
            if obj.IsActiveAccel
                objAccel=matlabshared.sensors.simulink.internal.Acceleration;
                if strcmp(obj.DataType,'single')
                    objAccel.OutputDataType = 'single';
                end
                out{count} = objAccel;
                count = count + 1;
            end
            if obj.IsActiveGyro
                objGyro = matlabshared.sensors.simulink.internal.AngularVelocity;
                if strcmp(obj.DataType,'single')
                    objGyro.OutputDataType = 'single';
                end
                out{count} = objGyro;
                count = count + 1;
            end
            if obj.IsActiveMag && obj.EnableSecondaryMag
                objMag = matlabshared.sensors.simulink.internal.MagneticField;
                if strcmp(obj.DataType,'single')
                    objMag.OutputDataType = 'single';
                end
                out{count} = objMag;
                count = count + 1;
            end
            if obj.IsActiveTemperature
                objTemp = matlabshared.sensors.simulink.internal.Temperature;
                if strcmp(obj.DataType,'single')
                    objTemp.OutputDataType = 'single';
                end
                out{count} = objTemp;
                count = count + 1;
            end
            if obj.IsAccelStatus && ~obj.IsActiveInterrupt
                out{count} =matlabshared.sensors.simulink.internal.AccelerationStatus;
                count = count + 1;
            end
            if obj.IsGyroStatus && ~obj.IsActiveInterrupt
                out{count} =matlabshared.sensors.simulink.internal.AngularRateStatus;
                count = count + 1;
            end
            if obj.IsMagStatus && ~obj.IsActiveInterrupt && obj.EnableSecondaryMag
                out{count} =matlabshared.sensors.simulink.internal.MagneticFieldStatus;
            end
        end

        function createSensorObjectImpl(obj)
            obj.SensorObject = sensors.internal.bmi160(obj.HwUtilityObject, ...
                'Bus',obj.I2CBus,'I2CAddress',obj.I2CAddress,'MagnetometerI2CAddress',obj.MagnetometerI2CAddress,'IsActiveMag',obj.IsActiveMag,'IsActiveGyro',obj.IsActiveGyro,'GyroscopeRange',obj.GyroscopeRange,'GyroscopeODR',obj.GyroscopeODR,'IsActiveAccel',obj.IsActiveAccel,'AccelerometerRange',obj.AccelerationRange,'AccelerometerODR',obj.AccelerometerODR,'AccelerometerFilterMode',obj.AccelerometerFilterMode,'GyroscopeFilterMode',obj.GyroscopeFilterMode,'IsAccelStatus',obj.IsAccelStatus,'IsGyroStatus',obj.IsGyroStatus,'IsMagStatus',obj.IsMagStatus,'EnableSecondaryMag',obj.EnableSecondaryMag,'IsActiveInterrupt',obj.IsActiveInterrupt,'IsActiveTemperature',obj.IsActiveTemperature,'MagnetometerODR',obj.MagnetometerODR,'InterruptPin',obj.InterruptPin,'DataType',obj.DataType);
        end

        function varargout = readSensorDataHook(obj)
            if obj.IsAccelStatus
                if obj.IsGyroStatus
                    if obj.IsMagStatus
                        outAccel = obj.OutputModules{end-2}.readSensor(obj.SensorObject);
                        outGyro = obj.OutputModules{end-1}.readSensor(obj.SensorObject);
                        [outMag,timestamp] = obj.OutputModules{end}.readSensor(obj.SensorObject);
                        % If more than status is required
                        if obj.NumOutputs > 3
                            for i = 1:obj.NumOutputs-3
                                [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                            end
                        else
                            i = 0;
                        end
                        varargout{i+1} = outAccel;
                        varargout{i+2} = outGyro;
                        varargout{i+3} = outMag;
                        varargout{i+4} = timestamp;
                    else
                        outAccel = obj.OutputModules{end-1}.readSensor(obj.SensorObject);
                        [outGyro,timestamp] = obj.OutputModules{end}.readSensor(obj.SensorObject);
                        % If more than status is required
                        if obj.NumOutputs > 2
                            for i = 1:obj.NumOutputs-2
                                [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                            end
                        else
                            i = 0;
                        end
                        varargout{i+1} = outAccel;
                        varargout{i+2} = outGyro;
                        varargout{i+3} = timestamp;
                    end
                else
                    if obj.IsMagStatus
                        outAccel = obj.OutputModules{end-1}.readSensor(obj.SensorObject);
                        [outMag,timestamp] = obj.OutputModules{end}.readSensor(obj.SensorObject);
                        % If more than status is required
                        if obj.NumOutputs > 2
                            for i = 1:obj.NumOutputs-2
                                [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                            end
                        else
                            i = 0;
                        end
                        varargout{i+1} = outAccel;
                        varargout{i+2} = outMag;
                        varargout{i+3} = timestamp;
                    else
                        [outAccel,timestamp] = obj.OutputModules{end}.readSensor(obj.SensorObject);
                        % If more than status is required
                        if obj.NumOutputs > 1
                            for i = 1:obj.NumOutputs-1
                                [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                            end
                        else
                            i = 0;
                        end
                        varargout{i+1} = outAccel;
                        varargout{i+2} = timestamp;
                    end
                end
            else
                if obj.IsGyroStatus
                    if obj.IsMagStatus
                        outGyro = obj.OutputModules{end-1}.readSensor(obj.SensorObject);
                        [outMag,timestamp] = obj.OutputModules{end}.readSensor(obj.SensorObject);
                        % If more than status is required
                        if obj.NumOutputs > 2
                            for i = 1:obj.NumOutputs-2
                                [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                            end
                        else
                            i = 0;
                        end
                        varargout{i+1} = outGyro;
                        varargout{i+2} = outMag;
                        varargout{i+3} = timestamp;
                    else
                        [outGyro,timestamp] = obj.OutputModules{end}.readSensor(obj.SensorObject);
                        % If more than status is required
                        if obj.NumOutputs > 1
                            for i = 1:obj.NumOutputs-1
                                [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                            end
                        else
                            i = 0;
                        end
                        varargout{i+1} = outGyro;
                        varargout{i+2} = timestamp;
                    end
                else
                    if obj.IsMagStatus
                        [outMag,timestamp] = obj.OutputModules{end}.readSensor(obj.SensorObject);
                        % If more than status is required
                        if obj.NumOutputs > 1
                            for i = 1:obj.NumOutputs-1
                                [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                            end
                        else
                            i = 0;
                        end
                         varargout{i+1} = outMag;
                         varargout{i+2} = timestamp;
                    else
                        for i = 1:obj.NumOutputs
                            [varargout{i},timestamp] = obj.OutputModules{i}.readSensor(obj.SensorObject);
                        end
                        varargout{i+1} = timestamp;
                    end
                end
            end
        end
    end

    methods(Access = protected)
        % Block mask display
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            outport_label = [];
            num = getNumOutputsImpl(obj);
            if num > 0
                outputs = cell(1,num);
                [outputs{1:num}] = getOutputNamesImpl(obj);
                for i = 1:num
                    outport_label = [outport_label 'port_label(''output'',' num2str(i) ',''' outputs{i} ''');' ]; %#ok<AGROW>
                end
            end
            maskDisplayCmds = [ ...
                ['color(''white'');',newline],...
                ['plot([100,100,100,100]*1,[100,100,100,100]*1);',newline]...
                ['plot([100,100,100,100]*0,[100,100,100,100]*0);',newline]...
                ['color(''blue'');',newline] ...
                ['text(38, 92, ','''',obj.Logo,'''',',''horizontalAlignment'', ''right'');',newline],...
                ['color(''black'');',newline], ...
                ['image(imread(fullfile(matlabshared.sensors.internal.getSensorRootDir,''+matlabshared'',''+sensors'',''+simulink'',''+internal'',''IMU_image.png'')),''center'');', newline], ...
                ['text(52,12,' [''' ' 'BMI160' ''',''horizontalAlignment'',''right'');' newline]]   ...
                outport_label
                ];
        end

        function flag = isInactivePropertyImpl(obj, prop)
            flag = false;
            switch prop
                case "AccelerationRange"
                    flag = ~obj.IsActiveAccel;
                case "AccelerometerODR"
                    flag = ~obj.IsActiveAccel;
                case "InterruptPin"
                    flag = ~obj.IsActiveInterrupt;
                case "MagnetometerI2CAddress"
                    flag = ~obj.EnableSecondaryMag;
                case "IsActiveMag"
                    flag = ~obj.EnableSecondaryMag;
                case "IsEnableAccelLowPassFilter"
                    flag = ~obj.IsActiveAccel;
                case "AccelerometerFilterMode"
                    flag = ~(obj.IsActiveAccel && obj.IsEnableAccelLowPassFilter);
                case "GyroscopeRange"
                    flag = ~obj.IsActiveGyro;
                case "GyroscopeODR"
                    flag = ~obj.IsActiveGyro;
                case "IsEnableGyroLowPassFilter"
                    flag = ~obj.IsActiveGyro;
                case "GyroscopeFilterMode"
                    flag = ~(obj.IsActiveGyro && obj.IsEnableGyroLowPassFilter);
                case "MagnetometerODR"
                    flag = ~(obj.IsActiveMag && obj.EnableSecondaryMag);
                case "IsAccelStatus"
                    flag = obj.IsActiveInterrupt;
                case "IsGyroStatus"
                    flag = obj.IsActiveInterrupt;
                case "IsMagStatus"
                    flag = obj.IsActiveInterrupt || ~obj.EnableSecondaryMag;
                case "BitRate"
                    flag = true;
            end
        end

        function validatePropertiesImpl(obj)
            % Validate related or interdependent property values
            %Check whether all outputs are disabled. In that case an error is
            %thrown asking user to enable atleast one output
            if ~obj.IsActiveGyro && ~obj.IsActiveAccel && ~(obj.IsActiveMag && obj.EnableSecondaryMag) && ~obj.IsActiveTemperature && ~obj.IsAccelStatus && ~obj.IsGyroStatus && ~obj.IsMagStatus
                error(message('matlab_sensors:general:SensorsNoOutputs'));
            end

        end
    end

    methods(Access = protected, Static)
        function header = getHeaderImpl()
            txtString = ['Measure linear acceleration and angular rate along X, Y, and Z axis and measure temperature from BMI160 sensor. Measure magnetic field along X, Y, and Z axis by connecting BMM150 as a secondary sensor to BMI160.',newline,newline,...
                'The block outputs acceleration, angular rate, and magnetic field values as separate [1X3] vectors in units of m/s^2, rad/s, and ' char(181) 'T respectively, along with the status of the measured values. Status is 0 if data read is new and 1 if data read is not new.  The block outputs temperature value in ',char(0176),'C. Connect BMM150 as a secondary magnetometer through ASDA and ASCL pins of BMI160.'];
            header = matlab.system.display.Header(mfilename('class'), 'Title',...
                'BMI160 6DOF IMU Sensor','Text',txtString,'ShowSourceLink',false);
        end

        function groups = getPropertyGroupsImpl
            i2cModule = matlab.system.display.internal.Property('I2CModule', 'Description', 'I2C module');
            i2cAddress = matlab.system.display.internal.Property('I2CAddress', 'Description', 'BMI160 I2C address');
            interruptProp = matlab.system.display.internal.Property('IsActiveInterrupt', 'Description', 'Enable data ready interrupt');
            interruptPin = matlab.system.display.internal.Property('InterruptPin', 'Description', 'Interrupt receive pin');
            secondaryMagProp = matlab.system.display.internal.Property('EnableSecondaryMag', 'Description', 'Enable secondary magnetometer');
            magnetometerI2CAddress = matlab.system.display.internal.Property('MagnetometerI2CAddress', 'Description', 'BMM150 I2C address');
            bitRate=matlab.system.display.internal.Property('BitRate', 'Description', 'Bit rate','IsGraphical',false);
            i2cProperties = matlab.system.display.Section('PropertyList', {i2cModule,i2cAddress,interruptProp,interruptPin,secondaryMagProp,magnetometerI2CAddress,bitRate});
            % Select outputs
            gyroProp = matlab.system.display.internal.Property('IsActiveGyro', 'Description', 'Angular rate (rad/s)');
            accelProp = matlab.system.display.internal.Property('IsActiveAccel', 'Description', 'Acceleration (m/s^2)');
            magProp = matlab.system.display.internal.Property('IsActiveMag', 'Description', ['Magnetic field (',char(181),'T)']);
            temperatureProp = matlab.system.display.internal.Property('IsActiveTemperature', 'Description', ['Temperature (',char(0176),'C)']);
            accelStatusProp= matlab.system.display.internal.Property('IsAccelStatus','Description', 'Acceleration status');
            gyroStatusProp= matlab.system.display.internal.Property('IsGyroStatus','Description', 'Angular rate status');
            magStatusProp= matlab.system.display.internal.Property('IsMagStatus','Description', 'Magnetic field status');
            selectOutputs = matlab.system.display.Section('Title', 'Select outputs', 'PropertyList', {accelProp,gyroProp,magProp,temperatureProp,accelStatusProp,gyroStatusProp,magStatusProp});
            % Accelerometer properties
            accelerationRange = matlab.system.display.internal.Property('AccelerationRange','Description', 'Accelerometer range');
            accelerometerODR = matlab.system.display.internal.Property('AccelerometerODR','Description', 'Accelerometer output data rate');
            accelerometerFilterMode = matlab.system.display.internal.Property('AccelerometerFilterMode','Description', 'Accelerometer filter mode');
            enableLowPassFilter=matlab.system.display.internal.Property('IsEnableAccelLowPassFilter', 'Description', 'Enable low pass filter');
            % gyroscope properties
            gyroscopeRange = matlab.system.display.internal.Property('GyroscopeRange', 'Description', 'Gyroscope range');
            gyroscopeODR = matlab.system.display.internal.Property('GyroscopeODR', 'Description', 'Gyroscope output data rate');
            gyroscopeFilterMode = matlab.system.display.internal.Property('GyroscopeFilterMode', 'Description', 'Gyroscope filter mode');
            enableGyroLowPassFilter=matlab.system.display.internal.Property('IsEnableGyroLowPassFilter', 'Description', 'Enable low pass filter');
            % Magnetometer properties
            magnetometerODR =  matlab.system.display.internal.Property('MagnetometerODR', 'Description', 'Magnetometer output data rate');
            accelerometerSettings = matlab.system.display.Section(...
                'Title','Accelerometer',...
                'PropertyList',{accelerationRange,accelerometerODR,enableLowPassFilter,accelerometerFilterMode});
            gyroscopeSettings = matlab.system.display.Section(...
                'Title','Gyroscope',...
                'PropertyList',{gyroscopeRange,gyroscopeODR,enableGyroLowPassFilter,gyroscopeFilterMode});
            magnetometerSettings = matlab.system.display.Section(...
                'Title','Magnetometer',...
                'PropertyList',{magnetometerODR});
            dataType =  matlab.system.display.internal.Property('DataType', 'Description', 'Data type');
            dataTypeSection = matlab.system.display.Section('PropertyList', {dataType});
            % Sample time
            SampleTimeProp = matlab.system.display.internal.Property('SampleTime', 'Description', 'Sample time');
            sampleTimeSection = matlab.system.display.Section('PropertyList', {SampleTimeProp});

            MainGroup = matlab.system.display.SectionGroup(...
                'Title','Main',...
                'Sections', [i2cProperties,selectOutputs,dataTypeSection,sampleTimeSection]);
            AdvancedGroup = matlab.system.display.SectionGroup(...
                'Title','Advanced',...
                'Sections',  [accelerometerSettings,gyroscopeSettings,magnetometerSettings]);
            groups=[ MainGroup, AdvancedGroup];

        end
    end
end