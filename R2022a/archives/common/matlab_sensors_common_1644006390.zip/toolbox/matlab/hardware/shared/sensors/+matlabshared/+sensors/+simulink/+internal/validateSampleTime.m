function newTime = validateSampleTime(newTime)
% Sample time must be a real scalar value or 2 element array.
%#codegen

%   Copyright 2021 The MathWorks, Inc.

coder.allowpcode('plain');

isOk = isreal(newTime) && ...
    (all(all(isfinite(newTime))) || all(all(isinf(newTime)))) && ... %need to work all dimensions to scalar logical
    (numel(newTime) == 1 || numel(newTime) == 2);

coder.internal.errorIf(~isOk,'svd:svd:InvalidSampleTimeNeedScalar');
if ~isreal(newTime)
    newTime = real(newTime);
end

coder.internal.errorIf((newTime(1) < 0.0 && newTime(1) ~= -1.0),'svd:svd:InvalidSampleTimeNeedPositive');

if numel(newTime) == 2
    coder.internal.errorIf((newTime(1) > 0.0 && newTime(2) >= newTime(1)),'svd:svd:InvalidSampleTimeNeedSmallerOffset');
    coder.internal.errorIf((newTime(1) == -1.0 && newTime(2) ~= 0.0),'svd:svd:InvalidSampleTimeNeedZeroOffset');
    coder.internal.errorIf((newTime(1) == 0.0 && newTime(2) ~= 1.0),'svd:svd:InvalidSampleTimeNeedOffsetOne');
end

end