
%   Copyright 2019-2020 The MathWorks, Inc.

classdef TimeFormat
    enumeration
        datetime,duration
    end
end