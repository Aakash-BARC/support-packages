classdef OutputModuleBase < matlab.System
   %OUTPUTMODULEBASE class is the base class that each output value has to
   %inherit.
   %   This class gives the abstract properties and methods for the
   %   simulink propogation methods.
    
   %   Copyright 2020-2021 The MathWorks, Inc.
    
    %#codegen
    
    properties(Abstract,Nontunable)
        OutputDataType char
        OutputSize double
        OutputName char
        IsOutputComplex logical
    end
    
    methods(Abstract)
        [data,timestamp] = readSensor(obj)        
    end
end