classdef (Hidden, Abstract) CommonSensorUtilities < handle
    
    % This class is the codegen class for
    % matlabshared.sensors.CommonSensorUtilities. It does not add any
    % feature. Rather this empty class ensures that when a hardware class
    % inherits matlabshared.sensors.CommonSensorUtilities, no unneccessary
    % error is thrown while generating code from sensor object.
    
    % Copyright 2020 The MathWorks, Inc.
    
    %#codegen
    methods (Access = {?matlabshared.sensors.internal.Accessor})
     function delayFunctionForHardware(obj,factor)
            % This delay is interms of seconds. Factor represents number of seconds 
     end
    end
end