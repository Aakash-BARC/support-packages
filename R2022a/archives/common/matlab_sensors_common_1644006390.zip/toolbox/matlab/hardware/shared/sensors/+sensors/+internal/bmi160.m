classdef (Sealed) bmi160 < matlabshared.sensors.accelerometer & matlabshared.sensors.gyroscope & matlabshared.sensors.magnetometer & matlabshared.sensors.sensorUnit & matlabshared.sensors.TemperatureSensor
    %BMI160 connects to the BMI160 sensor connected to a hardware object
    %
    %   sensorObj = bmi160(a) returns a System object that reads sensor
    %   data from the BMI160 sensor connected to the I2C bus of an
    %   hardware board. 'a' is a hardware object.
    %
    %   sensorObj = bmi160(a, 'Name', Value, ...) returns a BMI160 System object
    %   with each specified property name set to the specified value. You
    %   can specify additional name-value pair arguments in any order as
    %   (Name1,Value1,...,NameN, ValueN).
    %
    %   bmi160 Properties
    %   I2CAddress      : Specify the I2C Address of the BMI160.
    %   Bus             : Specify the I2C Bus where sensor is connected.
    %   ReadMode        : Specify whether to return the latest available
    %                     sensor values or the values accumulated from the
    %                     beginning when the 'read' API is executed.
    %                     ReadMode can be either 'latest' or 'oldest'.
    %                     Default value is 'latest'.
    %   SampleRate      : Rate at which samples are read from hardware.
    %                     Default value is 100 (samples/s).
    %   SamplesPerRead  : Number of samples returned per execution of read
    %                     function. Default value is 10.
    %   OutputFormat    : Format of output of read function. OutputFormat
    %                     can be either 'timetable' or 'matrix'. Default
    %                     value is 'timetable'.
    %   TimeFormat      : Format of time stamps returned by read function.
    %                     TimeFormat can be either 'datetime' or 'duration'
    %                     Default value is 'datetime'.
    %   SamplesAvailable: Number of samples remaining in the buffer waiting
    %                     to be read.
    %   SamplesRead     : Number of samples read from the sensor.
    %
    %   bmmi160 methods
    %
    %   readAcceleration      : Read one sample of acceleration data from
    %                           sensor.
    %   readAngularVelocity   : Read one sample of angular velocity values from
    %                           sensor.
    %   readMagneticField     : Read one sample of magnetic field value from
    %                           sensor.
    %   readTemperature       : Read one sample of temperature value from sensor.
    %   read                  : Read one frame of pressure and temperature values from
    %                           the sensor along with time stamps and
    %                           overruns.
    %   stop/release          : Stop sending data from hardware and
    %                           allow changes to non-tunable properties
    %                           values and input characteristics.
    %   flush                 : Flushes all the data accumulated in the
    %                           buffers and resets the system object.
    %   info                  : Read sensor information such as output
    %                           data rate, bandwidth and so on.
    %
    %
    %   Example: Read one sample of Acceleration value from BMI160 sensor
    %
    %   a = arduino('COM3','Uno','Libraries','I2C'); % Create arduino object with I2C library included
    %   sensorObj = bmi160(a);
    %   accelData  =  sensorObj.readAcceleration;
    %
    %   For Streaming workflow
    %   a = arduino('COM3','Uno','Libraries','I2C'); % Create arduino object with I2C library included
    %   sensorObj = bmi160(a);
    %   read(sensorObj)

    %   Copyright 2021 The MathWorks, Inc.

    %#codegen

    properties(SetAccess = protected, GetAccess = public, Hidden)
        MinSampleRate = 25;
        MaxSampleRate = 200;
    end

    properties(Nontunable, Hidden)
        DoF = [3;3];
    end

    properties(Access = protected, Constant)
        AccelerometerDataRegister = 0x12;
        DeviceID = 0xD1;
        CMD_REG = 0X7E;
        WHO_AM_I = 0x00;
        AccelerometerRangeRegister = 0x41;
        AccelerometerODRRegister = 0x40;
        ODRParametersAccel = [12.5,25,50,100,200,400,800,1600];
        ODRParametersGyro = [25,50,100,200,400,800,1600,3200];
        GyroscopeDataRegister = 0x0C;
        GyroscopeRangeRegister = 0x43;
        GyroscopeODRRegister = 0x42;
        TemperatureDataRegister = 0x20;
        MagnetometerDataHighRegister = 0x05;
        MagnetometerConfRegister = 0x44;
        StatusRegister = 0x1B;
        Magnetometer_IF_0 = 0x4B;
        PageRegister = 0x7F;
        Magnetometer_IF_1 = 0x4C;
        Magnetometer_IF_2 = 0x4D
        Magnetometer_IF_3 = 0x4E
        Magnetometer_IF_4 = 0x4F
        Magnetometer_IFConfig = 0x6B;
        MagnetometerDataRegister = 0x04;
        TemperatureOffset = 23; %Interms of °C
    end

    properties(Access = {?matlabshared.sensors.coder.matlab.sensorInterface, ?matlabshared.sensors.sensorInterface}, Constant)
        I2CAddressList = [0x68,0x69];
    end

    properties(Access = protected,Nontunable)
        GyroscopeRange = '125 dps';
        GyroscopeResolution;
        GyroscopeODR;
        GyroscopeFilterMode = 'Normal';
        IsActiveGyro = true;
        AccelerometerRange = '+/- 2g';
        AccelerometerResolution;
        AccelerometerODR;
        MagnetometerODR;
        AccelerometerFilterMode = 'Normal';
        IsActiveAccel = true;
        MagnetometerI2CAddress;
        IsActiveMag = true;
        EnableSecondaryMag = true;
        IsAccelStatus = false;
        IsGyroStatus = false;
        IsMagStatus = false;
        IsActiveInterrupt = false;
        IsActiveTemperature = false;
        MagnetometerResolution = 0.3;%Interms of micro tesla
        DegreesPerSecToRadiansPerSec = 0.017453;
        TemperatureResolution = 1/512;%This Resolution value is in terms of °C
        InterruptPin = 'INT1';
        DataType = 'single';
    end

    properties(Hidden, Constant)
        BytesToRead = 6;
        BytesToReadForTemperature = 2;
    end

    methods
        function obj = bmi160(varargin)
            obj@matlabshared.sensors.sensorUnit(varargin{:})
            if ~obj.isSimulink
                % Code generation does not support try-catch block. So init
                % function call is made separately in both codegen and IO
                % context.
                if ~coder.target('MATLAB')
                    obj.init(varargin{:});
                else
                    try
                        obj.init(varargin{:});
                    catch ME
                        throwAsCaller(ME);
                    end
                end
                obj.IsActiveAccel = true;
                obj.IsActiveGyro = true;
                obj.IsActiveMag = true;
                obj.EnableSecondaryMag = true;
                obj.AccelerometerRange = '+/- 2g';
                obj.AccelerometerResolution = getAccelerometerResolution(obj);
                obj.AccelerometerFilterMode = 'Normal';
                obj.GyroscopeRange = '125 dps';
                obj.GyroscopeResolution = getGyroscopeResolution(obj);
                obj.GyroscopeFilterMode = 'Normal';
                obj.IsAccelStatus = false;
                obj.IsGyroStatus = false;
                obj.IsMagStatus = false;
                obj.IsActiveTemperature = true;
                obj.IsActiveInterrupt = false;
                obj.InterruptPin = 'INT1';
                obj.DataType = 'single';
            else
                names =     {'Bus','I2CAddress','MagnetometerI2CAddress'...
                    'IsActiveMag','IsActiveGyro','GyroscopeRange','GyroscopeODR','IsActiveAccel','AccelerometerRange','AccelerometerODR','AccelerometerFilterMode','GyroscopeFilterMode','IsAccelStatus','IsGyroStatus','IsMagStatus','EnableSecondaryMag','IsActiveInterrupt','IsActiveTemperature','MagnetometerODR','InterruptPin','DataType'};
                defaults =    {0,obj.I2CAddressList(2),0x13,...
                    true,true,'125 dps',12.5,true,'+/- 2g', 25, 'Normal', 'Normal',false,false,false,false,false,false,'25 Hz','INT1','single'};
                p = matlabshared.sensors.internal.NameValueParserInternal(names, defaults ,false);
                p.parse(varargin{2:end});
                i2cAddress = p.parameterValue('I2CAddress');
                obj.MagnetometerI2CAddress = p.parameterValue('MagnetometerI2CAddress');
                bus =  p.parameterValue('Bus');
                obj.init(varargin{1},'I2CAddress',i2cAddress,'Bus',bus);
                obj.IsActiveAccel= p.parameterValue('IsActiveAccel');
                obj.IsActiveGyro= p.parameterValue('IsActiveGyro');
                obj.IsActiveMag= p.parameterValue('IsActiveMag');
                obj.EnableSecondaryMag = p.parameterValue('EnableSecondaryMag');
                obj.AccelerometerRange = p.parameterValue('AccelerometerRange');
                obj.AccelerometerResolution = getAccelerometerResolution(obj);
                obj.AccelerometerODR = p.parameterValue('AccelerometerODR');
                obj.AccelerometerFilterMode = p.parameterValue('AccelerometerFilterMode');
                obj.GyroscopeRange = p.parameterValue('GyroscopeRange');
                obj.GyroscopeResolution = getGyroscopeResolution(obj);
                obj.GyroscopeODR = p.parameterValue('GyroscopeODR');
                obj.GyroscopeFilterMode = p.parameterValue('GyroscopeFilterMode');
                obj.IsAccelStatus = p.parameterValue('IsAccelStatus');
                obj.IsGyroStatus = p.parameterValue('IsGyroStatus');
                obj.IsMagStatus = p.parameterValue('IsMagStatus');
                obj.IsActiveTemperature = p.parameterValue('IsActiveTemperature');
                obj.MagnetometerODR = p.parameterValue('MagnetometerODR');
                obj.IsActiveInterrupt = p.parameterValue('IsActiveInterrupt');
                obj.InterruptPin = p.parameterValue('InterruptPin');
                obj.DataType = p.parameterValue('DataType');
            end
        end

        function enableInterrupts(obj,value)
            if obj.IsActiveInterrupt
                if strcmp(value,'INT1')
                    writeRegister(obj.Device,0x51,0x10);
                    writeRegister(obj.Device,0x53,0x08);
                    writeRegister(obj.Device,0x55,0x00);
                    writeRegister(obj.Device,0x56,0x80);
                    writeRegister(obj.Device,0x57,0x00);
                else
                    writeRegister(obj.Device,0x51,0x10);
                    writeRegister(obj.Device,0x53,0x80);
                    writeRegister(obj.Device,0x55,0x00);
                    writeRegister(obj.Device,0x56,0x08);
                    writeRegister(obj.Device,0x57,0x00);
                end
            end
        end

        function disableInterrupts(obj)
            writeRegister(obj.Device,0x53,0x00);
            writeRegister(obj.Device,0x55,0x00);
            writeRegister(obj.Device,0x56,0x00);
            writeRegister(obj.Device,0x57,0x00);
        end

        function set.GyroscopeODR(obj, value)
            switch value
                case '25 Hz'
                    ByteMask = 0x06;
                case '50 Hz'
                    ByteMask = 0x07;
                case '100 Hz'
                    ByteMask = 0x08;
                case '200 Hz'
                    ByteMask = 0x09;
                case '400 Hz'
                    ByteMask = 0x0A;
                case '800 Hz'
                    ByteMask = 0x0B;
                case '1600 Hz'
                    ByteMask = 0x0C;
                case '3200 Hz'
                    ByteMask = 0x0D;
                otherwise
                    ByteMask = 0x06;
            end
            val_CTRL1_XL = readRegister(obj.Device, obj.GyroscopeODRRegister);
            writeRegister(obj.Device,obj.GyroscopeODRRegister, bitor(bitand(val_CTRL1_XL, uint8(0xF0)), uint8(ByteMask)));
            obj.GyroscopeODR = value;
        end

        function set.GyroscopeFilterMode(obj, value)
            switch value
                case 'Normal'
                    ByteMask = 0x20;
                case 'OSR2'
                    ByteMask = 0x10;
                case 'OSR4'
                    ByteMask = 0x00;
                otherwise
                    ByteMask = 0x20;
            end
            val_CTRL1_XL = readRegister(obj.Device, obj.GyroscopeODRRegister);
            writeRegister(obj.Device,obj.GyroscopeODRRegister, bitor(bitand(val_CTRL1_XL, uint8(0xCF)), uint8(ByteMask)));
            obj.GyroscopeFilterMode = value;
        end

        function set.MagnetometerODR(obj,value)
            switch value
                case '0.78125 Hz'
                    ByteMask = 0x01;
                case '1.5625 Hz'
                    ByteMask = 0x02;
                case '3.125 Hz'
                    ByteMask = 0x03;
                case '6.25 Hz'
                    ByteMask = 0x04;
                case '12.5 Hz'
                    ByteMask = 0x05;
                case '25 Hz'
                    ByteMask = 0x06;
                case '50 Hz'
                    ByteMask = 0x07;
                case '100 Hz'
                    ByteMask = 0x08;
                case '200 Hz'
                    ByteMask = 0x09;
                case '400 Hz'
                    ByteMask = 0x0A;
                case '800 Hz'
                    ByteMask = 0x0B;
                otherwise
                    ByteMask = 0x06;
            end
            val = readRegister(obj.Device, obj.MagnetometerConfRegister);
            writeRegister(obj.Device,obj.MagnetometerConfRegister, bitor(bitand(val, uint8(0xF0)), uint8(ByteMask)));
            enableMagDataMode(obj);
        end

        function set.AccelerometerODR(obj, value)
            switch value
                case '12.5 Hz'
                    ByteMask = 0x05;
                case '25 Hz'
                    ByteMask = 0x06;
                case '50 Hz'
                    ByteMask = 0x07;
                case '100 Hz'
                    ByteMask = 0x08;
                case '200 Hz'
                    ByteMask = 0x09;
                case '400 Hz'
                    ByteMask = 0x0A;
                case '800 Hz'
                    ByteMask = 0x0B;
                case '1600 Hz'
                    ByteMask = 0x0C;
                otherwise
                    ByteMask = 0x05;
            end
            val_CTRL1_XL = readRegister(obj.Device, obj.AccelerometerODRRegister);
            writeRegister(obj.Device,obj.AccelerometerODRRegister, bitor(bitand(val_CTRL1_XL, uint8(0x70)), uint8(ByteMask)));
            obj.AccelerometerODR = value;
        end

        function set.AccelerometerFilterMode(obj, value)
            switch value
                case 'Normal'
                    ByteMask = 0x20;
                case 'OSR2'
                    ByteMask = 0x10;
                case 'OSR4'
                    ByteMask = 0x00;
                otherwise
                    ByteMask = 0x20;
            end
            val_CTRL1_XL = readRegister(obj.Device, obj.AccelerometerODRRegister);
            writeRegister(obj.Device,obj.AccelerometerODRRegister, bitor(bitand(val_CTRL1_XL, uint8(0x0F)), uint8(ByteMask)));
            obj.AccelerometerFilterMode = value;
        end

        function set.GyroscopeRange(obj, value)
            setGyroRange(obj,value);
            obj.GyroscopeRange=value;
        end

        function set.AccelerometerRange(obj, value)
            setAccelRange(obj,value);
            obj.AccelerometerRange=value;
        end

        function set.IsActiveAccel(obj, value)
            if value
                accelPMUModeCommandRegister(obj);
            end
            obj.IsActiveAccel = value;
        end

        function set.IsActiveGyro(obj, value)
            if value
                gyroPMUModeCommandRegister(obj);
            end
            obj.IsActiveGyro = value;
        end

        function set.EnableSecondaryMag(obj, value)
            if value
                initSecondaryMagnetometer(obj);
            end
            obj.EnableSecondaryMag = value;
        end

        function set.IsActiveInterrupt(obj, value)
            obj.IsActiveInterrupt = value;
        end

        function set.InterruptPin(obj, value)
            enableInterrupts(obj,value);
            obj.InterruptPin = value;
        end

    end

    methods(Access = protected)
        function initDeviceImpl(obj)
            deviceid_value = readRegister(obj.Device, obj.WHO_AM_I);
            if(deviceid_value ~= obj.DeviceID)
                if coder.target('MATLAB')
                    matlabshared.sensors.internal.localizedWarning('matlab_sensors:general:invalidDeviceID',num2str(obj.DeviceID));
                end
            end
        end

        function initGyroscopeImpl(obj)
        end

        function initAccelerometerImpl(obj)
        end

        function initMagnetometerImpl(obj)
        end

        function initSensorImpl(obj)
            resetCommandRegister(obj);
            fastOffsetCommandRegister(obj);
        end

        function [data,status,timestamp]  = readAccelerationImpl(obj)
            if obj.IsActiveInterrupt
                disableInterrupts(obj);
                [tempData,status,timestamp] = obj.readRegisterData(obj.AccelerometerDataRegister, obj.BytesToRead, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToRead))
                        data = reshape(data,[obj.BytesToRead,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertAccelData(obj, data);
                enableInterrupts(obj,obj.InterruptPin);
            else
                [tempData,status,timestamp] = obj.readRegisterData(obj.AccelerometerDataRegister, obj.BytesToRead, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToRead))
                        data = reshape(data,[obj.BytesToRead,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertAccelData(obj, data);
            end
        end


        function [data,status,timestamp]  = readAngularVelocityImpl(obj)
            if obj.IsActiveInterrupt
                disableInterrupts(obj);
                [tempData,status,timestamp] = obj.readRegisterData(obj.GyroscopeDataRegister, obj.BytesToRead, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToRead))
                        data = reshape(data,[obj.BytesToRead,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertGyroData(obj, data);
                enableInterrupts(obj,obj.InterruptPin);
            else
                [tempData,status,timestamp] = obj.readRegisterData(obj.GyroscopeDataRegister, obj.BytesToRead, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToRead))
                        data = reshape(data,[obj.BytesToRead,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertGyroData(obj, data);
            end
        end

        function [data,status,timestamp]  = readMagneticFieldImpl(obj)
            if obj.IsActiveInterrupt
                disableInterrupts(obj);
                [tempData,status,timestamp] = obj.readRegisterData(obj.MagnetometerDataRegister, obj.BytesToRead, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToRead))
                        data = reshape(data,[obj.BytesToRead,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertMagData(obj, data);
                enableInterrupts(obj,obj.InterruptPin);
            else
                [tempData,status,timestamp] = obj.readRegisterData(obj.MagnetometerDataRegister, obj.BytesToRead, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToRead))
                        data = reshape(data,[obj.BytesToRead,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertMagData(obj, data);
            end
        end

        function [data,status,timestamp]  = readTemperatureImpl(obj)
            if obj.IsActiveInterrupt
                disableInterrupts(obj);
                [tempData,status,timestamp] = obj.readRegisterData(obj.TemperatureDataRegister, obj.BytesToReadForTemperature, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToReadForTemperature))
                        data = reshape(data,[obj.BytesToReadForTemperature,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertTemperatureData(obj, data);
                enableInterrupts(obj,obj.InterruptPin);
            else
                [tempData,status,timestamp] = obj.readRegisterData(obj.TemperatureDataRegister, obj.BytesToReadForTemperature, "uint8");
                if(isequal(size(tempData,2),1))
                    data = tempData';
                    if(isequal(numel(data),obj.SamplesPerRead*obj.BytesToReadForTemperature))
                        data = reshape(data,[obj.BytesToReadForTemperature,obj.SamplesPerRead])';
                    end
                else
                    data = tempData;
                end
                data = convertTemperatureData(obj, data);
            end
        end

        function [data,status,timestamp]  = readSensorDataImpl(obj)
            [accelData,~,~]  = readAccelerationImpl(obj);
            [gyroData,~,~] = readAngularVelocityImpl(obj);
            [magData,status,timestamp]=readMagneticFieldImpl(obj);
            [tempData ,~,~] = readTemperatureImpl(obj);
            data=[accelData,gyroData,magData,tempData];
        end

        function data = convertSensorDataImpl(obj, data)
            data=[convertAccelData(obj, data(1:obj.BytesToRead)) convertGyroData(obj, data(obj.BytesToRead+1:obj.BytesToRead*2)) convertMagData(obj, data(obj.BytesToRead*2+1:obj.BytesToRead*3)) convertTemperatureData(obj, data(obj.BytesToRead*3+1:obj.BytesToRead*3+obj.BytesToReadForTemperature))];
        end

        function setODRImpl(obj)
            % used only for MATLAB
            accelODR = obj.ODRParametersAccel(obj.ODRParametersAccel<=obj.SampleRate);
            obj.AccelerometerODR = accelODR(end);
            gyroODR = obj.ODRParametersGyro(obj.ODRParametersGyro<=obj.SampleRate);
            obj.GyroscopeODR = gyroODR(end);
        end

        function s = infoImpl(obj)
            s = struct('AccelerometerODR',obj.AccelerometerODR,'GyroscopeODR',obj.GyroscopeODR);
        end

        function names = getMeasurementDataNames(obj)
            names = [obj.AccelerometerDataName, obj.GyroscopeDataName ,obj.MagnetometerDataName];
        end
    end

    methods(Hidden = true)
        function [status,timestamp] = readAccelerationStatus(obj)
            %Status can take 2 values namely 0,1
            %0 represents  new data is available
            %1 represents  new data is not yet available
            [temp,~,timestamp] = obj.readRegisterData(obj.StatusRegister, 1, 'uint8');
            statusValues = bitget(uint8(temp),8);
            if(isequal(statusValues,1))
                status=int8(0);
            else
                status=int8(1);
            end
        end
        function [status,timestamp] = readAngularRateStatus(obj)
            %Status can take 2 values namely 0,1
            %0 represents  new data is available
            %1 represents  new data is not yet available
            [temp,~,timestamp] = obj.readRegisterData(obj.StatusRegister, 1, 'uint8');
            statusValues = bitget(uint8(temp),7);
            if(isequal(statusValues,1))
                status=int8(0);
            else
                status=int8(1);
            end
        end
        function [status,timestamp] = readMagneticFieldStatus(obj)
            %Status can take 2 values namely 0,1
            %0 represents  new data is available
            %1 represents  new data is not yet available
            timestamp = [];
            if obj.EnableSecondaryMag
                [temp,~,timestamp] = obj.readRegisterData(obj.StatusRegister, 1, 'uint8');
                statusValues = bitget(uint8(temp),6);
                if(isequal(statusValues,1))
                    status=int8(0);
                else
                    status=int8(1);
                end
            end
        end
    end

    methods(Access = private)
        function initSecondaryMagnetometer(obj)
            setMagInterface(obj);
            enablingPullUpRegistersForMag(obj);
            setMagHigherByte(obj);
            setAuxI2CAddress(obj);
            enableMagSetup(obj);
            setIFConfig(obj);
            enableSleepMode(obj);
            setRepititions(obj);
            enableForceMode(obj);
            setDataReadAddress(obj);
        end
        function data = convertTemperatureData(obj, tempSensorData)
            %little endian
            if strcmp(obj.DataType,'double')
                data = double(bitor(int16(tempSensorData(:, 1)), bitshift(int16(tempSensorData(:, 2)),8)));
                data = data*obj.TemperatureResolution + obj.TemperatureOffset;
            else
                data = single(bitor(int16(tempSensorData(:, 1)), bitshift(int16(tempSensorData(:, 2)),8)));
                data = single(data*obj.TemperatureResolution + obj.TemperatureOffset);
            end
        end

        function resetCommandRegister(obj)
            ByteMask = 0xB6;
            writeRegister(obj.Device,obj.CMD_REG, ByteMask);
            obj.Parent.delayFunctionForHardware(60);
        end

        function fastOffsetCommandRegister(obj)
            ByteMask = 0x03;
            writeRegister(obj.Device,obj.CMD_REG, ByteMask);
            obj.Parent.delayFunctionForHardware(60);

        end

        function gyroPMUModeCommandRegister(obj)
            ByteMask = 0x15;
            writeRegister(obj.Device,obj.CMD_REG, ByteMask);
            obj.Parent.delayFunctionForHardware(85);
        end

        function g = getGyroscopeResolution(obj)
            switch  obj.GyroscopeRange
                case sprintf('125 dps')
                    g = 1/262.4;
                case sprintf('250 dps')
                    g = 1/131.2;
                case sprintf('500 dps')
                    g = 1/65.6;
                case sprintf('1000 dps')
                    g = 1/32.8;
                case sprintf('2000 dps')
                    g = 1/16.4;
            end
        end

        function data = convertGyroData(obj,gyroSensorData)
            if strcmp(obj.DataType,'double')
                xa = double(bitor(int16(gyroSensorData(:, 1)), bitshift(int16(gyroSensorData(:, 2)),8))) ;
                ya = double(bitor(int16(gyroSensorData(:, 3)), bitshift(int16(gyroSensorData(:, 4)),8))) ;
                za = double(bitor(int16(gyroSensorData(:, 5)), bitshift(int16(gyroSensorData(:, 6)),8))) ;
                data = (obj.DegreesPerSecToRadiansPerSec * obj.GyroscopeResolution).*[xa, ya, za];
            else
                xa = single(bitor(int16(gyroSensorData(:, 1)), bitshift(int16(gyroSensorData(:, 2)),8))) ;
                ya = single(bitor(int16(gyroSensorData(:, 3)), bitshift(int16(gyroSensorData(:, 4)),8))) ;
                za = single(bitor(int16(gyroSensorData(:, 5)), bitshift(int16(gyroSensorData(:, 6)),8))) ;
                data = single((obj.DegreesPerSecToRadiansPerSec * obj.GyroscopeResolution).*[xa, ya, za]);
            end
        end

        function setGyroRange(obj,Range)
            switch Range
                case '125 dps'
                    ByteMask = 0x04;
                case '250 dps'
                    ByteMask = 0x03;
                case '500 dps'
                    ByteMask = 0x02;
                case '1000 dps'
                    ByteMask = 0x01;
                case '2000 dps'
                    ByteMask = 0x00;
            end
            val = readRegister(obj.Device,obj.GyroscopeRangeRegister);
            writeRegister(obj.Device,obj.GyroscopeRangeRegister,bitor( bitand(val, uint8(0xF8)),uint8(ByteMask)));
        end

        function g = getAccelerometerResolution(obj)
            switch  obj.AccelerometerRange
                case sprintf('+/- 2g')
                    g = 1/16384;
                case sprintf('+/- 4g')
                    g = 1/8192;
                case sprintf('+/- 8g')
                    g = 1/4096;
                case sprintf('+/- 16g')
                    g = 1/2048;
            end
        end

        function data = convertAccelData(obj,accelSensorData)
            %little endian
            if strcmp(obj.DataType,'double')
                xa = double(bitor(int16(accelSensorData(:, 1)), bitshift(int16(accelSensorData(:, 2)),8))) ;
                ya = double(bitor(int16(accelSensorData(:, 3)), bitshift(int16(accelSensorData(:, 4)),8))) ;
                za = double(bitor(int16(accelSensorData(:, 5)), bitshift(int16(accelSensorData(:, 6)),8))) ;
                data = obj.AccelerometerResolution.*[xa, ya, za];
                data = data*9.81;
            else
                xa = single(bitor(int16(accelSensorData(:, 1)), bitshift(int16(accelSensorData(:, 2)),8))) ;
                ya = single(bitor(int16(accelSensorData(:, 3)), bitshift(int16(accelSensorData(:, 4)),8))) ;
                za = single(bitor(int16(accelSensorData(:, 5)), bitshift(int16(accelSensorData(:, 6)),8))) ;
                data = single(obj.AccelerometerResolution.*[xa, ya, za]);
                data = single(data*9.81);
            end
        end

        function data = convertMagData(obj,gyroSensorData)
            %little endian
            if strcmp(obj.DataType,'double')
                xa = double(obj.conversionOfTwosComplementTodecimal(bitor(int16(bitshift(bitand(gyroSensorData(:, 1), uint8(0xF8)),-3)), bitshift(int16(gyroSensorData(:, 2)),5)),13 ));
                ya = double(obj.conversionOfTwosComplementTodecimal(bitor(int16(bitshift(bitand(gyroSensorData(:, 3), uint8(0xF8)),-3)), bitshift(int16(gyroSensorData(:, 4)),5)),13)) ;
                za = double(obj.conversionOfTwosComplementTodecimal(bitor(int16(bitshift(bitand(gyroSensorData(:, 5), uint8(0xFE)),-1)), bitshift(int16(gyroSensorData(:, 6)),7)),15)) ;
                data = obj.MagnetometerResolution.*[xa, ya, za];
            else
                xa = single(obj.conversionOfTwosComplementTodecimal(bitor(int16(bitshift(bitand(gyroSensorData(:, 1), uint8(0xF8)),-3)), bitshift(int16(gyroSensorData(:, 2)),5)),13 ));
                ya = single(obj.conversionOfTwosComplementTodecimal(bitor(int16(bitshift(bitand(gyroSensorData(:, 3), uint8(0xF8)),-3)), bitshift(int16(gyroSensorData(:, 4)),5)),13)) ;
                za = single(obj.conversionOfTwosComplementTodecimal(bitor(int16(bitshift(bitand(gyroSensorData(:, 5), uint8(0xFE)),-1)), bitshift(int16(gyroSensorData(:, 6)),7)),15)) ;
                data = single(obj.MagnetometerResolution.*[xa, ya, za]);
            end
        end

        function decimal = conversionOfTwosComplementTodecimal(obj,Input,bits)
            %  convert two's complement to decimal
            %  data - single value or array to convert
            %  bits - how many bits wide is the data
            len = length(Input);
            decimal=zeros(len,1);
            for i=1:len
                if bitget(Input(i),bits) == 1
                    decimal(i) = int16((bitxor(Input(i),2^bits-1)+1))*-1;
                else
                    decimal(i) = Input(i);
                end
            end
        end

        function setAccelRange(obj,Range)
            switch Range
                case '+/- 2g'
                    ByteMask = 0x03;
                case '+/- 4g'
                    ByteMask = 0x05;
                case '+/- 8g'
                    ByteMask = 0x08;
                case '+/- 16g'
                    ByteMask = 0x0C;
            end
            val = readRegister(obj.Device,obj.AccelerometerRangeRegister);
            writeRegister(obj.Device,obj.AccelerometerRangeRegister,bitor(bitand(val, uint8(0xF0)),uint8(ByteMask)));
        end

        function accelPMUModeCommandRegister(obj)
            ByteMask = 0x11;
            writeRegister(obj.Device,obj.CMD_REG, ByteMask);
            obj.Parent.delayFunctionForHardware(5);
        end

        function setMagInterface(obj)
            ByteMask = 0x19;
            writeRegister(obj.Device,obj.CMD_REG, ByteMask);
            obj.Parent.delayFunctionForHardware(60);
        end

        function enablingPullUpRegistersForMag(obj)
            ByteMask_EN_PULL_UP_REG_1 = 0x37;
            ByteMask_EN_PULL_UP_REG_2 = 0x9A;
            ByteMask_EN_PULL_UP_REG_3 = 0xC0;
            writeRegister(obj.Device,obj.CMD_REG, ByteMask_EN_PULL_UP_REG_1);
            obj.Parent.delayFunctionForHardware(1);
            writeRegister(obj.Device,obj.CMD_REG, ByteMask_EN_PULL_UP_REG_2);
            obj.Parent.delayFunctionForHardware(1);
            writeRegister(obj.Device,obj.CMD_REG, ByteMask_EN_PULL_UP_REG_3);
            obj.Parent.delayFunctionForHardware(1);
        end

        function enablingPullUpRegister4ForPage(obj)
            ByteMask_EN_PULL_UP_REG_4 = 0x90 ;
            writeRegister(obj.Device,obj.PageRegister, ByteMask_EN_PULL_UP_REG_4);
            obj.Parent.delayFunctionForHardware(1);
        end

        function enablingPullUpRegister5ForPage(obj)
            ByteMask_EN_PULL_UP_REG_5 = 0x80 ;
            writeRegister(obj.Device,obj.PageRegister, ByteMask_EN_PULL_UP_REG_5);
            obj.Parent.delayFunctionForHardware(1);
        end

        function setAuxI2CAddress(obj)
            val = readRegister(obj.Device, obj.Magnetometer_IF_0);
            temp=uint8(bitor(bitand(uint8(val), uint8(0x01)), bitshift(uint8(hex2dec(obj.MagnetometerI2CAddress)),1)));
            writeRegister(obj.Device,obj.Magnetometer_IF_0, temp);
            obj.Parent.delayFunctionForHardware(1);
        end

        function enableMagSetup(obj)
            ByteMask_EN_PULL_UP_REG_5 = 0x83 ;
            val = readRegister(obj.Device, obj.Magnetometer_IF_1);
            writeRegister(obj.Device,obj.Magnetometer_IF_1, bitor(bitand(val, uint8(0x00)), uint8(ByteMask_EN_PULL_UP_REG_5)));
            obj.Parent.delayFunctionForHardware(1);
        end

        function setIFConfig(obj)
            ByteMask = 0x20 ;
            val = readRegister(obj.Device, obj.Magnetometer_IFConfig);
            writeRegister(obj.Device,obj.Magnetometer_IFConfig, bitor(bitand(val, uint8(0x00)), uint8(ByteMask)));
            obj.Parent.delayFunctionForHardware(1);
        end

        function enableSleepMode(obj)
            ByteMask = 0x01 ;
            ByteMask1 = 0x4B;
            val = readRegister(obj.Device, obj.Magnetometer_IF_4);
            val2 = readRegister(obj.Device, obj.Magnetometer_IF_3);
            writeRegister(obj.Device,obj.Magnetometer_IF_4, bitor(bitand(val, uint8(0x00)), uint8(ByteMask)));
            writeRegister(obj.Device,obj.Magnetometer_IF_3, bitor(bitand(val2, uint8(0x00)), uint8(ByteMask1)));
            obj.Parent.delayFunctionForHardware(1);
        end

        function setRepititions(obj)
            ByteMask = 0x04;
            ByteMask1 = 0x51;
            ByteMask2 = 0x0E;
            ByteMask3 = 0x52;
            val = readRegister(obj.Device, obj.Magnetometer_IF_4);
            val2 = readRegister(obj.Device, obj.Magnetometer_IF_3);
            writeRegister(obj.Device,obj.Magnetometer_IF_4, bitor(bitand(val, uint8(0x00)), uint8(ByteMask)));
            writeRegister(obj.Device,obj.Magnetometer_IF_3, bitor(bitand(val2, uint8(0x00)), uint8(ByteMask1)));
            obj.Parent.delayFunctionForHardware(1);
            val = readRegister(obj.Device, obj.Magnetometer_IF_4);
            val2 = readRegister(obj.Device, obj.Magnetometer_IF_3);
            writeRegister(obj.Device,obj.Magnetometer_IF_4, bitor(bitand(val, uint8(0x00)), uint8(ByteMask2)));
            writeRegister(obj.Device,obj.Magnetometer_IF_3, bitor(bitand(val2, uint8(0x00)), uint8(ByteMask3)));
            obj.Parent.delayFunctionForHardware(1);
        end

        function enableForceMode(obj)
            ByteMask = 0x02;
            ByteMask1 = 0x4C;
            val = readRegister(obj.Device, obj.Magnetometer_IF_4);
            val2 = readRegister(obj.Device, obj.Magnetometer_IF_3);
            writeRegister(obj.Device,obj.Magnetometer_IF_4, bitor(bitand(val, uint8(0x00)), uint8(ByteMask)));
            writeRegister(obj.Device,obj.Magnetometer_IF_3, bitor(bitand(val2, uint8(0x00)), uint8(ByteMask1)));
        end

        function setDataReadAddress(obj)
            ByteMask = 0x42;
            val = readRegister(obj.Device, obj.Magnetometer_IF_2);
            writeRegister(obj.Device,obj.Magnetometer_IF_2, bitor(bitand(val, uint8(0x00)), uint8(ByteMask)));
        end

        function setMagConf(obj)
            ByteMask = 0x06;
            val = readRegister(obj.Device, obj.MagnetometerConfRegister);
            writeRegister(obj.Device,obj.MagnetometerConfRegister, bitor(bitand(val, uint8(0x00)), uint8(ByteMask)));
        end

        function enableMagDataMode(obj)
            ByteMask_EN_PULL_UP_REG_5 = 0x00 ;
            val = readRegister(obj.Device, obj.Magnetometer_IF_1);
            writeRegister(obj.Device,obj.Magnetometer_IF_1, bitor(bitand(val, uint8(0x3F)), uint8(ByteMask_EN_PULL_UP_REG_5)));
            obj.Parent.delayFunctionForHardware(1);
        end

        function setMagHigherByte(obj)
            ByteMask = 0x20;
            writeRegister(obj.Device,obj.MagnetometerDataHighRegister,uint8(ByteMask));
        end
    end
end