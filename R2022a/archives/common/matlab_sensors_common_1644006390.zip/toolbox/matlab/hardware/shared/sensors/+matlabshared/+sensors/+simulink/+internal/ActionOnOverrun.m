classdef ActionOnOverrun
   enumeration
      warning, 
      none,
      error
   end
end
