classdef (Hidden) sensorUnit < matlabshared.sensors.coder.matlab.sensorBase
    % Parent class for sensor with single dye (single I2CAddress).coder
    %class
    
    % Copyright 2020 The MathWorks, Inc.
    
    %#codegen
    
    properties(Hidden)
        Device;
    end
    
    properties(Abstract, Access = {?matlabshared.sensors.coder.matlab.sensorInterface, ?matlabshared.sensors.sensorInterface}, Constant)
        I2CAddressList;
    end
    
    properties(Access = protected)
        LastReadTime = 0;
        startTime;
    end
    
    properties(Access = protected,Nontunable)
        BusI2CDriver;
    end
    
    properties(Abstract,Nontunable)
        DoF
    end
    
    methods(Abstract, Access = protected)
        initDeviceImpl(obj) % for initialization which is common to all the sensors on the device (Example: powering up the mag unit in MPU9250)
        initSensorImpl(obj) % for individual sensor inits
        data = convertSensorDataImpl(obj); % to convert the raw bytes obtained while 'peeking' the values from IO Protocol buffer
        data = readSensorDataImpl(obj);
    end
    
    methods
        function obj = sensorUnit(varargin)
            obj@matlabshared.sensors.coder.matlab.sensorBase(varargin{:});
        end
    end
    
    methods
        function [varargout] = read(obj)
            [varargout{:}] = step(obj);
        end
        
        function flush(obj)
            % flush(imu); Equivalent to the System object 'reset' method.
            % It resets 'SamplesRead'.
            reset(obj);
        end
        
        function stop(obj)
            % stop(imu);
            % Equivalent to the System object 'release' method.
            % stop(imu), unlocks the system objects
            release(obj);
        end
    end
    
    methods(Access = protected)
        function init(obj, varargin)
            % At least parameter must be passed
            narginchk(2,inf);
            coder.internal.prefer_const(varargin);
            obj.Parent = varargin{1};
            parms = struct('I2CAddress', uint32(0), 'Bus', uint32(0),...
                'SampleRate', uint32(0), 'SamplesPerRead', uint32(0),...
                'ReadMode', uint32(0),...
                'OutputFormat', uint32(0), 'TimeFormat', uint32(0));
            poptions = struct('CaseSensitivity',false, 'PartialMatching','unique', ...
                'StructExpand',false);
            pstruct = coder.internal.parseParameterInputs(parms,poptions,varargin{2:end});
            % 'Streaming', 'ReadMode', 'OutputFormat', 'SamplesPerRead' and
            % 'TimeFormat' are not supported for code generation
            coder.internal.errorIf(pstruct.ReadMode ~= 0, 'matlab_sensors:general:propertyValueFixedCodegen','ReadMode', 'latest');
            coder.internal.errorIf(pstruct.OutputFormat ~= 0, 'matlab_sensors:general:propertyValueFixedCodegen','OutputFormat', 'matrix');
            coder.internal.errorIf(pstruct.TimeFormat ~= 0, 'matlab_sensors:general:propertyValueFixedCodegen','TimeFormat', 'duration');
            coder.internal.errorIf(pstruct.SamplesPerRead ~= 0, 'matlab_sensors:general:propertyValueFixedCodegen','SamplesPerRead', '1');
            if ~obj.isSimulink
                % the below functions are not required for Simulink. It
                % should be taken care from mask level
                % Validate the 'Bus' parameter if provided by the user
                availableBuses = getAvailableI2CBusIDs(obj.Parent);
                if iscell(availableBuses)
                    bus = coder.internal.getParameterValue(pstruct.Bus, availableBuses{1}, varargin{2:end});
                else
                    bus = coder.internal.getParameterValue(pstruct.Bus, availableBuses(1), varargin{2:end});
                end
            else
                % Bus value validation and default setting will be taken
                % care mask level for Simulink
                bus = coder.internal.getParameterValue(pstruct.Bus, {}, varargin{2:end});
            end
           % For Simulink all validation related to Bus is done at mask level
            if ~obj.isSimulink
                 % For all hwsdk based targets bus value is expected to be numeric
                if isa(obj.Parent, 'matlabshared.sensors.I2CSensorUtilities') || isa(obj.Parent, 'matlabshared.sensors.coder.matlab.I2CSensorUtilities')
                    % Bus is the value which device Object takes as input and
                    % also will be visible to end user. BusI2CDriver is
                    % required for streaming, which uses IO client API
                    % which currently takes numeric value for buses
                    [obj.Bus,obj.BusI2CDriver] = obj.Parent.getValidatedI2CBusInfo(bus);
                else
                    obj.Bus =  obj.validateI2CBus(bus,availableBuses);
                    obj.BusI2CDriver = obj.Bus;
                end
            else
                obj.Bus = bus;
                obj.BusI2CDriver = obj.Bus;
            end
            % Validate the 'I2CAddress' array provided by the user. In case
            % the parameter is absent, select the first element of
            % I2CAddressList property of each sensor unit object as default
            % I2CAddress.
            I2CAddressIn = coder.const(coder.internal.getParameterValue(pstruct.I2CAddress, obj.I2CAddressList(1), varargin{2:end}));
            coder.internal.assert(isnumeric(I2CAddressIn)||iscell(I2CAddressIn)||ischar(I2CAddressIn)||isstring(I2CAddressIn), 'matlab_sensors:general:invalidI2CAddressType');
            % convert the I2C Address into numeric array
            coder.extrinsic('matlabshared.sensors.internal.validateHexParameterRanged');
            % extrinsic function always returns mxArray unless type is
            % specified before
            I2CAddressNumeric = coder.const(matlabshared.sensors.internal.validateHexParameterRanged(I2CAddressIn));
            % Check if the given I2C Address is a possible I2C Address of
            % the particular sensor
            coder.internal.assert(any(ismember(obj.I2CAddressList, I2CAddressNumeric)),...
                'matlab_sensors:general:incorrectI2CAddressSensor', num2str(obj.I2CAddressList));
            obj.I2CAddress = coder.const(I2CAddressNumeric(ismember(I2CAddressNumeric,obj.I2CAddressList)));
            obj.Device = matlabshared.sensors.coder.matlab.device(obj.Parent,obj.I2CAddress,obj.BusI2CDriver);
            % Initialize the sensor device
            initDeviceImpl(obj);
            initSensorImpl(obj);
            % Set the sample rate of the device. It is done after device
            % initialization. Otherwise the changes may not have any
            % effect.
            obj.SampleRate = coder.internal.getParameterValue(pstruct.SampleRate, 100, varargin{2:end});
        end
        
        function varargout = stepImpl(obj)
            % There might be multiple entities to read from a sensor unit.
            % Read all those.
            [data,~,~] = readSensorDataImpl(obj);
            index = 1;
            for i = 1:numel(obj.DoF)
                varargout{i} = data(:,index:index+obj.DoF(i)-1);
                index = index + obj.DoF(i);
            end
            obj.SamplesRead = obj.SamplesRead + obj.SamplesPerRead;
            % To avoid unneccessary function call on hardware, get
            % timestamp from target only if it is requested.
            if nargout == numel(obj.DoF)+1
                timestamp = getCurrentTime(obj.Parent);
                varargout{i+1} = timestamp;
            end
        end
        
        function s = infoImpl(~)
            % Info is not supported for code generation. But if infoImpl is
            % filled in the concrete sensor class, in code generetaion
            % context the same error has to be thrown
            s = [];
            coder.internal.errorIf(true, 'matlab_sensors:general:unsupportedFunctionSensorCodegen', 'info');
        end
        
        function resetImpl(obj)
            obj.SamplesRead = 0;
        end
        
        function releaseImpl(obj)
            obj.SamplesRead = 0;
            closeI2CDev(obj.Device);
        end
        
        function [data, status, timestamp] = readRegisterData(obj, DataRegister, numBytes, precision)
            data = readRegister(obj.Device, DataRegister, numBytes, precision);
            % Put dummy values for status and timestamp. Timestamp is
            % obtained by read (or step) function
            status = 0;
            timestamp = 0;
        end
        
        function num = getNumOutputsImpl(obj)
            % last output is timestamp
            num = numel(obj.DoF)+1;
        end
    end
    
    methods(Access = private)
        function value = validateI2CBus(~, bus, availableBuses)
            % Change the error IDs
            coder.internal.assert(isnumeric(bus) && isscalar(bus) &&...
                isreal(bus) &&  bus>=0 && floor(bus)==bus , ...
                'matlab_sensors:general:invalidBusType', 'I2C', num2str(availableBuses));
            coder.internal.assert(ismember(bus, availableBuses),...
                'matlab_sensors:general:invalidBusValue', 'I2C', num2str(availableBuses));
            value = bus;
        end
    end
end
