
%   Copyright 2017 The MathWorks, Inc.

classdef PrecisionEnum
    enumeration
        int8, uint8, int16, uint16, int32, uint32, int64, uint64
    end
end