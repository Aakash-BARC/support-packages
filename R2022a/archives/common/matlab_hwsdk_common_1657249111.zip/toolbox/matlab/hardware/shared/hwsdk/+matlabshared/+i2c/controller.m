classdef controller < matlabshared.i2c.controller_base
    
    %   Copyright 2017-2022 The MathWorks, Inc.
    properties(GetAccess = public, SetAccess = {?matlabshared.hwsdk.internal.base})
        AvailableI2CBusIDs double
    end
    
    properties(Access = private, Constant = true)
        %         I2C BitRate Range for default 1kHz to 100kHz
        I2CBitRate = [1000 100000];
    end
    
    methods(Access = public, Hidden)
        function obj = controller()
        end
    end
    
    properties(Access = protected)
        I2CDriverObj
    end
    
    methods(Sealed, Access = public)
        function addresses = scanI2CBus(obj, bus)
            try
                % Validations
                if nargin < 2
                    bus = obj.getHwsdkDefaultI2CBusIDHook();
                else
                    bus = obj.validateBus(bus);
                end
                try
                    addresses = obj.scanI2CBusHook(bus);
                catch e
                    if strcmpi(e.identifier,'ioserver:general:CFunctionNotFound')
                        matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:libraryNotUploaded', 'I2C');
                    else
                        throwAsCaller(e);
                    end
                end
                validateAddressTypeHook(obj, addresses);
                c = onCleanup(@() integrateDataHook(obj,bus));
            catch e
                integrateErrorKeyHook(obj,e.identifier);
                throwAsCaller(e);
            end
        end
    end
    
    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base, ?matlabshared.sensors.internal.Accessor})
        
        function buses = getAvailableI2CBusIDs(obj)
            buses = getAvailableI2CBusIDsHook(obj);
        end
    end
    
    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base})
        
        function i2cPinsArray = getAvailableI2CPins(obj)
            i2cPinsArray = getAvailableI2CPinsImpl(obj);
            assert(size(i2cPinsArray, 1)==1);    % row based
            for i = 1:numel(i2cPinsArray)
                assert(isstring(i2cPinsArray(i).SCLPin));
                assert(isstring(i2cPinsArray(i).SDAPin));
            end
        end
        
        function maxI2CAddress = getMaxI2CAddress(obj)
            maxI2CAddress = obj.getMaxI2CAddressHook();
            assert(isnumeric(maxI2CAddress));
            assert(isscalar(maxI2CAddress));
        end
        
        function i2cBitRateLimit = getI2CBitRateLimit(obj, bus)
            i2cBitRateLimit = obj.getI2CBitRateLimitHook(bus);
            assert(size(i2cBitRateLimit, 1)==1); % row based
            assert(isnumeric(i2cBitRateLimit));
            assert(i2cBitRateLimit(1) <= i2cBitRateLimit(2));
        end
        
        function i2cDefaultBitRate = getI2CDefaultBitRate(obj, bus)
            i2cDefaultBitRate = obj.getI2CDefaultBitRateHook(bus);
            assert(isscalar(i2cDefaultBitRate) && isnumeric(i2cDefaultBitRate));
        end
        
        function maxI2CReadWriteBufferSize = getMaxI2CReadWriteBufferSize(obj)
            % Assume 256 byte buffer length
            maxI2CReadWriteBufferSize = obj.getMaxI2CReadWriteBufferSizeHook();
            assert(isnumeric(maxI2CReadWriteBufferSize));
            assert(isscalar(maxI2CReadWriteBufferSize));
        end
        
        function availableI2CPrecisions = getAvailableI2CPrecisions(obj)
            availableI2CPrecisions = obj.getAvailableI2CPrecisionsHook;
            assert(isstring(availableI2CPrecisions));
        end
        
        function i2cDriverObj = getI2CDriverObj(obj)
            i2cDriverObj = getI2CDriverObjImpl(obj);
        end
    end
    
    
    methods(Access = protected)
        function validateAddressTypeHook(~, addresses)
            % ValidateAddressTypeHook(obj, addresses)
            % Validates the datatype of I2C addresses output from
            % scanI2CBus.
            if ~isempty(addresses)
                assert(isstring(addresses));
                assert(size(addresses, 1) == 1); % row based
            end
        end
        
        function buses = getAvailableI2CBusIDsHook(obj)
            i2cPinsArray = obj.getAvailableI2CPins();
            buses = [];
            if numel(i2cPinsArray) > 0
                buses = 1:numel(i2cPinsArray);
            end
        end
        
        function addresses = scanI2CBusHook(obj, bus)
            addresses = scanI2CBus(obj.Protocol,bus-1);
            if 0 == addresses
                pinsI2C = obj.getI2CTerminals;
                sda = obj.getPinsFromTerminals(pinsI2C(1));
                scl = obj.getPinsFromTerminals(pinsI2C(2));
                obj.localizedError('MATLAB:hwsdk:general:scanI2CBusFailure', char(string(bus)), sda{1}, scl{1});
            end
            numAddrsFound = length(addresses);
            if numAddrsFound ~= 0 % devices found
                % Creating a hex string row vector.
                addresses = ("0x" + string(dec2hex(uint8(addresses))))';
            else
                addresses = [];
            end
        end
        
        function bitRateLimit = getI2CBitRateLimitHook(obj, bus)
            % Assume I2C Standard bus speeds
            bitRateLimit = obj.I2CBitRate;
        end
        
        function defaultBitRate = getI2CDefaultBitRateHook(obj, bus)
            bitRateLimit = obj.getI2CBitRateLimitHook(bus);
            targetBitRate = 100000;
            if bitRateLimit(1) <= targetBitRate && bitRateLimit(2) >= targetBitRate
                defaultBitRate = targetBitRate;
            elseif bitRateLimit(1) >= targetBitRate
                defaultBitRate = bitRateLimit(1);
            else
                defaultBitRate = bitRateLimit(2);
            end
        end
        
        function maxI2CAddress = getMaxI2CAddressHook(obj)
            % Assume I2C 7-bit Addressing
            maxI2CAddress = 2^7-1;
        end
        
        function maxI2CReadWriteBufferSize = getMaxI2CReadWriteBufferSizeHook(obj)
            % Assume 256 byte buffer length
            maxI2CReadWriteBufferSize = 2^8;
        end
        
        function availableI2CPrecisions = getAvailableI2CPrecisionsHook(obj)
            availableI2CPrecisions = obj.getAvailablePrecisions;
        end
        
        function i2cDriverObj = getI2CDriverObjImpl(obj)
            % This is the default I2C device driver. Overload this method
            % in the hardware class to return a different driver if
            % required
            if(isempty(obj.I2CDriverObj))
                obj.I2CDriverObj = matlabshared.ioclient.peripherals.I2C;
            end
            i2cDriverObj = obj.I2CDriverObj;
        end
    end
    
    methods(Access = private)
        function busNum = validateBus(obj, bus)
            buses = matlabshared.hwsdk.internal.renderArrayOfIntsToString(obj.AvailableI2CBusIDs);
            try
                if ~(isnumeric(bus) && isreal(bus) && isscalar(bus) && ~isinteger(bus) && bus>=0)
                    obj.localizedError('MATLAB:hwsdk:general:invalidBusType', 'I2C', buses);
                elseif ~ismember(bus, obj.AvailableI2CBusIDs)
                    obj.localizedError('MATLAB:hwsdk:general:invalidBusValue', 'I2C', buses);
                end
            catch e
                throwAsCaller(e);
            end
            busNum = bus;
        end
    end
    
    methods(Access = {?matlabshared.hwsdk.internal.base,?arduino.accessor.UnitTest})
        % Converts HWSDK I2C Bus ID to Hardware Bus Number
        function [busNumber, SCLPin, SDAPin] = getI2CBusInfoHook(obj, hwsdkI2CBusID)
            % GETI2CBUSINFOHOOK Fetches the I2C pins and bus number to be
            % sent to IOServer. Subsequent function to
            % getHwsdkDefaultI2CBusIDHook()
            % Hardwares have to override this function if their default I2C
            % Bus ID is not 1.
            busNumber = hwsdkI2CBusID - 1;
            i2cPins = obj.getAvailableI2CPins();
            SCLPin = i2cPins(hwsdkI2CBusID).SCLPin;
            SDAPin = i2cPins(hwsdkI2CBusID).SDAPin;
        end
        
        function hwsdkDefaultI2CBusID = getHwsdkDefaultI2CBusIDHook(~)
            % GETHWSDKDEFAULTI2CBUSIDHOOK Fetches the default I2C Bus ID.
            % HWSDK defaults the I2C Bus to 1 considering MATLAB indexing
            % which starts with 1.
            % Hardwares can choose to override their default I2C Bus ID to
            % 0 and accordingly override getI2CBusInfoHook() to provide
            % right busNumber values to be sent to IOServer.
            hwsdkDefaultI2CBusID = 1;
        end
        
        % Hardware inherits following methods to modify the property display
        function sclPin = getI2CSCLPinForPropertyDisplayHook(~, pin)
            sclPin = pin;
        end
        
        function sdaPin = getSDAPinForPropertyDisplayHook(~, pin)
            sdaPin = pin;
        end
        
        % Hardware inherits following method to modify the object display
        function showI2CProperties(~, Interface, I2CAddress, Bus, SCLPin, SDAPin, BitRate, showAll)
            if nargin < 2
                showAll = 0;
            end
            
            if showAll
                fprintf('             Interface: "%s"\n', Interface);
            end
            
            fprintf('            I2CAddress: %-1d ("0x%02s")\n', I2CAddress, dec2hex(I2CAddress));
            
            if showAll
                fprintf('                   Bus: %d\n', Bus);
            end
            
            fprintf('                SCLPin: "%s"\n', SCLPin);
            fprintf('                SDAPin: "%s"\n', SDAPin);
            
            if showAll
                fprintf('               BitRate: %d (bits/s)\n', BitRate);
            end
            
            fprintf('\n');
        end
    end
end

% LocalWords:  dev cdev matlabshared CBus CIs
