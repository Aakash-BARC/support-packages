function ports = getAvailablePorts()

%   Copyright 2018 The MathWorks, Inc.

    usbDevices = matlab.hwmgr.internal.hwconnection.USBDeviceEnumerator;
    comPorts = usbDevices.getSerialPorts();
    ports = cellstr(char(comPorts));
end

% LocalWords:  matlabshared
