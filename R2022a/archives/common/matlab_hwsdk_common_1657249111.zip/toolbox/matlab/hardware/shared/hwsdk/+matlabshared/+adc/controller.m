classdef controller < matlabshared.adc.controller_base &...
                      matlabshared.hwsdk.internal.HWSDKDataUtility
    % HWSDK Analog IO Controller
    %
    % All the methods and hooks to interface HWSDK to IOSERVER are implemented here
    %
    % Available methods Syntax:
    % 	data = readVoltage(obj, pin); % Reads a Analog Pin
    % Input Arguments:
    %	obj = Object belonging to target class which inherits from adc.controller
    %   pin = pin to perform read operation on (Eg: 'D13')
    
    %   Copyright 2017-2022 The MathWorks, Inc.
    properties(GetAccess = public, SetAccess = {?matlabshared.hwsdk.internal.base})
        AvailableAnalogPins string
    end
    
    properties(Access = protected)
        % This property holds the analog driver object that provides
        % internal APIs for IO and code generation
        AnalogDriverObj = matlabshared.ioclient.peripherals.AnalogInput();
    end
    
    methods
        % HWSDK displays a string array. Some hardware might require a
        % different type of display. Since a Getter cannot be
        % inherited, a trip is provided here which the individual hardware
        % can make use of.
        function availableAnalogPins = get.AvailableAnalogPins(obj)
            availableAnalogPins =  getAvailableAnalogPinsForPropertyDisplayHook(obj, obj.AvailableAnalogPins);
        end
    end
    
    methods(Access = protected)
        % Hardware inherits this method to modify the property display
        function availableDigitalPins = getAvailableAnalogPinsForPropertyDisplayHook(~, pins)
            availableDigitalPins = pins;
        end
    end
    
    methods (Access = private, Static = true)
        function name = matlabCodegenRedirect(~)
            % Codegen redirector class. During codegen this class will be
            % replaced by matlabshared.coder.controller.controller by MATLAB
            name = 'matlabshared.coder.adc.controller';
        end
    end
    
    methods(Access = public, Hidden)
        function obj = controller(varargin)
        end
    end
    
    methods(Sealed, Access = public)
        function [data, triggerTime] = readVoltage(obj, pin)
            try
                if (nargin < 2)
                    obj.localizedError('MATLAB:minrhs');
                end
                pin = obj.validateAnalogInputVoltagePin(pin);
                readVoltageImpl(obj,pin);
                [data, triggerTime] = obj.readVoltageHook(pin);
                assert(isnumeric(data) && isscalar(data));
                assert(isa(triggerTime, 'datetime'));
                triggerTime.Format = 'd-MMM-y HH:mm:ss.SSS';
                c = onCleanup(@() integrateDataHook(obj));
            catch e
                integrateErrorKeyHook(obj,e.identifier);
                throwAsCaller(e);
            end
        end
    end
    
    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base})
        function availableAnalogPins = getAvailableAnalogInputVoltagePins(obj)
            availableAnalogPins = getAvailableAnalogInputVoltagePinsImpl(obj);
            assert(size(availableAnalogPins, 1)==1 && ...    % row based
                isstring(availableAnalogPins), ...
                'ASSERT: getAvailableAnalogInputVoltagePinsImpl must return a row based array of strings');
        end
        
        function pin = validateAnalogInputVoltagePin(obj, pin)
            if ischar(pin)
                pin = string(pin);
            end
            
            validPins = obj.getAvailableAnalogInputVoltagePins();
            if isscalar(pin) && isstring(pin)
                iPin = find(strcmpi(pin, validPins));
                if ~isempty(iPin)
                    pin = char(validPins(iPin));
                    aliasPin = getPinAliasHook(obj, pin);
                    if ~isempty(aliasPin)
                        pin = aliasPin;
                    end
                    return;
                else
                    matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidPinNumber', char(obj.getBoardNameHook), matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins));
                end
            end
            
            matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidPinType', matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins));
        end
    end
    
    methods(Access = protected)
        function [voltage, triggerTime] = readVoltageHook(obj, pin)
            pinNumber = obj.getPinNumber(pin);
            resolution = getADCResolutionInBitsHook(obj);
            resultDatatype = getDatatypeFromResolutionHook(obj, resolution);
            assert(isstring(resultDatatype));
            % Call the device driver method to read analog voltage. This
            % function internally calls the IO Client function
            counts = readResultAnalogInSingleInternal(obj.AnalogDriverObj, obj.Protocol, pinNumber, resultDatatype);
            maxCount = power(2, resolution) - 1;
            normalizedVoltage = double(typecast(uint8(counts), char(resultDatatype))) / maxCount;
            voltage = normalizedVoltage * getReferenceVoltageImpl(obj);
            triggerTime = datetime('now');
        end
        
        function resolution = getADCResolutionInBitsHook(~)
            resolution = 10;
        end
        
        function resultDatatype = getDatatypeFromResolutionHook(~, resolution)
            if 8 >= resolution
                resultDatatype = "uint8";
            elseif 16 >= resolution
                resultDatatype = "uint16";
            elseif 32 >= resolution
                resultDatatype = "uint32";
            elseif 64 >= resolution
                resultDatatype = "uint64";
            end
        end
    end
end

% LocalWords:  MMM HH
