classdef controller < matlabshared.pwm.controller_base &...
                      matlabshared.hwsdk.internal.HWSDKDataUtility
% HWSDK PWM controller
%
% All the methods and hooks to interface HWSDK to IOSERVER are implemented here
%
% Available methods Syntax:
% 	writePWMVoltage(obj, pin, voltage); % Write PWM duty cycle
% Input Arguments:
%	obj = Object belonging to target class which inherits from pwm.controller
%   pin = Pin on which specified PWM duty cycle needs to be generated on (Eg: 'D13')
%   voltage = Voltage of digital pin's PWM specified as number between 0 and reference volts
%
% Available methods Syntax:
% 	writePWMDutyCycle(obj, pin, dutyCycle); % Write PWM duty cycle
% Input Arguments:
%	obj = Object belonging to target class which inherits from pwm.controller
%   pin = Pin on which specified PWM duty cycle needs to be generated on (Eg: 'D13')
%   dutyCycle = Value of digital pin's PWM duty cycle specified as number between 0 and 1.
				  
%   Copyright 2017-2022 The MathWorks, Inc.

    properties(GetAccess = public, SetAccess = {?matlabshared.hwsdk.internal.base})
        AvailablePWMPins string
    end
    
    properties(Access = protected)
        PWMDriverObj = matlabshared.ioclient.peripherals.PWM;
    end
    
    methods
        % HWSDK displays a string array. Some hardware might require a
        % different type of display. Since a Getter cannot be
        % inherited, a trip is provided here which the individual hardware
        % can make use of.
        function availablePins = get.AvailablePWMPins(obj)
            availablePins =  getAvailablePWMPinsForPropertyDisplayHook(obj, obj.AvailablePWMPins);
        end
    end
    
    methods(Access = protected)
        % Hardware inherits this method to modify the property display
        function availableDigitalPins = getAvailablePWMPinsForPropertyDisplayHook(~, pins)
            availableDigitalPins = pins;
        end
    end
    
    methods(Access = public, Hidden)
        function obj = controller()
        end
    end
    
    methods (Access = private, Static = true)
        function name = matlabCodegenRedirect(~)
            % Codegen redirector class. During codegen this class will be
            % replaced by matlabshared.coder.controller.controller by MATLAB
            name = 'matlabshared.coder.pwm.controller';
        end
    end
       
    methods(Sealed, Access = public)
        function writePWMVoltage(obj, pin, voltage)
            %   Output a PWM signal on a PWM pin.
            %
            %   Syntax:
            %   writePWMVoltage(obj,pin,voltage)
            %
            %   Description:
            %   Write the specified voltage to the specified PWM pin.
            %
            %   Input Arguments:
            %   obj     - Low Cost Hardware Object
            %   pin     - PWM pin number on the hardware (character vector or string)
            %   voltage - PWM signal voltage to write to the PWM pin (double).
            %
            %   See also writeDigitalPin, writePWMDutyCycle            

            try
                if nargin < 3
                    obj.localizedError('MATLAB:minrhs');
                end
                pin = obj.validatePWMPin(pin);
                voltageRange = obj.getPWMVoltageRange();
                range = voltageRange(2) - voltageRange(1);
                voltage = obj.validatePWMVoltage(voltage, voltageRange);
                dutyCycle = voltage/range;
                writePWMVoltageImpl(obj, pin);
                obj.writePWMDutyCycleHook(pin, dutyCycle);
                c = onCleanup(@() integrateDataHook(obj));
            catch e
                integrateErrorKeyHook(obj,e.identifier);
                throwAsCaller(e);
            end
        end
        
        function writePWMDutyCycle(obj, pin, dutyCycle)
            %   Output a PWM signal on a PWM pin.
            %
            %   Syntax:
            %   writePWMDutyCycle(obj,pin,dutyCycle)
            %
            %   Description:
            %   Set the specified duty cycle on the specified PWM pin.
            %
            %   Input Arguments:
            %   obj       - Low Cost Hardware Object
            %   pin       - Digital pin number on the hardware (character vector or string)
            %   dutyCycle - PWM signal duty cycle to write to the PWM pin (double).
            %
            %   See also writeDigitalPin, writePWMVoltage                      
            try
                if nargin < 3
                    obj.localizedError('MATLAB:minrhs');
                end
                pin = obj.validatePWMPin(pin);
                dutyCycle = obj.validatePWMDutyCycle(dutyCycle);
                writePWMDutyCycleImpl(obj, pin);
                obj.writePWMDutyCycleHook(pin, dutyCycle);
                c = onCleanup(@() integrateDataHook(obj));
            catch e
                integrateErrorKeyHook(obj,e.identifier);
                throwAsCaller(e);
            end
        end
    end

    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base})
        function availablePWMPins = getAvailablePWMPins(obj)
            availablePWMPins = obj.getAvailablePWMPinsImpl();
            assert(size(availablePWMPins, 1)==1 && ...    % row based
                   isstring(availablePWMPins), ...
                   'ASSERT: getAvailablePWMPinsImpl must return a row based array of strings');
        end
        
        function voltageRange = getPWMVoltageRange(obj)
            voltageRange = obj.getPWMVoltageRangeImpl();
            assert(all(size(voltageRange)==[1 2]));    % 1x2 range
            assert(isnumeric(voltageRange));
        end
        
        function pin = validatePWMPin(obj, pin)
            if ischar(pin)
                pin = string(pin);
            end
            
            validPins = obj.getAvailablePWMPins();
            if isscalar(pin) && isstring(pin)
                iPin = find(strcmpi(pin, validPins));
                if ~isempty(iPin)
                    pin = validPins(iPin);
                    return;
                else
                	% TODO: Check for pin aliases
                    matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidPinNumber', char(obj.getBoardNameHook), matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins));
                end
            end
            obj.localizedError('MATLAB:hwsdk:general:invalidPinType',  char(matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins)));
        end
        
        function voltage = validatePWMVoltage(obj, volt, voltRange)
            if isnumeric(volt) && isscalar(volt) && ~isnan(volt)
                if (volt < voltRange(1) || volt > voltRange(2))
                    obj.localizedError('MATLAB:hwsdk:general:invalidPWMValue', 'voltage', [num2str(voltRange(1)) ' - ' num2str(voltRange(2))]);
                else
                    voltage = volt;
                end
            else
                voltage = 0;
                obj.localizedError('MATLAB:hwsdk:general:invalidPWMType', 'voltage', [num2str(voltRange(1)) ' - ' num2str(voltRange(2))]);
            end
        end
        
        function dutyCycle = validatePWMDutyCycle(obj, duty)
            if isnumeric(duty) && isscalar(duty) && ~isnan(duty)
                if duty < 0 || duty > 1
                    obj.localizedError('MATLAB:hwsdk:general:invalidPWMValue', 'duty cycle', '0 - 1');
                else
                    dutyCycle = duty;
                end
            else
                dutyCycle = 0;
                obj.localizedError('MATLAB:hwsdk:general:invalidPWMType', 'duty cycle', '0 - 1');
            end
        end
    end
    
    methods(Access = protected)
        function writePWMDutyCycleHook(obj, pin, dutyCycle)
            pinNumber = obj.getPinNumber(pin);
            setPWMDutyCycleInternal(obj.PWMDriverObj, obj.Protocol, pinNumber, dutyCycle);
        end
    end
end