classdef BluetoothDeviceTypeEnum < double
% Copyright 2016-2018 The MathWorks, Inc.
    
   enumeration
      HC05                (0)
      HC06                (1)
   end
end
