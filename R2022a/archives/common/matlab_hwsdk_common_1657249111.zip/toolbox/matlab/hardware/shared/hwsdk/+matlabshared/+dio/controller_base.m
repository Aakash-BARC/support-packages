classdef (Abstract) controller_base < matlabshared.hwsdk.internal.base
%   Digital controller Base class

%   Copyright 2017-2021 The MathWorks, Inc.
    % User Interface
    %
    properties(Abstract, GetAccess = public, SetAccess = {?matlabshared.hwsdk.internal.base})
        AvailableDigitalPins string
    end
    
    methods(Abstract, Access = public)
        data = readDigitalPin(obj, pin);
        writeDigitalPin(obj, pin, data);
    end

    % Developer Interface
    %
    methods(Abstract, Access = {?matlabshared.hwsdk.internal.base})
        availableDigitalPins = getAvailableDigitalPins(obj);
    end
    
    methods(Abstract, Access = protected)
        availableDigitalPins = getAvailableDigitalPinsImpl(obj);
    end
    
    methods(Abstract, Hidden, Access = protected)
        writeDigitalPinImpl(obj,pin,data);
        data = readDigitalPinImpl(obj, pin);
    end
end