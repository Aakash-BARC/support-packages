classdef controller < matlabshared.dio.controller_base &...
                      matlabshared.hwsdk.internal.HWSDKDataUtility
% HWSDK Digital IO controller
%
% All the methods and hooks to interface HWSDK to IOSERVER are implemented here
%
% Available methods Syntax:
% 	data = readDigitalPin(obj, pin); % Reads a Digital Pin
%	writeDigitalPin(obj, pin, data); % writes to a Digital Pin		  
% Input Arguments:
%	obj = Object belonging to target class which inherits from dio.controller (Eg: 'a')
%   pin = pin to perform read or write operation on (Eg: 'D13')
%   data = logical 1/0 or true/false to be written to pin or read from the digital pin
				  
% Copyright 2017-2022 The MathWorks, Inc.
    properties(GetAccess = public, SetAccess = {?matlabshared.hwsdk.internal.base})
        AvailableDigitalPins string
    end
    
    properties(Access = protected)
        % This property holds the Digital IO driver object that provides
        % internal APIs for IO and code generation
        DigitalIODriverObj = matlabshared.ioclient.peripherals.DigitalIO;
    end
    
    methods
        % HWSDK displays a string array. Some hardware might require a
        % different type of display. Since a Getter cannot be
        % inherited, a trip is provided here which the individual hardware
        % can make use of.
        function availablePins = get.AvailableDigitalPins(obj)
            availablePins =  getAvailableDigitalPinsForPropertyDisplayHook(obj, obj.AvailableDigitalPins);
        end
    end
    
    methods(Access = protected)
        % Hardware inherits this method to modify the property display
        function availableDigitalPins = getAvailableDigitalPinsForPropertyDisplayHook(~, pins)
            availableDigitalPins = pins;
        end
    end
    
    methods (Access = private, Static = true)
        function name = matlabCodegenRedirect(~)
            % During codegen this class will be replaced by
            % matlabshared.coder.dio.controller by MATLAB
            name = 'matlabshared.coder.dio.controller';            
        end
    end
    
    methods(Access = public, Hidden)
        function obj = controller(varargin)
        end
    end
       
    methods(Sealed, Access = public)
        function data = readDigitalPin(obj, pin)
            %   Read digital pin value.
            %
            %   Syntax:
            %   value = readDigitalPin(obj,pin)
            %
            %   Description:
            %   Reads logical value from the specified pin on the Arduino hardware.
            %
            %   Input Arguments:
            %   obj - Low cost hardware object
            %   pin - Digital pin number on the Arduino hardware (character vector or string)
            %
            %   Output Arguments:
            %   value - Digital (0, 1) value acquired from digital pin (double)
            %
            %   See also writeDigitalPin
            
            try
                if (nargin < 2)
                    obj.localizedError('MATLAB:minrhs');
                end               
                pin = obj.validateDigitalPin(pin);
                readDigitalPinImpl(obj, pin);
                data = obj.readDigitalPinHook( pin);
                c = onCleanup(@() integrateDataHook(obj));
            catch e
                integrateErrorKeyHook(obj,e.identifier);
                throwAsCaller(e);
            end
        end
        
        function writeDigitalPin(obj, pin, data)
            %   Set or Reset a digital pin.
            %
            %   Syntax:
            %   writeDigitalPin(obj,pin,value)
            %
            %   Description:
            %   Writes specified value to the specified pin on the Arduino hardware.
            %
            %   Input Arguments:
            %   obj   - Low cost hardware object
            %   pin   - Digital pin number on the hardware (character vector or string)
            %   value - Digital value (0, 1) or (true, false) to write to the specified pin (double).
            %
            %   See also readDigitalPin, writePWMVoltage, writePWMDutyCycle
            
            try
                if (nargin < 3)
                    obj.localizedError('MATLAB:minrhs');
                end
                pin = obj.validateDigitalPin(pin);
                data = matlabshared.hwsdk.internal.validateDigitalParameter(data);
                writeDigitalPinImpl(obj,pin,data);
                obj.writeDigitalPinHook(pin, data);
                c = onCleanup(@() integrateDataHook(obj));
            catch e
                integrateErrorKeyHook(obj,e.identifier);
                throwAsCaller(e);
            end
        end
    end

    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base})
        function availableDigitalPins = getAvailableDigitalPins(obj)
            availableDigitalPins = getAvailableDigitalPinsImpl(obj);
            assert(size(availableDigitalPins, 1)==1 && ...    % row based
                   isstring(availableDigitalPins), ...
                   'ASSERT: getAvailableDigitalPinsImpl must return a row based array of strings');
        end
        
        function pin = validateDigitalPin(obj, pin)
            if isstring(pin)
                pin = char(pin);
            end    
            validPins = obj.getAvailableDigitalPins();
            if ischar(pin)
                iPin = find(strcmpi(pin, validPins));
                if ~isempty(iPin)
                    pin = char(validPins(iPin));
                    return;
                else
                    pin = getPinAliasHook(obj, pin);
                    if isempty(pin)
                        validPins = obj.getAvailableDigitalPins();
                        matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidPinNumber', char(obj.getBoardNameHook), matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins)); 
                    end
                end
            else 
                 matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidPinType',  matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins));
            end
        end
    end
    
    methods(Access = protected)
        function data = readDigitalPinHook(obj, pin)
            pinNumber = obj.getPinNumber(pin);
            % ReadDigitalIO internally calls the corresponding IO Clinet
            % method
            % devicedrivers returns logical data, whereas HwSDK returns
            % double data
            data = obj.DigitalIODriverObj.readDigitalPinInternal(obj.Protocol, pinNumber);
        end
        
        function writeDigitalPinHook(obj, pin, value)
            pinNumber = obj.getPinNumber(pin);
            % writeDigitalIO internally calls the corresponding IO Clinet
            % method
            obj.DigitalIODriverObj.writeDigitalPinInternal(obj.Protocol, pinNumber, value)
        end
    end
     
end