function result = sizeof(precision)

%   Copyright 2017 The MathWorks, Inc.

    switch precision
      case {string('int8'), string('uint8'), string('char')}
        result = 1;
      case {string('int16'), string('uint16')}
        result = 2;
      case {string('int32'), string('uint32')}
        result = 4;
      case {string('int64'), string('uint64')}
        result = 8;
      otherwise
        error(['Unknown Precision: ' precision]);
    end
end