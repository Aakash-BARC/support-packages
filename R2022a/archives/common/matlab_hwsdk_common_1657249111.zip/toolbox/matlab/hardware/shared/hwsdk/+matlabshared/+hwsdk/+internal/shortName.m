function name = shortName(className)

%   Copyright 2017 The MathWorks, Inc.

    dots = strfind(className, '.');
    if ~isempty(dots) %#ok<STREMP>
        name = className(dots(end)+1: end);
    else
        name = className;
    end
end