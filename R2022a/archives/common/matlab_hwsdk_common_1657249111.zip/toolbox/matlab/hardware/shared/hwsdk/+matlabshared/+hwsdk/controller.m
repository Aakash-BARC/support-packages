classdef controller < matlabshared.hwsdk.controller_base &...
        matlab.mixin.CustomDisplay &...
        matlabshared.hwsdk.internal.HWSDKDataUtility
    % hwsdk controller class
    
    %   Copyright 2017-2022 The MathWorks, Inc.
    
    properties(GetAccess = public, SetAccess = private)
        AvailablePins string
    end
    
    properties(Access = private, Constant = true)
        Group = 'MATLAB_HARDWARE'
        Prefix = 'MATLABIO_'
    end
    
    properties(Hidden, SetAccess = private)
        Pref
        Args
        
        %Type of communication between Arduino and host
        ConnectionType
        
        %Display debug trace of commands executed on Arduino hardware
        TraceOn
        
        %Force compile and download of Arduino server.
        ForceBuildOn
        
        %Flag of whether uploading a library or not
        LibrariesSpecified
        
        BaudRateSpecified = false
    end
    
    properties(Access = private, Constant = true)
        % major release/minor release - 22aMarch
        LibVersion = '22.1.0';
    end
    
    properties(Access = private)
        IsInitialized = false;
        Connection = [];
        ResourceOwner = [];
        DefaultBaudRate = 115200;
        CurrentLDLibPath
        DefaultTCPIPPort = 9500;
        MinPortValue = 1024;
        MaxPortValue = 65535;
        %Default service UUID to search BLE devices setup with MW infra, same as that specified
        %in IOServer
        ServiceUUID = 'BEC069d9-E1DC-49C4-8A05-F24198ED6E57'
    end
    
    properties(Access = {?matlabshared.hwsdk.internal.base,?matlabshared.sensors.MultiStreamingUtilities})
        Protocol = [];
    end
    
    properties(Access = protected)
        % Flag to indicate whether the hardware is storing debug messages
        % on the host or not
        IsDebugObjectRequired = 0;
    end
    
    methods
        % HWSDK displays a string array. Some hardware might require a
        % different type of display. Since a Getter cannot be
        % inherited, a trip is provided here which the individual hardware
        % can make use of.
        function availablePins = get.AvailablePins(obj)
            availablePins =  getAvailablePinsForPropertyDisplayHook(obj, obj.AvailablePins);
        end
    end
    
    methods(Access = protected)
        % Hardware inherits this method to modify the property display
        function availablePins = getAvailablePinsForPropertyDisplayHook(~, pins)
            availablePins = pins;
        end
    end
    
    methods (Access = private, Static = true)
        function name = matlabCodegenRedirect(~)
            % Codegen redirector class. During codegen the current class
            % will willbe replaced by matlabshared.coder.hwsdk.controller by
            % MATLAB
            name = 'matlabshared.coder.hwsdk.controller';
        end
    end
    
    methods(Sealed, Access = public)
        function varargout = configurePin(obj, pin, config)
            try
                if nargout > 1
                    obj.localizedError('MATLAB:maxlhs');
                end

                if (nargout > 0 && nargin > 2)
                    obj.localizedError('MATLAB:maxrhs');
                end
                if isstring(pin)
                    pin = char(pin);
                end
                if nargin ~= 2
                    % Writing pin configuration
                    obj.configurePinImpl(pin, config);
                else
                    % Reading pin configuration
                    varargout = {obj.configurePinImpl(pin)};
                end
                % configurePin can be called with and without configmode,
                % adding following logic for data integration.
                if  nargin ~= 2
                    dconfig = config;
                else
                    dconfig = 'NA';
                end
                c = onCleanup(@() integrateDataHook(obj, dconfig));
            catch e
                % configurePin can be called with and without configmode,
                % adding following logic for data integration.
                if ~exist('dconfig','var') && nargin ~= 2
                    dconfig = config;
                else
                    dconfig = 'NA';
                end
                integrateErrorKeyHook(obj, e.identifier,dconfig);
                throwAsCaller(e);
            end
        end
        
        function obj = device(parentObj, varargin)
            %DEVICE  Create I2C, SPI or Serial device
            %
            %   Connect to the I2C device at the specified address on the I2C bus
            %
            %   [I2CDevice] = device(obj, 'I2CAddress', ADDRESS) returns
            %   I2C object and connects to an I2C device at the specified address on the default I2C bus of the Arduino hardware
            %
            %   [I2CDevice] = device(obj, 'I2CAddress', ADDRESS, 'NAME', 'VALUE')
            %   returns I2C object and connects to an I2C device at the specified address using  using one or more name-value pair arguments
            %
            %   Example:
            %   i2cDevice = device(obj, 'I2CAddress', address) Connects to an I2C device at the specified address on the default I2C bus of the Arduino hardware.
            %
            %   Examples:
            %       % Construct an arduino object
            %       a = arduino();
            %
            %       % Construct an I2C device object at I2CAddress '0x48'
            %       tmp102 = device(a,'I2CAddress','0x48');
            %
            %       % Construct microbit object
            %       m = microbit();
            %
            %       % Construct an I2C device object at I2CAddress '0x48'
            %       tmp102 = device(m,'I2CAddress','0x25','Bus',1);
            %
            %       % Construct an I2C device object at I2CAddress '0x48'
            %       and BitRate 100KHz
            %       tmp102 = device(a,'I2CAddress','0x48','BitRate',100000);
            %
            %       % Construct an I2C device object at I2CAddress '0x48',
            %       Bus 1 and BitRate 100KHz
            %       tmp102 = device(a,'I2CAddress','0x48','Bus',1,'BitRate',100000);
            %
            %   Connect to the SPI device enabled with a specified Chip Select Pin.
            %
            %   [SPIDevice] = device(obj, 'SPIChipSelectPin', PIN) returns SPI device object and connects to an SPI device enabled with a specified Chip Select Pin
            %   [SPIDevice] = device(obj, 'SPIChipSelectPin', PIN, 'NAME', 'VALUE')
            %   returns SPI device object and connects to an SPI device enabled with a specified Chip Select Pin using one or more name-value pairs
            %
            %   Examples:
            %       % Construct an arduino object
            %       a = arduino();
            %
            %       % Construct an SPI device object with 'D8' as ChipSelectPin
            %       eeprom = device(a,'SPIChipSelectPin','D8');
            %
            %       % Construct microbit object
            %       m = microbit();
            %
            %       % Construct an SPI device object with 'P16' as SPIChipSelectPin
            %       eeprom = device(m,'SPIChipSelectPin','P16');
            %
            %       % Construct SPI device object with 'D8' as ChipSelectPin and 100KHz Bit Rate
            %       eeprom = device(a,'SPIChipSelectPin','D8','BitRate',100000);
            %
            %       % Construct SPI device object with 'D8' as ChipSelectPin and ActiveLevel 'high'
            %       eeprom = device(a,'SPIChipSelectPin','D8','Activelevel','high');
            %
            %       % Construct SPI device object with 'D8' as ChipSelectPin and SPIMode 3
            %       eeprom = device(a,'SPIChipSelectPin','D8','SPIMode',3);
            %
            %       % Construct SPI device object with 'D8' as ChipSelectPin and BitOrder lsbfirst
            %       eeprom = device(a,'SPIChipSelectPin','D8','BitOrder','lsbfirst');
            %
            %   Connection to Serial device connected to TX and RX Pin of Arduino Board
            %
            %   [SERIALDEVICE]= device(obj, 'SerialPort', PORT) creates a connection to Serial Port PORT of the Arduino board and returns Serial device object
            %   [SERIALDEVICE]= device(obj, 'SerialPort', PORT) creates a connection to Serial Port PORT of the Arduino board using one or more name -value pairs and returns Serial device object
            %
            %   Examples:
            %       % Construct an arduino object
            %       a = arduino();
            %
            %       % Construct a Serial device object at Port 1
            %       dev1 = device(a,'SerialPort',1);
            %
            %       % Construct a Serial device object at Port 1 with 100KHz Baud Rate
            %       dev1 = device(a,'SerialPort',1,'BaudRate',100000);
            %
            %       % Construct a Serial device object at Port 1 with 8 Data Bits
            %       dev1 = device(a,'SerialPort',1,'DataBits',8);
            %
            %       % Construct a Serial device object at Port 1 with 1 Stop Bit
            %       dev1 = device(a,'SerialPort',1,'StopBits',1);
            %
            %       % Construct a Serial device object at Port 1 with even parity
            %       dev1 = device(a,'SerialPort',1,'Parity','even');
            %
            %   See also read, write, readRegister, writeRegister, writeRead
            
            try
                obj = getDeviceHook(parentObj, parentObj, varargin{:});
                c = onCleanup(@() integrateDataHook(parentObj, varargin{:}));
            catch e
                integrateErrorKeyHook(parentObj, e.identifier,varargin{:});
                throwAsCaller(e);
            end
        end

        function status = getBLEConnectedStatus(obj)
            % property getter method for Connected property added
            % dynamically for BLE connection type
            assert(obj.ConnectionType== matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE);
            status = obj.Connection.IsTransportLayerConnectedHandle();
        end
    end
    
    methods(Sealed, Hidden)
        % Needs to be callable from device factory (function) which can
        % return I2C, SPI or Serial devices.
        %
        function dev = getDevice(obj, varargin)
            dev = obj.getDeviceHook(varargin{:});
            assert(isa(dev, 'matlabshared.i2c.device') || ...
                isa(dev, 'matlabshared.spi.device') || ...
                isa(dev, 'matlabshared.serial.device'));
        end
    end
    
    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base})
        function name = getHardwareName(obj)
            name = obj.getHarwdareNameImpl();
            assert(isstring(name));
            assert(size(name, 1) == 1);
            assert(size(name, 2) == 1);
        end
        
        function precisions = getAvailablePrecisions(obj)
            precisions = obj.getAvailablePrecisionsHook();
            assert(size(precisions, 1) == 1); % row based
            assert(all(ismember(precisions, matlabshared.hwsdk.internal.precisions)));
        end
        
        function pinNumber = getPinNumber(obj, pin)
            pinNumber = obj.getPinNumberImpl(pin);
            assert(isscalar(pinNumber) && isnumeric(pinNumber));
        end
        
        function pins = getAvailablePins(obj)
            pins = obj.getAvailablePinsImpl();
        end
        
        
        function initHardware(obj, varargin)
            obj.Args = parseInputs(obj, varargin{:});
            
            [isPref, oldPref] = obj.getPreference();
            
            if ~isfield(oldPref, 'ConnectionType') || isempty(oldPref.ConnectionType) || ~isenum(oldPref.ConnectionType)
                isPref = false;
            end
            % No parameters given:
            % If no last preference, auto-detect serial port
            % If last preference exists, reuse last preference if address exists
            % If last preference exists, auto-detect serial if address no longer exists
            if isempty(obj.Args.Address)
                if isPref
                    obj.ConnectionType = oldPref.ConnectionType;
                    if obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                        obj.Args.Port = oldPref.Port;
                    end
                    status = obj.validateAddressExistence(oldPref.ConnectionType, oldPref.Address);
                    if status
                        % Unix systems assigns same serial port for
                        % different boards. Therefore always auto-detect
                        % the serial port to ensure correct board is used
                        % rather than blindly reuse the last preference.
                        %
                        if ~ispc && (obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial)
                            origPort = oldPref.Address;
                            if ~ismac
                                [~, origPort] = system(['readlink ', oldPref.Address]);
                                if ~isempty(origPort)
                                    origPort = ['/dev/',strtrim(origPort)];
                                else
                                    origPort = oldPref.Address;
                                end
                            end
                            boardName = obj.validateSerialPort(origPort);
                            if ~isempty(oldPref.CustomParams)
                                if isfield(oldPref.CustomParams,'Board')
                                    obj.Args.CustomParams.Board = boardName;
                                end
                            end
                        else
                            obj.Args.CustomParams = oldPref.CustomParams;
                        end
                        obj.Args.Address = oldPref.Address;
                        obj.Args.TraceOn = oldPref.TraceOn;
                        obj.Args.BaudRate = oldPref.BaudRate;
                        obj.BaudRateSpecified = false;
                    end
                end
            end
            
            % Address not specified, and preferences data was not current
            %
            if isempty(obj.Args.Address)
                % No previous preference - assume serial connection and auto-detect
                obj.ConnectionType = matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial;
                port = obj.scanSerialPorts();
                if isempty(port)
                    obj.localizedError('MATLAB:hwsdk:general:boardNotDetected', char(obj.getHarwdareNameImpl));
                end
                obj.Args.Address = port;
            end
            
            if ~isempty(obj.Args.CustomParams)
                obj.Args.CustomParams = obj.validateCustomRequiredParamsHook(obj.Args.CustomParams, oldPref);
            end
            
            
            % Add dynamic properties according to connection type
            switch obj.ConnectionType
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                    p = addprop(obj, 'Port');
                    obj.Port = obj.Args.Address;
                    p.SetAccess = 'private';
                    addressKey = obj.Port;
                    % Adding 'BaudRate' property dynamically to the object
                    % when the connection type is serial. This is because
                    % BT and WiFi uses the default baudrate of 115200
                    p = addprop(obj, 'BaudRate');
                    p.GetAccess = 'public';
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth
                    p = addprop(obj, 'DeviceAddress');
                    % Setting Trace to false for BLE, BT, and WiFi as Trace isn't
                    % supported on these transports
                    obj.Args.TraceOn = false;
                    % Setting the Serial BaudRate to default value for BT
                    % as programmable BaudRate is not supported on BT
                    obj.BaudRateSpecified = true;
                    obj.Args.BaudRate = getDefaultBaudRate(obj);
                    obj.DeviceAddress = obj.Args.Address;
                    p.SetAccess = 'private';
                    p = addprop(obj, 'Channel');
                    % The supported Bluetooth devices all have one channel
                    obj.Channel = 1;
                    p.SetAccess = 'private';
                    addressKey = obj.DeviceAddress;
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE 
                    % Setting Trace to false for BLE, BT and WiFi as Trace isn't
                    % supported on these transports
                    obj.Args.TraceOn = false;
                    p1 = addprop(obj, 'Name');
                    p2 = addprop(obj, 'Address');
                    obj.Address = char(obj.Args.Address);
                    Addresses =  obj.bleDeviceList.Address;
                    indices = Addresses.matches(obj.Address);
                    index = find(indices,1);
                    obj.Name = char(obj.bleDeviceList.Name(index));
                    p1.SetAccess = 'private';
                    p2.SetAccess = 'private';
                    p = addprop(obj, 'Connected');
                    p.GetMethod = @getBLEConnectedStatus;
                    p.GetAccess = 'public';
                    p.SetAccess = 'protected';
                    addressKey = obj.Address;
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                    p = addprop(obj, 'DeviceAddress');
                    % Setting Trace to false for BLE, BT and WiFi as Trace isn't
                    % supported on these transports
                    obj.Args.TraceOn = false;
                    obj.DeviceAddress = obj.Args.Address;
                    p.SetAccess = 'private';
                    p = addprop(obj, 'Port');
                    obj.Port = obj.Args.Port;
                    p.SetAccess = 'private';
                    addressKey = obj.DeviceAddress;
            end
            
            % Check if transport layer already occupied, or arduino connection already exists.
            if obj.ConnectionType~=matlabshared.hwsdk.internal.ConnectionTypeEnum.Mock
                if isKey(obj.ConnectionMap, addressKey)
                    storedBoard = obj.ConnectionMap(addressKey);
                    obj.localizedError('MATLAB:hwsdk:general:connectionExists', char(storedBoard), addressKey);
                end
            end
            
            if isa(obj, 'matlabshared.addon.controller')
                obj.Libraries = obj.Args.Libraries;
                obj.LibrariesSpecified = obj.Args.LibrariesSpecified;
            end
            
            if isempty(obj.Args.TraceOn)
                if isPref
                    obj.TraceOn = oldPref.TraceOn;
                else
                    obj.TraceOn = false;
                end
            else
                obj.TraceOn = obj.Args.TraceOn;
            end
            
            obj.ForceBuildOn = obj.Args.ForceBuildOn;
            
             if isequal(obj.ConnectionType, matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial)
                if isempty(obj.Args.BaudRate)
                    if isPref && ~isempty(oldPref.BaudRate) && isequal(obj.ConnectionType,oldPref.ConnectionType)
                        % If BaudRate is not specified as NV pair get and prefs
                        % exist, take the BaudRate from preferences
                        obj.BaudRate = oldPref.BaudRate;
                    else
                        % If BaudRate is not specified as NV pair and no prefs, get
                        % default Baud Rate for the hardware
                        obj.BaudRate = getBaudRateHook(obj);
                    end
                else
                    obj.BaudRate = obj.Args.BaudRate;
                end
             end
            
            if(obj.ConnectionType ~= matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial &&  obj.ConnectionType ~= matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi)
                % setup and initialize host target connection for BT and
                % BLE connections as we might get board related info from
                % server before going to initHardware and build is not
                % happening here
                initServerConnection(obj);
            end
            
            initHardwareHook(obj);
            
            if isa(obj, 'matlabshared.dio.controller')
                obj.AvailableDigitalPins = obj.getAvailableDigitalPins();
            end
            
            if isa(obj, 'matlabshared.adc.controller')
                obj.AvailableAnalogPins = obj.getAvailableAnalogInputVoltagePins();
                availableAnalogPinsHook(obj);
            end
            
            if isa(obj, 'matlabshared.pwm.controller')
                obj.AvailablePWMPins = obj.getAvailablePWMPins();
            end
            
            if isa(obj, 'matlabshared.i2c.controller')
                obj.AvailableI2CBusIDs = obj.getAvailableI2CBusIDs();
            end
            
            if isa(obj, 'matlabshared.spi.controller')
                obj.AvailableSPIBusIDs = obj.getAvailableSPIBusIDs();
            end
            
            if isa(obj, 'matlabshared.serial.controller')
                obj.AvailableSerialPortIDs = obj.getAvailableSerialPortIDs();
            end
            
            obj.AvailablePins = obj.getAvailablePins();
           
            if(obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial || obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi)
                % Setup and initialize host and target connection for
                % Serial and WiFi after the board info is retrieved as we might need
                % to update the server
                initServerConnection(obj);
            end
            % Update preference last to ensure preference is only
            % updated when an arduino object is successfully created
            switch obj.ConnectionType
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                    obj.setPreference(obj.ConnectionType, obj.Port, [], obj.TraceOn, obj.BaudRate, obj.Args.CustomParams);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth
                    obj.setPreference(obj.ConnectionType, obj.DeviceAddress, [],  obj.TraceOn, getDefaultBaudRate(obj),obj.Args.CustomParams);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                    obj.setPreference(obj.ConnectionType, obj.DeviceAddress, obj.Port, obj.TraceOn, [],obj.Args.CustomParams);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE
                    obj.setPreference(obj.ConnectionType,obj.Address, [],obj.TraceOn,[],obj.Args.CustomParams);
            end
        end
    end
    
    methods(Access = private)
        function args = parseInputs(obj, varargin)
            % Parse validate given inputs
            nInputs = numel(varargin);
            
            % Initialize this way instead of 'struct' to avoid empty struct
            args.Address = [];
            args.Libraries = {};
            args.TraceOn = [];
            args.ForceBuildOn = false;
            args.LibrariesSpecified = false;
            args.CustomParams = [];
            args.BaudRate = [];
            
            paramNames = obj.getCustomRequiredParameterNamesHook();
            assert(isstring(paramNames));
            nCustomParams = size(paramNames, 2);
            if nCustomParams > 0
                args.CustomParams = struct();
                for paramName = paramNames
                    args.CustomParams.(char(paramName)) = [];
                end
            end
            
            % No parameters to parse
            if nInputs == 0
                return;
            end
            
            % Step 1 - Derive connection type based on first input parameter
            iParam = 0;
            if nInputs > 0
                iParam = iParam + 1;
                param = varargin{iParam};
                if ~ischar(param) && ~isstring(param)
                    obj.localizedError('MATLAB:hwsdk:general:invalidAddressTypeFirstInput');
                end
                if isstring(param)
                    param = char(param);
                end
                
                [args.Address, args.Port] = obj.validateTransport(param);
            end
            
            % Step 2 - Get board parameter (Port and Board parameters are
            % required before specifying any parameter-value pairs)
            if nInputs > 1
                if nCustomParams > 0
                    if (obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial || obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi)
                        assert(size(paramNames, 1) == 1); % row based
                        for paramName = paramNames
                            iParam = iParam + 1;
                            customParams.(char(paramName)) = varargin{iParam};
                        end
                        args.CustomParams = obj.parseCustomRequiredParamsHook(customParams);
                    else
                        % No configuration is allowed if connection type is BLE and Bluetooth
                        obj.localizedError('MATLAB:hwsdk:general:BoardNameParamUnSupported');
                    end
                end
            end
            
            % Step 3 - Parse additional NV parameters
            if nInputs > 1 + nCustomParams
                iParam = iParam + 1;
                switch obj.ConnectionType
                    case matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                        % Only serial connection type allows
                        % specifying NV pairs for:
                        %    Libraries
                        %    TraceOn
                        %    ForceBuildOn
                        %    BaudRate
                        
                        p = inputParser;
                        p.PartialMatching = true;
                        p.KeepUnmatched = false;
                        if isa(obj, 'matlabshared.addon.controller')
                            addParameter(p, 'Libraries', {''});
                        end
                        addParameter(p, 'TraceOn', false, @islogical);
                        addParameter(p, 'ForceBuildOn', false, @islogical);
                        addParameter(p, 'BaudRate', [], @isnumeric);
                        addCustomNameValueParametersHook(obj, p);
                        % Validate whether the CustomParams is not any one of validParameters e.g TraceOn, Libraries, etc
                        if ~isempty(args.CustomParams)
                            validateCustomParamsHook(obj, args.CustomParams.Board, p.Parameters);
                        end
                        try
                            parse(p, varargin{iParam:end});
                        catch e
                            switch e.identifier
                                case 'MATLAB:InputParser:ParamMissingValue'
                                    message = e.message;
                                    index = strfind(message, '''');
                                    str = message(index(1)+1:index(2)-1);
                                    try
                                        validatestring(str, p.Parameters);
                                    catch
                                        unmatchedCustomParamsErrorHook(obj,str);
                                    end
                                    param = e.message(index(1):index(2));
                                    obj.localizedError('MATLAB:hwsdk:general:missingParamValue', param);
                                case 'MATLAB:InputParser:ParamMustBeChar'
                                    message = e.message;
                                    message(1) = lower(message(1));
                                    unmatchedCustomParamsErrorHook(obj,['- ',message(1:end-1)]);
                                case 'MATLAB:InputParser:UnmatchedParameter'
                                    message = e.message;
                                    index = strfind(message, '''');
                                    param = e.message(index(1):index(2));
                                    unmatchedCustomParamsErrorHook(obj,param);
                                otherwise
                                    inputParserErrorHook(obj,e);
                            end
                        end
                        args.TraceOn = p.Results.TraceOn;
                        args.ForceBuildOn  = p.Results.ForceBuildOn;
                        args.BaudRate = p.Results.BaudRate;
                        if ~isempty(args.BaudRate)
                            obj.BaudRateSpecified = true;
                        end
                        % 3. Validate Libraries data type
                        if isa(obj, 'matlabshared.addon.controller')
                            if ~ischar(p.Results.Libraries) && ~iscell(p.Results.Libraries) && ~iscellstr(p.Results.Libraries) && ~isstring(p.Results.Libraries)
                                obj.localizedError('MATLAB:hwsdk:general:invalidLibrariesType');
                            end
                            % Convert char vector to cell array of char vectors.
                            % For example, 'servo, i2c' -> {'servo', 'i2c'}
                            libs = p.Results.Libraries;
                            if isstring(libs)
                                if length(libs) == 1 % single string
                                    libs = char(libs);
                                else % array of strings
                                    libs = cellstr(libs);
                                end
                            end
                            % Convert cell array of strings to cell array of char vectors.
                            % For example,{"servo", "i2c"} -> {'servo', 'i2c'}
                            if iscell(libs)
                                libs = cellstr(libs);
                            end
                            if ischar(libs) && ~isempty(libs)
                                libs = strtrim(strsplit(libs, ','));
                            end
                            args.Libraries     = libs;
                            args.LibrariesSpecified = true;
                            if isempty(args.Libraries) % User specifies '' or {} or ""
                                args.Libraries = {};
                            elseif isempty(args.Libraries{1}) % User does not specify 'Libraries' nv pair -> default value of {''} or {""}
                                args.Libraries = {};
                                args.LibrariesSpecified = false;
                            end
                        end
                        parseCustomNameValueParametersHook(obj, p);
                    case {matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE, matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth}
                         % No configuration is allowed if connect with BLE
                         % and Bluetooth
                        obj.localizedError('MATLAB:hwsdk:general:wlLibChangeNotSupported',char(getHarwdareNameImpl(obj)), 'Bluetooth');
                    case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                        % Only an optional parameter Port is
                        % allowed to be specified other than board
                        % and address
                        if nInputs > 2 + nCustomParams
                            obj.localizedError('MATLAB:hwsdk:general:wlLibChangeNotSupported',char(getHarwdareNameImpl(obj)), 'WiFi');
                        end
                        try
                            validateattributes(varargin{3},{'double'}, {'finite','scalar','integer','>', 1024})
                            args.Port = varargin{3};
                        catch
                            obj.localizedError('MATLAB:hwsdk:general:invalidWiFiPort',num2str(obj.MinPortValue),num2str(obj.MaxPortValue));
                        end
                end
            end
        end
        
        function initServerConnection(obj)
            switch obj.ConnectionType
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                    obj.Connection = obj.serialHook(obj.Port);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth
                    obj.Connection = obj.bluetoothHook(obj.DeviceAddress, obj.Channel);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                    obj.Connection = obj.tcpClientHook(obj.DeviceAddress, obj.Port);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE
                    obj.Connection = obj.blePeripheralHook(obj.Address);
                otherwise
                    % unsupported
            end
            connectionStatus = initCommunication(obj, obj.Connection);
            
            %%
            serverUpdateAttempted = false;
            if ~connectionStatus
                if ~ obj.BaudRateSpecified && isequal(obj.ConnectionType, matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial)
                    obj.BaudRate = getBaudRateHook(obj);
                end
                if(isa(obj.Protocol.TransportLayer, 'matlabshared.ioclient.transport.TransportLayerAbstract'))
                    % Update server and try again
                    obj.Protocol.TransportLayer.close();
                    if(obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial)
                        obj.Connection.TransportProtocolObj.BaudRate = obj.BaudRate; %update the BaudRate of Connection Object to the current BaudRate, if Baudrate retreived from preferences doesn't work
                    end
                    obj.updateServer();
                    obj.Protocol.TransportLayer.open();
                else
                    % Update server and try again for
                    % ITransport since the API for open and close is
                    % different
                    obj.Protocol.TransportLayer.disconnect();
                    obj.updateServer();
                    obj.Protocol.TransportLayer.connect();
                end
                serverUpdateAttempted = true;
                connectionStatus = initCommunication(obj, obj.Connection);
                if ~connectionStatus
                    obj.localizedError('MATLAB:hwsdk:general:incorrectServerInitialization');
                end
            end
            
            % Check already downloaded libraries if any and retrieve IDs
            % If nothing has been downloaded, update server code
            % If server code exists but libraries are different, update
            % server code.
            %
            % If server code exists and libraries are the same, reuse old
            % library IDs
            %
            if obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                serverStatus = obj.validateServerInfo();
            else
                serverStatus = validateServerInfo(obj,true);
            end
            if ~serverUpdateAttempted && (~serverStatus || obj.ForceBuildOn)
                if obj.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                    if(isa(obj.Protocol.TransportLayer, 'matlabshared.ioclient.transport.TransportLayerAbstract'))
                        obj.Protocol.TransportLayer.close();
                        %buildTimeout = 10; %TODO make this a an arg going into updateServerImpl to timeout Build and Upload
                        
                        obj.updateServerImpl();
                        
                        obj.Protocol.TransportLayer.open();   %% Open Transport Layer
                    else
                        % When Itransport object is directly passed to IO
                        % Protocol API to open and close transport layer is different
                        obj.Protocol.TransportLayer.disconnect();
                        %buildTimeout = 10; %TODO make this a an arg going into updateServerImpl to timeout Build and Upload
                        
                        obj.updateServerImpl();
                        
                        obj.Protocol.TransportLayer.connect();   %% Open Transport Layer
                    end
                    flag = initCommunication(obj, obj.Connection);
                    serverStatus = false;
                    if flag
                        serverStatus = validateServerInfo(obj,true);
                    end
                end
            end
            
            if ~serverStatus
                obj.showFailedUploadErrorHook();
            end
        end
        
        function [flag, serverInfo]  = getServerInfo(obj)
            serverInfo.ioServerVersion = getCoreIOServerVersion(obj.Protocol); % IOServer version Number
            serverInfo.hwSPPKGVersion = getBoardIOServerVersion(obj.Protocol); % HWSPPKG + HWSDK version Number
            serverInfo.boardServerInfo = getBoardInfo(obj.Protocol);
            flag = ~isempty(serverInfo.ioServerVersion) && ~isempty(serverInfo.hwSPPKGVersion) && ~isempty(serverInfo.boardServerInfo);
        end
        
        function libraryList = extractLibrariesFromServerInfo(~,boardServerInfo)
            libList = boardServerInfo.LibraryList;
            libraryList = split(libList,',')';
            if strcmpi(libraryList,"") %If empty string convert to empty cell array, being handled throughout code for empty Libraries
                libraryList = {};
            end
        end
        
        function status = validateServerInfo(obj,varargin)
            if nargin < 2
                dispVersionError = false;
            else
                dispVersionError = varargin{1};
            end
            % Below code is a workaround for Arduino CLI's incapability
            % to report error code when another arduino board's port is
            % given for the current board
            status = false;
            [flag, serverInfo]  = getServerInfo(obj);
            if isa(obj, 'matlabshared.addon.controller')
                libraryList = extractLibrariesFromServerInfo(obj,serverInfo.boardServerInfo);
                if obj.LibrariesSpecified % no libraries are given
                    obj.Libraries = obj.validateLibraries(obj.Libraries); % check existence and completeness of libraries
                else
                    if flag && ~obj.ForceBuildOn% use the retrieved libs from the board
                        obj.Libraries =  libraryList;
                    else % use default libraries
                        obj.Libraries = obj.getDefaultLibraries();
                    end
                end
                flagLib = isempty(setxor(libraryList,obj.Libraries));
            else
                flagLib = true;
            end
            serverTrace = getServerTraceInfoHook(obj,serverInfo.boardServerInfo.CustomData);
            serverBaudRate = str2double(extractAfter(extractBefore(serverInfo.boardServerInfo.CustomData,','),'  '));
            flagserverVersion = validateServerVersionHook(obj,serverInfo,obj.LibVersion);
            if ~flagserverVersion && dispVersionError
                obj.localizedError('MATLAB:hwsdk:general:invalidSPPKGVersion',char(obj.getHarwdareNameImpl),char(obj.getSPPKGBaseCodeImpl));
            end
            if isequal(obj.ConnectionType, matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial)
                baudRate = obj.BaudRate;
            else
                baudRate = getDefaultBaudRate(obj);
            end
            if obj.validateServerInfoHook(serverInfo.boardServerInfo) && ...
                    flag && ... % verify if server config is same as config specified by user to avoid rebuilding everytime
                    flagserverVersion && ...
                    flagLib && ... % check if Libraries on server are same as the ones specified
                    (serverTrace == obj.TraceOn) && ... % check if Trace value is same as what is specified
                    (serverBaudRate == baudRate)  % check with Baudrate is same as what is specified
                if isa(obj, 'matlabshared.addon.controller')
                    obj.LibraryIDs = 0:(length(obj.Libraries)-1); % assign LibIDs
                end
                status = true;
            end
        end
        %%
        function updateLibraryIDs(obj, libNames, libIDs)
            for whichLib = 1:numel(obj.Libraries)
                IndexC = strfind(libNames, obj.Libraries{whichLib});
                obj.LibraryIDs(whichLib) = libIDs(not(cellfun('isempty', IndexC)));
            end
        end
        
        function flag = initCommunication(obj, connectionObj)
            flag = false;
            try
                if isempty(obj.Protocol)
                    if(isprop(obj,'CheckSumEnable') && isequal(obj.CheckSumEnable,1))
                        obj.Protocol = matlabshared.ioclient.IOProtocol(connectionObj,'Checksum','enable');
                    else
                        obj.Protocol = matlabshared.ioclient.IOProtocol(connectionObj);
                    end
                    timeoutval = getIOProtocolTimeoutHook(obj);
                    setIOProtocolTimeout(obj.Protocol,timeoutval);
                    if(obj.IsDebugObjectRequired)
                        debugObj = getDebugObjectHook(obj);
                        if(~isempty(debugObj))
                            % If the hardware class does not implement the
                            % function hook, the return will be an empty
                            % array.
                            obj.Protocol.setDebugObj(debugObj);
                        end
                    end
                end
                resetDelay = obj.getResetDelayHook();
                flag = connect(obj.Protocol, resetDelay);
            catch
            end
        end
        
        function updateServer(obj)
            if obj.ConnectionType ~= matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                hardwareName = getHarwdareNameImpl(obj);
                obj.localizedError('MATLAB:hwsdk:general:wlConnectionFailed', char(hardwareName), char(lower(hardwareName)));
            end
            
            if isa(obj, 'matlabshared.addon.controller')
                if ~obj.LibrariesSpecified
                    obj.Libraries = obj.getDefaultLibraries();
                end
                obj.Libraries = obj.validateLibraries(obj.Libraries); % check existence and completeness of libraries
                obj.LibraryIDs = 0:(length(obj.Libraries)-1);
            end
            
            obj.updateServerImpl();
        end
    end
    
    methods(Access = public, Hidden)
        function obj = controller()
            obj.Pref = obj.Prefix + obj.getHardwareName();
        end
    end
    
    methods(Access = protected)
        function dev = getDeviceHook(obj, varargin)
            if (nargin < 3)
                obj.localizedError('MATLAB:minrhs');
            end
            
            parent = varargin{1};
            if ~isa(parent, 'matlabshared.hwsdk.controller')
                obj.localizedError('MATLAB:hwsdk:general:incompatibleHardware', class(parent));
            end
            
            p = inputParser;
            p.PartialMatching = true;
            
            if isa(parent, 'matlabshared.i2c.controller')
                addParameter(p, 'I2CAddress', [], @(x) any(~isempty(x)));
            end
            
            if isa(parent, 'matlabshared.spi.controller')
                addParameter(p, 'SPIChipSelectPin', '', @(x) any(~isempty(x)));
            end
            
            if isa(parent, 'matlabshared.serial.controller')
                addParameter(p, 'SerialPort', '',@(x) any(~isempty(x)));
            end
            
            if isempty(p.Parameters)
                error('The specified hardware does not support I2C, SPI or Serial.');
            end
            
            try
                parse(p, varargin{2:end});
            catch e
                areMandatoryParametersFilled = find(structfun(@(x) ~isempty(x), p.Results),1);
                if isempty(areMandatoryParametersFilled)
                    switch e.identifier
                        case 'MATLAB:InputParser:ParamMustBeChar'
                            % No manipulation required when there is a number
                            % in place of NV pair Name(char)
                            obj.localizedError('MATLAB:hwsdk:general:requiredNVPairName', 'device', matlabshared.hwsdk.internal.renderCellArrayOfCharVectorsToCharVector(p.Parameters, ', '));
                        otherwise
                            % Extract the string representing the NV pair
                            % Name
                            message = e.message;
                            index = strfind(message, '''');
                            str = message(index(1)+1:index(2)-1);
                            validNVPairName = find(cellfun(@(x) (strcmpi(x, str) == 1), fieldnames(p.Results)),1);
                            if isempty(validNVPairName)
                                % If str is not mandatory NV pair
                                obj.localizedError('MATLAB:hwsdk:general:requiredNVPairName', 'device', matlabshared.hwsdk.internal.renderCellArrayOfCharVectorsToCharVector(p.Parameters, ', '));
                            elseif strcmp(e.identifier, 'MATLAB:InputParser:ParamMissingValue') || strcmp(e.identifier,'MATLAB:InputParser:ArgumentFailedValidation')
                                % If mandatory NV pair Name is available
                                % but no Value is provided
                                obj.localizedError('MATLAB:InputParser:ParamMissingValue', str);
                            end
                    end
                end
                % Rest of the manipulations will be done by the
                % corresponding device peripherals.
            end
            
            % Check which of the parameters (I2C / SPI / Serial) is used
            results = find(structfun(@(x) ~isempty(x), p.Results));
            
            switch p.Parameters{results(1)}
                case "I2CAddress"
                    interface = matlabshared.hwsdk.internal.InterfaceEnum.I2C;
                case "SPIChipSelectPin"
                    interface = matlabshared.hwsdk.internal.InterfaceEnum.SPI;
                case "SerialPort"
                    interface = matlabshared.hwsdk.internal.InterfaceEnum.Serial;
                otherwise
                    % Can't reach here because earlier try-catch manages it
            end
            
            switch interface
                case matlabshared.hwsdk.internal.InterfaceEnum.I2C
                    dev = matlabshared.i2c.device(varargin{:});
                case matlabshared.hwsdk.internal.InterfaceEnum.SPI
                    dev = obj.getSPIDeviceHook(varargin{:});
                case matlabshared.hwsdk.internal.InterfaceEnum.Serial
                    dev = matlabshared.serial.device(varargin{:});
                otherwise
                    % Can't reach here because earlier try-catch manages it
            end
        end

        function dev = getSPIDeviceHook(~,varargin)
            % This is a hook for creating SPI device. The hardware
            % object can override this method for custom SPI
            % implementation.
            dev = matlabshared.spi.device(varargin{:});
        end
        
        %         function remainingArgs = validateCustom(obj, argsIn)
        %             remainingArgs = argsIn{2:end};
        %         end
        
        function supportedTransports = getSupportedTransportsHook(~)
            supportedTransports = enumeration('matlabshared.hwsdk.internal.ConnectionTypeEnum')';
            supportedTransports(supportedTransports == matlabshared.hwsdk.internal.ConnectionTypeEnum.Mock) = [];
        end
        
        function modes = getSupportedModesHook(~)
            modes = ['DigitalInput', 'DigitalOutput', 'AnalogInput', 'PWM', 'SPI', 'I2C', 'Unset'];
        end
        
        function port = getTCPIPPortHook(obj)
            [isPref, oldPref] = getPreference(obj);
            if isPref
                port = oldPref.Port;
            else
                port = obj.DefaultTCPIPPort;
            end
        end
        
        % status = validateServerInfoHook(obj, serverInfo)
        function status = validateServerInfoHook(~, ~)
            status = true;
        end
        
        function status = validateServerVersionHook(obj,serverInfo, ~)
            % The third argument should be defined as HWSDKVersion in the
            % overriding methods. Overriding methods should implement logic to validate LibVersion, HWSDKVersion, and IOServer version
            % verify that SPPKG version number and IOServer version number are in sync, this enables catching errors from different IOServer,HWSDK and HWSPPKG verions
            releaseIndex = strfind(obj.LibVersion,'.');
            % Major.Minor should be same for hwSPPKG and ioServer version
            statusRelease = strncmpi(serverInfo.hwSPPKGVersion,serverInfo.ioServerVersion,releaseIndex(end)-1);
            % hwSPPKG monthly should be greater than ioServer version number
            statusMonthly = str2double(extractAfter(serverInfo.hwSPPKGVersion,releaseIndex(end))) >= str2double(extractAfter(serverInfo.ioServerVersion,releaseIndex(end)));
            status = strcmpi(serverInfo.hwSPPKGVersion, obj.LibVersion) && ...
                     statusRelease && statusMonthly;
        end
        
        function precisions = getAvailablePrecisionsHook(obj) %#ok<MANU>
            % Required for sensors. Used by I2C to read data of number of bytes
            % related to specified precision.
            precisions = ["int8", "uint8", "int16", "uint16", "int32", "uint32", "int64", "uint64"];
        end
        
        % paramNames = getCustomRequiredParameterNamesHook(obj)
        function paramNames = getCustomRequiredParameterNamesHook(~)
            paramNames = strings(0,0);
        end
        
        function addCustomNameValueParametersHook(~, ~)
            % addCustomNameValueParametersHook(obj, inputparserObj)
            % Hardware spkg uses this hook to add additional NV Pairs
            % specific to their application like ArduinoIDELocation for
            % MALTAB Compiler Support for Arduino I/O APIs. Look at the
            % implementation done in arduino.m
        end
        
        function parseCustomNameValueParametersHook(~, ~)
            % parseCustomNameValueParametersHook(obj, inputparserObj)
            % Hardware spkg uses this hook to parse additional NV Pairs
            % specific to their application like ArduinoIDELocation for
            % MALTAB Compiler Support for Arduino I/O APIs. Look at the
            % implementation done in arduino.m
        end
        
        % customParams = parseCustomRequiredParamsHook(obj, customParams)
        function customParams = parseCustomRequiredParamsHook(~, customParams)
            %             error(['Must implement ''parseCustomRequiredParamsHook'' to parse custom parameters (' ...
            %                 char(matlabshared.hwsdk.internal.renderArrayOfStringsToString(obj.getCustomRequiredParameterNamesHook())) ')']);
        end
        
        % customParams = validateCustomRequiredParamsHook(obj, customParams, prefs)
        function customParams = validateCustomRequiredParamsHook(~, customParams, ~)
            %             error(['Must implement ''validateCustomRequiredParamsHook'' to validate custom parameters (' ...
            %                 char(matlabshared.hwsdk.internal.renderArrayOfStringsToString(obj.getCustomRequiredParameterNamesHook())) ')']);
        end
        
        % isValid = validateSerialDeviceHook(obj, vid, pid)
        function isValid = validateSerialDeviceHook(~, ~, ~)
            isValid = false;
        end
        
        % initHardwareHook(obj)
        function initHardwareHook(~)
        end
        
        function baudRate = getBaudRateHook(obj)
            baudRate = getDefaultBaudRate(obj);
        end
        
        % connection = serialHook(obj, varargin)
        function connection = serialHook(~, varargin)
            connection = serial(varargin{:});
        end
        
        % connection = bluetoothHook(obj, varargin)
        function connection = bluetoothHook(~, varargin)
            connection = bluetooth(varargin{:});
        end
        
        % connection = tcpClientHook(obj, varargin)
        function connection = tcpClientHook(~, varargin)
            connection = matlabshared.network.internal.TCPClient(varargin{:});
        end
        
        % connection =  blePeripheralHook(obj, deviceAddress)
        function connection = blePeripheralHook(~,deviceAddress)
            connection = matlabshared.ioclient.transport.TransportLayerUtility.getTransportLayer('ble',deviceAddress);
        end

        % delay = getResetDelayHook(obj)
        function delay = getResetDelayHook(~)
            delay = 0;
        end
        
        function val = getIOProtocolTimeoutHook(~)
          % use default value of 10 seconds
          val = 10;
        end
        
        function showFailedUploadErrorHook(obj)
            obj.localizedError('MATLAB:hwsdk:general:failedUpload', char(obj.getBoardNameHook), obj.Port);
        end
        
        function debugObj = getDebugObjectHook(~)
            % This is a function hook. The hardware class should implment
            % this method to return the debug message object if the debug
            % messages are stored on the host.
            debugObj = [];
        end
        
        function unmatchedCustomParamsErrorHook(obj,param)
            % Hardware spkg can override this hook to parse additional
            % NV Pairs specific to their application like AnalogReference
            % for Arduino I/O APIs in the 'MATLAB:hwsdk:general:invalidParam'
            % error message . Look at the implementation done in arduino.m
            
            if isa(obj, 'matlabshared.addon.controller')
                obj.localizedError('MATLAB:hwsdk:general:invalidParam', param, upper(class(obj)), 'are ''Libraries'',');
            else
                obj.localizedError('MATLAB:hwsdk:general:invalidParam', param, upper(class(obj)), 'are');
            end
        end
        
        
        function serverTrace = getServerTraceInfoHook(~,CustomData)
            serverTrace = str2double(extractAfter(extractAfter(CustomData,','),'  '));
        end
        
        function inputParserErrorHook(~,e)
            % Hardware spkg can override this hook to catch additional
            % errors while parsing user inputs and throw error messages
            % specific to arduino class, Look at the implementation done in arduino.m
            
            throwAsCaller(e);
        end
        % Adding a validateCustomParamsHook hook which is overriden in the
        % Arduino class
        function validateCustomParamsHook(~)
        end
        
        function availableAnalogPinsHook(~)
            % This method manages board specific analog pins
            % Method definition is overridden in arduino
        end
        
        function status = portEmulatorAvailableHook(~, ~) 
            % Hook to be appropriately overridden in the derived classes to
            % validate a pseudo or virtual serial port
            % board specific object and port address should be passed in the
            % overriding hook impl
            % e.g. portEmulatorAvailableHook(arduinoObj, portAddress)
            % e.g  portEmulatorAvailableHook(microbitObj, portAddress)
            status = false;
        end
        
        function list = getBleListHook(obj,varargin)
            % Hook to overridden to detect list of ble devices with a
            % different service UUID than the one specified in HWSDK controller
            % This function returns list of ble devices advertising with the specific service UUID 
            assert(nargin > 1);
            if(nargin == 1)
                list = blelist('Services',obj.ServiceUUID,'Timeout',varargin{1});
            else
                list = blelist('Services',obj.ServiceUUID);
            end
        end        
    end
    
    methods (Access = protected)
        % Custom Display
        function displayScalarObject(obj)
            header = getHeader(obj);
            disp(header);
            
            switch obj.ConnectionType
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                    fprintf('                  Port: "%s"\n', obj.Port);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth
                    fprintf('         DeviceAddress: "%s"\n', obj.DeviceAddress);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE
                    fprintf('               Address: "%s"\n', obj.Address);
                    fprintf('                  Name: "%s"\n', obj.Name);
                    fprintf('             Connected: %d\n', obj.Connected);
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                    fprintf('         DeviceAddress: "%s"\n', obj.DeviceAddress);
                    fprintf('                  Port: %d\n', obj.Port);
                otherwise
            end
            
            obj.displayDynamicPropertiesHook();
            fprintf('         AvailablePins: [%s]\n', matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(obj.AvailablePins));
            if isa(obj, 'matlabshared.dio.controller')
                fprintf('  AvailableDigitalPins: [%s]\n', matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(obj.AvailableDigitalPins));
            end
            if isa(obj, 'matlabshared.pwm.controller')
                fprintf('      AvailablePWMPins: [%s]\n', matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(obj.AvailablePWMPins));
            end
            if isa(obj, 'matlabshared.adc.controller')
                fprintf('   AvailableAnalogPins: [%s]\n', matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(obj.AvailableAnalogPins));
            end
            if isa(obj, 'matlabshared.i2c.controller')
                fprintf('    AvailableI2CBusIDs: %s\n', ...
                    matlabshared.hwsdk.internal.renderArrayOfIntsToString(obj.AvailableI2CBusIDs));
            end
            if isa(obj, 'matlabshared.spi.controller')
                fprintf('    AvailableSPIBusIDs: %s\n', ...
                    matlabshared.hwsdk.internal.renderArrayOfIntsToString(obj.AvailableSPIBusIDs));
            end
            if isa(obj, 'matlabshared.serial.controller')
                fprintf('    AvailableSerialPortIDs: %s\n', ...
                    matlabshared.hwsdk.internal.renderArrayOfIntsToString(obj.AvailableSerialPortIDs));
            end
            
            if isa(obj, 'matlabshared.addon.controller')
                fprintf('             Libraries: [%s]\n', matlabshared.hwsdk.internal.renderArrayOfStringsToString(...
                    obj.Libraries, ', ', 1));
            end
            
            
            % Allow for the possibility of a footer.
            footer = getFooter(obj);
            %footer = matlabshared.hwsdk.internal.footer(inputname(1));
            
            if ~isempty(footer)
                disp(footer);
            end
            fprintf('\n');
        end
        
        function displayDynamicPropertiesHook(obj)
            p = findprop(obj, 'Board');
            if ~isempty(p)
                fprintf('                 Board: "%s"\n', char(obj.getBoardNameHook));
            end
        end
    end
    
    methods(Access = protected)
        function pins = renderPins(~, pins)
            if numel(pins) <= 8
                pins = matlabshared.hwsdk.internal.renderArrayOfStringsToString(pins, ', ', 1);
            else
                pins = ['"' char(pins(1)) '-' char(pins(end)) '"'];
            end
        end
        
        function [address, port] = validateTransport(obj, param)
            supportedTransports = obj.getSupportedTransportsHook();
            assert(size(supportedTransports, 1) == 1); % Row based
            assert(size(supportedTransports, 2) >= 1);
            assert(isa(supportedTransports, 'matlabshared.hwsdk.internal.ConnectionTypeEnum'));
            
            status = false;
            address = [];
            port = [];
            for transport = supportedTransports
                [status, address, port] = obj.validateAddressExistence(transport, param);
                if status
                    obj.ConnectionType = transport;
                    break;
                end
            end
            if ~status
                errorText = '';
                BLEIndex = find(supportedTransports == "BLE");
                supportedTransportsList = supportedTransports;
                if ~isempty(BLEIndex)
                    supportedTransportsList(BLEIndex) = [];
                end
                for transport = supportedTransportsList
                    if isempty(errorText)
                        % Fill the text of first transport
                    elseif transport == supportedTransportsList(end)
                        % Separate last error Text by 'or'
                        % string " or " is used because character
                        % concatenation ignores spaces.
                        errorText = strcat(errorText, " or ");
                    else
                        % Separate all error messages by comma
                        errorText = strcat(errorText, ", ");
                    end
                    errorText = char(strcat(errorText, getErrorText(transport)));
                end
                if ispc || ismac
                    obj.localizedError('MATLAB:hwsdk:general:invalidAddressPCMac', char(obj.getHarwdareNameImpl), param, errorText);
                else
                    obj.localizedError('MATLAB:hwsdk:general:invalidAddressLinux', char(obj.getHarwdareNameImpl), param, errorText);
                end
            end
        end
        
        function [status, address, port] = validateAddressExistence(obj, type, address)
            status = false;
            port = [];
            switch type
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                    if ispc
                        address = upper(address);
                    end
                                   
                    % Check for physical serial ports
                    status = any(ismember(serialportlist, address));
                   
                    % Check if a pseudo port is demanding access
                    if ~any(true(status))
                        status = portEmulatorAvailableHook(obj, address);
                    end
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth
                    if ismac||ispc
                        address = strrep(address, '\', '/');
                        if contains(address, 'btspp://')
                            address = ['btspp://', upper(address(9:end))];
                        end
                        try
                            % Retrieve the bluetoothlist warning state set by the user
                            % Suppress the warnings from bluetoothlist API temporarily
                            % userBTListWarningState has the information of the previous warning state
                            userBTListWarningState = warning('off','MATLAB:bluetooth:bluetoothlist:noDeviceFound');
                            devices = bluetoothlist;
                            status = any(ismember(devices.Name(:), address)) || any(ismember(devices.Address(:), upper(address(9:end))));
                            matches = sum(ismember(devices.Name(:), address));
                            % Return to the warnings from bluetoothlist set by the user
                            warning(userBTListWarningState.state,'MATLAB:bluetooth:bluetoothlist:noDeviceFound');
                            % If bluetooth remote names are passed in and there
                            % are more than one bluetooth device with the same
                            % name detected, throw an error and ask for the
                            % unique address
                            if matches > 1
                                obj.localizedError('MATLAB:hwsdk:general:ambiguousBTName', address);
                            end
                        catch
                            % Return to the warnings from bluetoothlist set by the user
                            warning(userBTListWarningState.state,'MATLAB:bluetooth:bluetoothlist:noDeviceFound');
                            status = 0;
                        end
                    end
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE                    
                    if ismac||ispc
                        if contains(address, ':')
                            address = erase(address,':');
                        end
                        originalState = warning('off','MATLAB:ble:ble:noDeviceFound');
                        try
                            listDevices = getBleListHook(obj,10);
						    warning(originalState.state,'MATLAB:ble:ble:noDeviceFound');
                            address = upper(address);
                            status = any(ismember(upper(listDevices.Name(:)), address))||any(ismember(listDevices.Address(:),address));
                            %check if user provided device name instead of
                            %address
                            matches = (ismember(upper(listDevices.Name(:)), address));
                            % If ble device names are passed in and there
                            % are more than one ble device with the same
                            % name detected, throw an error and ask for the
                            % unique address
                            ambiguousAddress =[];
                            if sum(matches) > 1                               
                                for i = 1:size(matches)
                                    if(matches(i))
                                        ambiguousAddress = [ambiguousAddress listDevices.Address(i)];
                                    end
                                end
                                obj.localizedError('MATLAB:ble:ble:ambiguousDeviceName', address, char(strjoin(ambiguousAddress,',')));
                            end
                            % replace device name with address
                            if sum(matches)
                                name = address;
                                names =  upper(listDevices.Name);
                                indices = names.matches(string(name));
                                index = find(indices,1);
                                address = listDevices.Address(index);
                            end
                            % Transport confirmed to be BLE than save
                            % bledevicelist to use later in workflow
                            if(status)
                                p = addprop(obj,'bleDeviceList');
                                obj.bleDeviceList = listDevices;
                                p.SetAccess = 'private';
                                p.Hidden = true;
                            end
                        catch e
                            warning(originalState.state,'MATLAB:ble:ble:noDeviceFound');
                            if strcmpi(e.identifier,'MATLAB:ble:ble:bluetoothOperationRadioNotAvailable')
                                status = 0;
                            elseif strcmpi(e.identifier,'MATLAB:ble:ble:ambiguousDeviceName')
                                throwAsCaller(e);
                            end
                        end
                    end
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                    % Check for xxx.xxx.xxx.xxx IP address format to
                    % determine whether address is IP or hostname
                    if strcmp(computer, 'GLNXA64')
                        obj.CurrentLDLibPath = getenv('LD_LIBRARY_PATH');
                        setenv('LD_LIBRARY_PATH', '');
                        c = onCleanup(@() cleanup(obj));
                    end
                    if strcmp(computer, 'PCWIN64')
                        cmd = ['ping -n 3 ',address];
                        [pingStatus, result] = system(cmd);
                        % pingStatus = 1 means failed ping
                        % pingStatus = 0 means either success or Destination not reachable (which is again a failed ping)
                        if(isequal(pingStatus, 0))
                            addressMatch = regexpi(result,address);
                            % For a successful ping the address is printed
                            % in the reply messages as well
                            % For messages containing Destination host
                            % unreachable, the IP address of the board is
                            % not present in the reply messages
                            % 3 pings + 2 in the headers
                            if isequal(numel(addressMatch), 5)
                                status = true;
                            end
                        end
                    else
                        cmd = ['ping -c 3 ',address];
                        [~, result] = system(cmd);
                        match = regexpi(result,'ttl=\d+ time=[0-9.]+ ms'); % ttl=56 time=6.42ms
                        status = ~isempty(match);
                    end
                    port = getTCPIPPortHook(obj);
            end
            function cleanup(obj)
                setenv('LD_LIBRARY_PATH', obj.CurrentLDLibPath);
            end
        end
        
        function setPreference(obj, type, address, port, trace, baudRate, customParams)
            % This function add the given input parameters to MATLAB preference
            % if none exists, or set the existing preference with the given
            % input parameters
            newPref.Address = address;
            newPref.CustomParams = customParams;
            newPref.ConnectionType = type;
            newPref.Port = port; % TCPIP port
            newPref.TraceOn = trace;
            newPref.BaudRate = baudRate;
            
            [isPref, oldPref] = getPreference(obj);
            if isPref && ~isequal(newPref, oldPref)
                setpref(obj.Group, char(obj.Pref), newPref);
            elseif ~isPref
                addpref(obj.Group, char(obj.Pref), newPref);
            end
        end
        
        function [isPref, pref] = getPreference(obj)
            isPref = ispref(obj.Group, char(obj.Pref));
            pref = [];
            if isPref
                pref = getpref(obj.Group, char(obj.Pref));
            end
        end
        
        function boardName = validateSerialPort(obj, port)
            origPort = port;
            % Workaround for g1452757 to allow user specify tty port
            % for auto-detection since the HW connection API only
            % detect cu port.
            if ismac
                port = strrep(port, 'tty', 'cu');
            end
            usbdev = matlab.hwmgr.internal.hwconnection.USBDeviceEnumerator;
            [foundPorts, devinfo] = getSerialPorts(usbdev);
            if ~isempty(foundPorts)
                % Workaround to find VID/PID based on given serial port
                index = find(strcmpi(foundPorts, port));
                if ~isempty(index)
                    vid = string(devinfo(index).VendorID);
                    pid = string(devinfo(index).ProductID);
                end
            end
            [isValid, boardName] = obj.validateSerialDeviceHook(vid, pid);
            if ~isValid % No hardware found at the given port
                obj.localizedError('MATLAB:hwsdk:general:invalidPort', char(obj.getHarwdareNameImpl), origPort);
            end
        end
        
        function port = scanSerialPorts(obj)
            port = [];
            usbdev = matlab.hwmgr.internal.hwconnection.USBDeviceEnumerator;
            [foundPorts, devinfo] = getSerialPorts(usbdev);
            for iPort = 1:numel(foundPorts)
                vid = string(devinfo(iPort).VendorID);
                pid = string(devinfo(iPort).ProductID);
                
                try
                    if (obj.validateSerialDeviceHook(vid, pid))
                        port = char(foundPorts{iPort});
                    end
                catch
                    % do nothing
                    % obj.validateSerialDeviceHook is expected to throw an
                    % error if an invalid vid_pid is found on iPort
                    % Keep on scanning
                    % If a valid board is found, 'port' will have a
                    % non-empty port address
                end
            end
        end
        function baudRate = getDefaultBaudRate(obj)
            baudRate = obj.DefaultBaudRate;
        end
    end
    
    methods(Access = {?matlabshared.hwsdk.internal.base,?arduino.accessor.UnitTest})
        function result = isDigitalPin(obj, pin)
            result = ismember(pin, obj.AvailableDigitalPins) || ismember(pin, obj.AvailablePWMPins);
        end
        
        function result = isAnalogPin(obj, pin)
            result = ismember(pin, obj.AvailableAnalogPins);
        end
        
        function boardName = getBoardNameHook(obj)
            boardName = getHarwdareNameImpl(obj);
            assert(isstring(boardName) || ischar(boardName));
        end
        
        function modes = getSupportedModes(obj)
            modes = getSupportedModesHook(obj);
        end
        
        % pin = getPinAliasHook(obj, pin)
        function pin = getPinAliasHook(~, ~)
            pin = [];
        end
    end
end