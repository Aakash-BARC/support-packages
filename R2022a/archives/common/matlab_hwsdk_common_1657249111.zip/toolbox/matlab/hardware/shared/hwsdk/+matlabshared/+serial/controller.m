classdef controller < matlabshared.serial.controller_base
    % hwsdk controller class
    
    %   Copyright 2019-2021 The MathWorks, Inc.
    properties(GetAccess = public, SetAccess = {?matlabshared.hwsdk.internal.base})
        AvailableSerialPortIDs double
    end
    
    properties(Access = private, Constant = true)
        SerialBaudRate = 9600
    end
    
    methods(Access = public, Hidden)
        function obj = controller()
        end
    end
    
    
    properties (Constant, Hidden)
        
        FlowControlOptions = {'none', 'hardware', 'software'} % check if required
        ParityOptions = {'none', 'even', 'odd'}
        StopBitsOptions = [1 1.5 2]
        DataBitOptions = [5 6 7 8 9]
        SupportedBaudRates = [300 600 1200 2400 4800 9600 14400 19200 28800 38400 57600 115200]
        MaxSerialBufferSize = 2^8
        
    end
    
    properties (Constant, Hidden)
        % DefaultTimeout - Default read/write timeout to 10 sec
        DefaultTimeout = 10
    end
    
    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base, ?matlabshared.sensors.internal.Accessor})
        
        function buses = getAvailableSerialPortIDs(obj)
            buses = obj.getAvailableSerialPortIDsHook();
        end
        
    end
    
    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base})
        
        function serialPinsArray = getAvailableSerialPins(obj)
            serialPinsArray = getAvailableSerialPinsImpl(obj);
        end
        
        function maxSerialReadWriteBufferSize = getMaxSerialReadWriteBufferSize(obj)
            maxSerialReadWriteBufferSize = obj.getMaxSerialReadWriteBufferSizeHook();
            assert(isnumeric(maxSerialReadWriteBufferSize));
            assert(isscalar(maxSerialReadWriteBufferSize));
        end
        function supportedBaudRates = getSupportedBaudRates(obj)
            supportedBaudRates =  obj.getSupportedBaudRatesHook;
        end
        
        function supportedParityOptions = getSupportedParity(obj)
            supportedParityOptions=  getSupportedParityHook(obj);
        end
        
        function supportedDataBitOptions = getSupportedDataBits(obj)
            supportedDataBitOptions = getSupportedDataBitsHook(obj);
        end
        
        function supportedStopBitOptions = getSupportedStopBits(obj)
            supportedStopBitOptions = getSupportedStopBitOptionsHook(obj);
        end
        
        function supportedTimeOut = getSupportedTimeOut(~)
            supportedTimeOut = [0 8];
        end
        
        function availableSerialPrecisions = getAvailableSerialPrecisions(obj)
            availableSerialPrecisions = obj.getAvailableSerialPrecisionsHook;
            assert(isstring(availableSerialPrecisions));
        end
        
    end
    
    methods(Access = protected)
        function supportedBaudRates = getSupportedBaudRatesHook(obj)
            supportedBaudRates =  obj.SupportedBaudRates;
        end
        
        function supportedParityOptions = getSupportedParityHook(obj)
            supportedParityOptions=  obj.ParityOptions;
        end
        
        function supportedDataBitOptions = getSupportedDataBitsHook(obj)
            supportedDataBitOptions =  obj.DataBitOptions;
        end
        
        function supportedStopBitOptions = getSupportedStopBitOptionsHook(obj)
            supportedStopBitOptions =  obj.StopBitOptions;
        end
        
        function buses = getAvailableSerialPortIDsHook(obj)
            serialPinsArray = obj.getAvailableSerialPins();
            buses = [];
            if numel(serialPinsArray) > 0
                buses = 1:numel(serialPinsArray);
            end
        end
        
        function defaultBaudRate = getSerialDefaultBaudRateHook(obj)
            defaultBaudRate = obj.SerialBaudRate;
        end
        
        function maxSerialBufferSize = getMaxSerialReadWriteBufferSizeHook(obj)
            % Assume 256 byte buffer length
            maxSerialBufferSize = obj.MaxSerialBufferSize;
        end
        
        function availableSerialPrecisions = getAvailableSerialPrecisionsHook(obj)
            availableSerialPrecisions = [obj.getAvailablePrecisions];
        end
    end
    
end

% LocalWords:  dev cdev matlabshared CBus CIs
