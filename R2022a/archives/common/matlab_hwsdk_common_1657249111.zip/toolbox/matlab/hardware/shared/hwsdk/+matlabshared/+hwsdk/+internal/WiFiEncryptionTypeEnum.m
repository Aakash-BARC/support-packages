classdef WiFiEncryptionTypeEnum < double
%   Copyright 2018 The MathWorks, Inc.
   enumeration
      None      (0)
      WPA       (1) 
      WEP       (2)
   end
end
