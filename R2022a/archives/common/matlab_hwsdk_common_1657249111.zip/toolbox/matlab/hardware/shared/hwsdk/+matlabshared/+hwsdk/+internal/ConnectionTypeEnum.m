
%   Copyright 2017-2021 The MathWorks, Inc.

classdef ConnectionTypeEnum < double
    enumeration
        Serial    (0)
        Bluetooth (1)
        WiFi      (2)
        BLE       (3)
        Mock      (4)
    end
    
    methods
        function errorText = getErrorText(transport)
            m = '';
            errorText = '';
            switch(transport)
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial
                    m = message('MATLAB:hwsdk:general:SerialErrorTextForInvalidAddressPCMac');
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth
                    m = message('MATLAB:hwsdk:general:BluetoothErrorTextForInvalidAddressPCMac');
                case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
                    m = message('MATLAB:hwsdk:general:IPErrorTextForInvalidAddressPCMac');
                otherwise
                    % No error message for Mock.
            end
            if ~isempty(m)
                errorText = m.getString();
            end
        end
    end
end