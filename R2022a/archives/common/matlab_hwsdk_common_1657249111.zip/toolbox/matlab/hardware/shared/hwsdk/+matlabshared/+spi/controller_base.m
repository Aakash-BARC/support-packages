
%   Copyright 2017-2021 The MathWorks, Inc.

classdef (Abstract) controller_base < matlabshared.hwsdk.internal.base
    % User Interface
    %
    properties(Abstract, GetAccess = public, SetAccess = {?matlabshared.hwsdk.internal.base})
        AvailableSPIBusIDs double
    end

    % Developer Interface
    %
    methods(Abstract, Access = {?matlabshared.hwsdk.internal.base})
%         dev = spidev(obj, varargin);
        spiPins = getAvailableSPIPins(obj, bus);
        spiChipSelectPins = getAvailableSPIChipSelectPins(obj, bus);
        numSPIBuses = getNumSPIBuses(obj);
        spiBitRates = getSPIBitRates(obj, bus);
        spiDefaultBitRate = getSPIDefaultBitRate(obj, bus);
        maxSPIReadWriteBufferSize = getMaxSPIReadWriteBufferSize(obj);
    end

    % Implementation Interface
    %
    methods(Abstract, Access = protected)
%         dev = spidevHook(obj, varargin);
        spiPins = getAvailableSPIPinsImpl(obj, bus);
        spiBitRates = getSPIBitRatesImpl(obj, bus);
    end
end

% LocalWords:  dev spidev
