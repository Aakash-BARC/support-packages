
%   Copyright 2017 The MathWorks, Inc.

classdef InterfaceEnum
    enumeration
        I2C, SPI, Analog, Serial
    end
end