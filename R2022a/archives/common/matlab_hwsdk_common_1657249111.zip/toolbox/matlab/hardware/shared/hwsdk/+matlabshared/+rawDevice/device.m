
%   Copyright 2017-2021 The MathWorks, Inc.

classdef (Abstract)device < matlabshared.addon.LibraryBase
    % Developer Interface
    methods(Hidden, Access = public)
        function obj = device(varargin)
            parent = varargin{1};
            if ~isa(parent, 'matlabshared.hwsdk.controller') &&...
               ~isa(parent, 'matlabshared.i2c.controller') &&...
               ~isa(parent, 'matlabshared.spi.controller') &&...
               ~isa(parent, 'matlabshared.serial.controller')
                error(['The first parameter, ''' class(parent) ''' is not a compatible hardware.']);
            end
            
            obj.Parent = parent;
        end
    end
    
    methods (Access = private, Static = true)
        function name = matlabCodegenRedirect(~)
            name = 'matlabshared.coder.rawDevice.device';
        end
    end
    
    methods(Sealed, Access = {?matlabshared.hwsdk.internal.base})
        function init(obj, varargin)
            if (nargin < 1)
                obj.localizedError('MATLAB:minrhs');
            end
            
            parent = varargin{1};
            if ~isa(parent, 'matlabshared.hwsdk.controller')
                error(['' class(parent) ''' is not a compatible hardware for use with this sensor.']);
            end
            obj.Parent = parent;
            
            p = inputParser;
            
            if isa(obj, 'matlabshared.i2c.peripheral') && isa(obj.Parent, 'matlabshared.i2c.controller')
                addParameter(p, 'I2CAddress', []);
            end
            
            if isa(obj, 'matlabshared.spi.peripheral')&& isa(obj.Parent, 'matlabshared.spi.controller')
                addParameter(p, 'SPIChipSelectPin', []);
            end
            
            if isa(obj, 'matlabshared.adc.peripheral')&& isa(obj.Parent, 'matlabshared.adc.controller')
                addParameter(p, 'AnalogPin', []);
            end
            
            parse(p, varargin{2:end});
            
            if sum(structfun(@(x) ~isempty(x), p.Results)) > 1
                error(['Invalid NV pair combination, only ONE of the ' ...
                    '' arduinoio.internal.renderCellArrayOfCharVectorsToCharVector(p.Parameters, ', ') '' ...
                    ' NV pairs may be specified.']);
            end
            
            if sum(structfun(@(x) ~isempty(x), p.Results)) == 0
                if isa(obj, 'matlabshared.i2c.peripheral') && isa(obj.Parent, 'matlabshared.i2c.controller')
                    i2cDeviceAddresses = arrayfun(@(x) matlabshared.hwsdk.internal.validateHexParameterRanged('I2CAddress', x, 0, 255), obj.Parent.scanI2CBus, 'UniformOutput', true);
                    validAddresses = intersect(i2cDeviceAddresses, obj.getI2CAddressSpace);
                    if numel(validAddresses) > 0
                        varargin{end+1} = 'I2CAddress';
                        varargin{end+1} = validAddresses(1);
                    else
                        error('I2C device requires specification of "I2CAddress" parameter');
                    end
                elseif isa(obj, 'matlabshared.spi.peripheral')&& isa(obj.Parent, 'matlabshared.spi.controller')
                    error('SPI device requires specification of "SPIChipSelectPin" parameter');
                elseif isa(obj, 'matlabshared.adc.peripheral')&& isa(obj.Parent, 'matlabshared.adc.controller')
                    error('Analog device requires specification of "AnalogPin" parameter');
                end
            end
            
            results = find(structfun(@(x) ~isempty(x), p.Results));
            
            if isempty(results)
                error(['Protocol parameters missing. Valid parameters are ''' ...
                    arduinoio.internal.renderCellArrayOfCharVectorsToCharVector(p.Parameters, ', ') ...
                    '''']);
            end
            
            if numel(results) > 1
                error(['Invalid protocol parameters specified, only one of the ' ...
                    '' arduinoio.internal.renderCellArrayOfCharVectorsToCharVector(p.Parameters, ', ') '' ...
                    ' name/value pairs may be specified.']);
            end
            
            switch p.Parameters{results(1)}
                case "I2CAddress"
                    interface = "i2c";
                case "SPIChipSelectPin"
                    interface = "spi";
                case "SerialPort"
                    interface = "serial";
                otherwise
                    error('Internal Error');
            end
            
            obj.Interface = interface;
            obj.Device = parent.getDevice(interface, varargin{:});
            
            prop = properties(obj.Device);
            for i = 1:numel(prop)
                p = addprop(obj, prop{i});
                p.Dependent = true;
                p.SetAccess = 'private';
                p.GetMethod = @(x) obj.Device.(prop{i});
            end
        end
    end

    % User Interface
    methods(Abstract, Access = public)
        data = read(obj, varargin);
        write(obj, varargin);
    end
end

% LocalWords:  matlabshared hwsdk spi adc CAddress
