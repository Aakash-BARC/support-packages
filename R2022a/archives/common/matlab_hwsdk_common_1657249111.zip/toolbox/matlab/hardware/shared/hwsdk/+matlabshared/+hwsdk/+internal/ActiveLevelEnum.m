
%   Copyright 2017 The MathWorks, Inc.

classdef ActiveLevelEnum
    enumeration
        low, high
    end
end