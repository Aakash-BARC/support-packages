function vars = workspaceVariableOfClass(className)

%   Copyright 2017 The MathWorks, Inc.

    w = evalin('base', 'who');
    vars = {};
    for i = 1 : size(who, 2)
        if evalin('base', ['isa(' w{i} ', ''' className ''')'])
            vars{end+1} = w{i};
        end
    end
end