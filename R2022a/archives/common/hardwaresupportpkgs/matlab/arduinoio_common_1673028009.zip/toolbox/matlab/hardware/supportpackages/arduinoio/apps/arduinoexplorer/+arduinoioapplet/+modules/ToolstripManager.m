classdef ToolstripManager < matlabshared.mediator.internal.Publisher...
        & matlabshared.mediator.internal.Subscriber...
        & arduinoioapplet.modules.internal.ErrorSource
    %  TOOLSTRIPMANAGER - Module that manages the Toolstrip tab

    %  This module manages the population of the Arduino Explorer app's
    %  toolstrip and handles all the operations related to its widgets.

    % Copyright 2021 The MathWorks, Inc.

    properties (Access=private)
        % Mediator object to share events and listeners across app components
        Mediator

        % Handle to the app toolstrip
        ToolstripHandle

        % Handle to the app container for displaying dialogs
        AppDialogParent

        % Session section
        NewSessionButton

        % View board pinout
        ViewPinoutButton

        % Configure section
        ConfigurePlotButton

        % Record section
        InitialWorkspaceVariableName
        WorkspaceVarLabel
        WorkspaceVarSuffix = 1
        WorkspaceVariableNameEditField
        DurationLabel
        DurationEditField
        StartRecordingButtonText
        StopRecordingButtonText
        StartRecordingDescription
        StopRecordingDescription
        RecordingDisabledDescription
        StartRecordingButtonIcon
        StopRecordingButtonIcon
        DataLoggingButton
        % Status indicating the current state of the record button
        StartRecordStatus

        % Visualize section
        SignalAnalyzerButton

        % Code section
        CodeGenButton

        % Documentation section
        HelpButton

        % Listener handles
        NewSessionButtonListener
        ViewPinoutButtonListener
        ConfigurePlotButtonListener
        DurationFieldListener
        WorkspaceVarFieldListener
        DataLogButtonListener
        SignalAnalyzerButtonListener
        CodeGenButtonListener
    end

    %% Observable properties to trigger property events
    properties(SetObservable)
        % New session section
        UserConfirmedNewSession

        % View Pinout section
        UserClickedViewPinout

        % Configure Section
        UserClickedConfigurePlot

        % Record section
        UserRequestedStartRecording
        UserRequestedStopRecording

        % Analyze section
        UserRequestedSignalAnalyzerLaunch

        % Code section
        UserRequestedCodeGen

        % Property to store the user edited workspace var name
        % and duration
        CurrentDuration
        CurrentWorkspaceVarName

    end

    %% Constant properties used throughout this class
    properties(Constant, Access=private)

        ViewPinoutIcon = "Pinout_24px.png"
        ConfigurePlotIcon = "ConfigurePlot_24px.png"
        StartRecordingIcon = "Record_24px.png"
        CodeGenIcon = "GenerateMATLABScript_24px.png"
        SignalAnalyzerIcon = "SignalAnalyzer_24px.png"
        DefaultDuration = 10
        WorkspaceVarPrefix = "ARD_DATA"

        % Help page link
        HelpButtonLink = "arduinoio/arduinoexplorer_intro"
        HelpButtonTag = "ArduinoExplorerHelp"

        % Toolstrip column widths
        SessionSectionWidth = 50
        PinoutSectionWidth = 50
        ConfigurePlotSectionWidth = 70
        RecordEditFieldWidth = 180
        RecordButtonWidth = 50
        AnalyzeSectionWidth = 60
        CodeGenSectionWidth = 60
    end

    %% Public methods
    methods
        % Constructor
        function obj = ToolstripManager(mediator,toolstripHandle,dialogParent)
            % Call the superclass constructors
            obj@matlabshared.mediator.internal.Publisher(mediator);
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            % Store references
            obj.Mediator = mediator;
            obj.ToolstripHandle = toolstripHandle;
            obj.AppDialogParent = dialogParent;

            % Construct the app toolstrip
            populateToolstrip(obj);
        end

        function subscribeToMediatorProperties(obj,~,~)
            % Events that the toolstrip should listen to
            obj.subscribe('UserConfiguredPins', @(src, event)obj.handlePostPinConfigurations());
            obj.subscribe('IsPinsToRecordEmpty', @(src, event)obj.handlePinsToRecordChange(event));
            obj.subscribe('DataLoggedToWorkspace', @(src, event)obj.handleDataLoggingComplete());
        end

        function varName = getInitialWorkspaceVariableName(obj)
            varName = obj.InitialWorkspaceVariableName;
        end

        function duration = getInitialDuration(obj)
            duration = obj.DefaultDuration;
        end
    end

    %% Callback functions for widget listeners
    methods (Access = private)
        function handleNewSessionRequest(obj)
            % Callback function to handle user request to start a new app session
            warningStr = getString(message("MATLAB:arduinoio:arduinoapp:newSessionConfirmation"));
            selection = matlab.hwmgr.internal.DialogFactory.constructConfirmationDialog(...
                obj.AppDialogParent, ...
                warningStr, getString(message("MATLAB:arduinoio:arduinoapp:appName")),...
                'Options', {'Yes', 'No'},...
                'DefaultOption', 'No');
            result = strcmpi(selection, "Yes");
            if ~isempty(result) && result
                obj.NewSessionButton.Enabled = false;
                obj.DataLoggingButton.Enabled = false;
                obj.DataLoggingButton.Description = obj.RecordingDisabledDescription;
                obj.WorkspaceVarLabel.Enabled = false;
                obj.WorkspaceVariableNameEditField.Enabled = false;
                obj.DurationLabel.Enabled = false;
                obj.DurationEditField.Enabled = false;
                obj.setUserConfirmedNewSessionProperty();
            end
        end

        function handlePinoutRequest(obj)
            % Callback function to execute when user clicks the "View Pinout"
            % toolstrip button
            obj.setUserClickedViewPinoutProperty();
        end

        function handleConfigurePlotRequest(obj)
            % Callback for when user clicked "Configure Plot" toolstrip button
            obj.setUserClickedConfigurePlotProperty();
        end

        function handlePostPinConfigurations(obj)
            % Callback function to handle toolstrip changes after
            % users has configured Arduino pins

            obj.NewSessionButton.Enabled = true;
        end

        function handlePinsToRecordChange(obj,eventData)
            % Function to enable/disable record button based on the
            % pins to record
            if eventData.AffectedObject.IsPinsToRecordEmpty
                obj.DataLoggingButton.Enabled = false;
                obj.DataLoggingButton.Description = obj.RecordingDisabledDescription;
                obj.WorkspaceVarLabel.Enabled = false;
                obj.WorkspaceVariableNameEditField.Enabled = false;
                obj.DurationLabel.Enabled = false;
                obj.DurationEditField.Enabled = false;
            else
                obj.DataLoggingButton.Enabled = true;
                obj.DataLoggingButton.Description = obj.StartRecordingDescription;
                obj.WorkspaceVarLabel.Enabled = true;
                obj.WorkspaceVariableNameEditField.Enabled = true;
                obj.DurationLabel.Enabled = true;
                obj.DurationEditField.Enabled = true;
            end
        end

        function handleDurationChangeRequest(obj,eventData)
            % Function to handle change in duration
            oldValueString = eventData.OldValue;
            newValueString = eventData.NewValue;

            % Remove all whitespaces from the user input string
            newValueString = arduinoioapplet.internal.Utility.removeWhitespace(newValueString);

            % Check for the input if it is in Engineering/Scientific
            % notation and also that it is not 'Inf' and is positive
            newValue = str2double(newValueString);
            [status,errorID] = validateDuration(obj,newValue);
            if status
                % Revert the value in the Duration Edit Field to the old value
                % Create an exception object for the duration not being a
                % number and set the 'ErrorObj' property
                errObj = MException(errorID, getString(message(errorID)));
                obj.setErrorObjProperty(errObj);
                obj.DurationEditField.Value = oldValueString;
                return;
            end
            obj.CurrentDuration = str2double(obj.DurationEditField.Value);
        end

        function handleWorkspaceVarChangeRequest(obj,eventData)
            % Function to handle change in workspace variable name

            oldVarName = eventData.OldValue;
            newVarName = eventData.NewValue;
            if validateWorkspaceVarName(obj,newVarName)
                % Create an exception object and the set the 'ErrorObj' property
                errObj = MException('MATLAB:arduinoio:arduinoapp:invalidVariableName',...
                    getString(message('MATLAB:arduinoio:arduinoapp:invalidVariableName')));
                obj.setErrorObjProperty(errObj);
                % Revert the variable Name to the old valid variable name
                obj.WorkspaceVariableNameEditField.Value = oldVarName;
                return;
            end

            % Check if variable name already exists in workspace
            if arduinoioapplet.internal.Utility.isVariablePresentInBaseWorkspace(newVarName)
                % Create an exception object and the set the 'ErrorObj' property
                errObj = MException('MATLAB:arduinoio:arduinoapp:variableAlreadyExists',...
                    getString(message('MATLAB:arduinoio:arduinoapp:variableAlreadyExists')));
                obj.setErrorObjProperty(errObj);
                % Revert the variable Name to the old valid variable name
                obj.WorkspaceVariableNameEditField.Value = oldVarName;
                return;
            end
            obj.WorkspaceVariableNameEditField.Value = newVarName;
            obj.CurrentWorkspaceVarName = string(obj.WorkspaceVariableNameEditField.Value);
        end

        function handleDataLoggingRequest(obj)
            % Function to start/stop data recording
            if obj.StartRecordStatus
                obj.setLoggingButton('Stop');
                obj.disableWidgetsBeforeRecording();
                obj.setUserRequestedStartRecordingProperty();
            else
                obj.setLoggingButton('Start');
                obj.enableWidgetsAfterRecording();
                obj.setUserRequestedStopRecordingProperty();
            end
        end

        function handleDataLoggingComplete(obj)
            % Function to handle toolstrip widget changes after recording
            % completes without interruption
            obj.updateWorkspaceVariableName();
            obj.setLoggingButton('Start');
            obj.enableWidgetsAfterRecording();
        end

        function handleSignalAnalyzerRequest(obj)
            obj.setUserRequestedSignalAnalyzerLaunchProperty();
        end

        function handleCodeGenRequest(obj)
            % Function to handle the request for generating MATLAB code
            % from the current app state
            setUserRequestedCodeGenProperty(obj);
        end
    end

    %% Internal functions
    methods(Access=private)
        function populateToolstrip(obj)
            % Function to render the Arduino Explorer's toolstrip

            % Set the toolstrip tab name
            obj.ToolstripHandle.Title = getString(message("MATLAB:arduinoio:arduinoapp:appName"));

            % Create toolstrip sections
            createSessionSection(obj);
            createViewPinoutSection(obj);
            createConfigureSection(obj);
            createDataLoggingSection(obj);
            createAnalyzeSection(obj);
            createCodeGenSection(obj);
            createHelpSection(obj);

            % Initialize listeners for toolstrip widgets
            addWidgetEventListeners(obj);
        end

        function createSessionSection(obj)
            % Add Section
            sessionSectionTitle = getString(message("MATLAB:arduinoio:arduinoapp:sessionSectionLabel"));
            sessionSection = obj.ToolstripHandle.addSection(sessionSectionTitle);
            sessionSection.Tag = 'SessionSection';

            % Add Columns to Section
            sessionColumn1 = sessionSection.addColumn('Width',obj.SessionSectionWidth,'HorizontalAlignment','center');
            sessionColumn1.Tag = 'SessionSectionColumn1';

            % Add "New Session" button
            newSessionButtonLabel = getString(message("MATLAB:arduinoio:arduinoapp:sessionButtonLabel"));
            newSessionButtonDescription = getString(message("MATLAB:arduinoio:arduinoapp:sessionButtonDescription"));
            icon = matlab.ui.internal.toolstrip.Icon.NEW_24;
            obj.NewSessionButton = matlab.ui.internal.toolstrip.Button(newSessionButtonLabel, icon);
            obj.NewSessionButton.Enabled = false;
            obj.NewSessionButton.Description = newSessionButtonDescription;
            obj.NewSessionButton.Tag = 'NewSessionButton';
            sessionColumn1.add(obj.NewSessionButton);
        end

        function createViewPinoutSection(obj)
            % Add Section
            pinoutSectionTitle = getString(message("MATLAB:arduinoio:arduinoapp:viewPinoutSectionLabel"));
            pinoutSection = obj.ToolstripHandle.addSection(pinoutSectionTitle);
            pinoutSection.Tag = 'View Pinout Section';

            % Add Columns to Section
            viewPinoutColumn1 = pinoutSection.addColumn('Width',obj.PinoutSectionWidth,'HorizontalAlignment','center');
            viewPinoutColumn1.Tag = 'Pinout Column1';

            % Add "View Pinout" button
            viewPinoutButtonLabel = getString(message("MATLAB:arduinoio:arduinoapp:viewPinoutButtonLabel"));
            viewPinoutButtonDescription = getString(message("MATLAB:arduinoio:arduinoapp:viewPinoutButtonDescription"));
            obj.ViewPinoutButton = matlab.ui.internal.toolstrip.Button(viewPinoutButtonLabel,...
                fullfile(arduinoioapplet.internal.ArduinoAppConstants.IconFolder,obj.ViewPinoutIcon));
            obj.ViewPinoutButton.Description = viewPinoutButtonDescription;
            obj.ViewPinoutButton.Tag = 'ViewPinoutButton';
            viewPinoutColumn1.add(obj.ViewPinoutButton);
        end

        function createConfigureSection(obj)
            % Add Section
            configureSectionTitle = getString(message("MATLAB:arduinoio:arduinoapp:configureSectionLabel"));
            configureSection = obj.ToolstripHandle.addSection(configureSectionTitle);
            configureSection.Tag = 'ConfigureSection';

            % Add Columns to Section
            configureColumn1 = configureSection.addColumn('Width',obj.ConfigurePlotSectionWidth,'HorizontalAlignment', 'center');
            configureColumn1.Tag = 'ConfigureColumn1';

            % Add "Configure Plot" buttons
            configurePlotButtonLabel = getString(message("MATLAB:arduinoio:arduinoapp:configurePlotButtonLabel"));
            configurePlotButtonDescription = getString(message("MATLAB:arduinoio:arduinoapp:configurePlotButtonDescription"));
            icon = matlab.ui.internal.toolstrip.Icon(fullfile(arduinoioapplet.internal.ArduinoAppConstants.IconFolder,obj.ConfigurePlotIcon));
            obj.ConfigurePlotButton = matlab.ui.internal.toolstrip.Button(configurePlotButtonLabel, icon);
            obj.ConfigurePlotButton.Description = configurePlotButtonDescription;
            obj.ConfigurePlotButton.Tag = 'ConfigurePlotButton';
            configureColumn1.add(obj.ConfigurePlotButton);
        end

        function createDataLoggingSection(obj)
            % Add Section
            dataLoggingSectionTitle = getString(message("MATLAB:arduinoio:arduinoapp:recordSectionLabel"));
            dataLoggingSection = obj.ToolstripHandle.addSection(dataLoggingSectionTitle);
            dataLoggingSection.Tag = 'RecordSection';

            % Add columns to section
            dataLoggingColumn1 = dataLoggingSection.addColumn('HorizontalAlignment','right');
            dataLoggingColumn1.Tag = "DataLoggingColumn1";
            dataLoggingSection.addColumn('Width',4);

            dataLoggingColumn2 = dataLoggingSection.addColumn('Width',obj.RecordEditFieldWidth,'HorizontalAlignment','left');
            dataLoggingColumn2.Tag = "DataLoggingColumn2";
            dataLoggingSection.addColumn('Width',10);

            dataLoggingColumn3 = dataLoggingSection.addColumn('Width',obj.RecordButtonWidth,'HorizontalAlignment','center');
            dataLoggingColumn3.Tag = "DataLoggingColumn3";

            % Add Log to workspace Label
            logToWorkspaceLabelStr = getString(message("MATLAB:arduinoio:arduinoapp:workspaceVarLabel"));
            obj.WorkspaceVarLabel = matlab.ui.internal.toolstrip.Label(logToWorkspaceLabelStr);
            obj.WorkspaceVarLabel.Tag = 'WorkspaceVariableLabel';
            obj.WorkspaceVarLabel.Description = getString(message("MATLAB:arduinoio:arduinoapp:workspaceVarFieldDescription"));
            obj.WorkspaceVarLabel.Enabled = false;
            dataLoggingColumn1.add(obj.WorkspaceVarLabel);

            % Add Workspace Variable Name Edit Field
            % Check if the default variable name is already present in the
            % workspace. If yes then have the next valid variable name.
            varName = obj.getNextAvailableVariableName(obj.WorkspaceVarPrefix);
            obj.InitialWorkspaceVariableName = varName;
            workspaceVariableNameDescription = getString(message("MATLAB:arduinoio:arduinoapp:workspaceVarFieldDescription"));
            obj.WorkspaceVariableNameEditField = matlab.ui.internal.toolstrip.EditField(obj.InitialWorkspaceVariableName);
            obj.WorkspaceVariableNameEditField.Description = workspaceVariableNameDescription;
            obj.WorkspaceVariableNameEditField.Tag = 'VariableNameEditField';
            obj.WorkspaceVariableNameEditField.Enabled = false;
            dataLoggingColumn2.add(obj.WorkspaceVariableNameEditField);

            % Add Duration Label
            durationLabelStr = getString(message("MATLAB:arduinoio:arduinoapp:durationLabel"));
            durationDescription = getString(message("MATLAB:arduinoio:arduinoapp:durationFieldDescription"));
            obj.DurationLabel = matlab.ui.internal.toolstrip.Label(durationLabelStr);
            obj.DurationLabel.Tag = 'DurationLabel';
            obj.DurationLabel.Description = durationDescription;
            obj.DurationLabel.Enabled = false;
            dataLoggingColumn1.add(obj.DurationLabel);

            % Add Duration Edit Field
            obj.DurationEditField = matlab.ui.internal.toolstrip.EditField(num2str(obj.DefaultDuration));
            obj.DurationEditField.Description = durationDescription;
            obj.DurationEditField.Tag = 'DurationEditField';
            obj.DurationEditField.Enabled = false;
            dataLoggingColumn2.add(obj.DurationEditField);

            % Add Start/Stop recording button
            obj.StartRecordingButtonText = getString(message("MATLAB:arduinoio:arduinoapp:recordButtonLabel"));
            obj.StartRecordingDescription = getString(message("MATLAB:arduinoio:arduinoapp:recordButtonDescription"));
            obj.RecordingDisabledDescription = getString(message("MATLAB:arduinoio:arduinoapp:recordButtonDisabledDescription"));
            obj.StartRecordingButtonIcon = matlab.ui.internal.toolstrip.Icon(fullfile(arduinoioapplet.internal.ArduinoAppConstants.IconFolder,obj.StartRecordingIcon));
            obj.StopRecordingButtonText = getString(message("MATLAB:arduinoio:arduinoapp:stopRecordButtonLabel"));
            obj.StopRecordingDescription = getString(message("MATLAB:arduinoio:arduinoapp:stopRecordButtonDescription"));
            obj.StopRecordingButtonIcon = matlab.ui.internal.toolstrip.Icon.STOP_24;

            obj.DataLoggingButton = matlab.ui.internal.toolstrip.Button(obj.StartRecordingButtonText, obj.StartRecordingButtonIcon);
            obj.DataLoggingButton.Description = obj.RecordingDisabledDescription;
            obj.DataLoggingButton.Enabled = false;
            obj.DataLoggingButton.Tag = 'StartRecordingButton';
            dataLoggingColumn3.add(obj.DataLoggingButton);

            obj.StartRecordStatus = true;
        end

        function createAnalyzeSection(obj)
            % Add Section
            analyzeSectionTitle = getString(message("MATLAB:arduinoio:arduinoapp:analyzeSectionLabel"));
            analyzeSection = obj.ToolstripHandle.addSection(analyzeSectionTitle);
            analyzeSection.Tag = 'AnalyzeSectionTitle';

            % Add Columns to Section
            analyzeColumn1 = analyzeSection.addColumn('Width',obj.AnalyzeSectionWidth,'HorizontalAlignment', 'center');
            analyzeColumn1.Tag = 'AnalyzeSectionColumn1';

            % Add Signal Analyzer launch button
            signalAnalyzerButtonLabel = getString(message("MATLAB:arduinoio:arduinoapp:analyzeButtonLabel"));
            signalAnalyzerButtonDescription = getString(message("MATLAB:arduinoio:arduinoapp:analyzeButtonDescription"));
            icon = matlab.ui.internal.toolstrip.Icon(fullfile(arduinoioapplet.internal.ArduinoAppConstants.IconFolder,obj.SignalAnalyzerIcon));
            obj.SignalAnalyzerButton = matlab.ui.internal.toolstrip.Button(signalAnalyzerButtonLabel, icon);
            obj.SignalAnalyzerButton.Enabled = false;
            obj.SignalAnalyzerButton.Description = signalAnalyzerButtonDescription;
            obj.SignalAnalyzerButton.Tag = 'SignalAnalyzerButton';
            analyzeColumn1.add(obj.SignalAnalyzerButton);
        end

        function createCodeGenSection(obj)
            % Add Section
            codeGenSectionTitle = getString(message("MATLAB:arduinoio:arduinoapp:codeSectionLabel"));
            codeGenSection = obj.ToolstripHandle.addSection(codeGenSectionTitle);
            codeGenSection.Tag = 'CodeGenTitle';

            % Add Columns to Section
            codeGenColumn1 = codeGenSection.addColumn('Width',obj.CodeGenSectionWidth,'HorizontalAlignment', 'center');
            codeGenColumn1.Tag = 'CodeGenColumn1';

            % Add Current State code gen button
            codeGenButtonLabel = getString(message("MATLAB:arduinoio:arduinoapp:codeGenButtonLabel"));
            codeGenDescription = getString(message("MATLAB:arduinoio:arduinoapp:codeGenButtonDescription"));
            icon = matlab.ui.internal.toolstrip.Icon(fullfile(arduinoioapplet.internal.ArduinoAppConstants.IconFolder,obj.CodeGenIcon));
            obj.CodeGenButton = matlab.ui.internal.toolstrip.Button(codeGenButtonLabel, icon);
            obj.CodeGenButton.Enabled = true;
            obj.CodeGenButton.Description = codeGenDescription;
            obj.CodeGenButton.Tag = 'GenerateCodeButton';
            codeGenColumn1.add(obj.CodeGenButton);
        end

        function createHelpSection(obj)
            % Function to create help button in the app's quick access bar
            % till g2501071 is addressed.
            % The help button is shared between app tabs.
            try
                % Since there is no way to check if the help button exists,
                % remove the button if it exists and create a new help button.
                obj.AppDialogParent.removeQabControl(obj.HelpButtonTag);
            catch
            end
            obj.HelpButton = matlab.ui.internal.toolstrip.qab.QABHelpButton();
            obj.HelpButton.DocName = obj.HelpButtonLink;
            obj.HelpButton.Tag = obj.HelpButtonTag;
            obj.AppDialogParent.add(obj.HelpButton);
        end

        function status = validateWorkspaceVarName(~,varName)
            % Function to validate the user specified workspace variable name

            status = 0;
            % Check if user has specified a valid MATLAB variable name
            if ~isvarname(varName)
                status = 1;
            end
        end

        function [status,errorID] = validateDuration(~,duration)
            % Function to validate the user specified duration
            status = 0;
            errorID = [];
            if  isnan(duration) || ~isreal(duration) || isinf(duration) || duration <= 0
                if isnan(duration)
                    errorID = 'MATLAB:arduinoio:arduinoapp:dataNotNumeric';
                elseif ~isreal(duration)
                    errorID = 'MATLAB:arduinoio:arduinoapp:dataNotReal';
                elseif isinf(duration)
                    errorID = 'MATLAB:arduinoio:arduinoapp:dataInf';
                else
                    errorID = 'MATLAB:arduinoio:arduinoapp:dataNegative';
                end

                status = 1;
            end
        end

        function resetVariableNameSuffix(obj)
            obj.WorkspaceVarSuffix = 1;
        end

        function updateWorkspaceVariableName(obj)
            % Function to update the workspace variable name after recording
            varName = obj.WorkspaceVarPrefix;
            nextVarName = obj.getNextAvailableVariableName(varName);
            obj.WorkspaceVariableNameEditField.Value = nextVarName;
            obj.CurrentWorkspaceVarName = nextVarName;
        end

        function varName = getNextAvailableVariableName(obj, variableNamePrefix)
            % Function to get the next valid workspace variable name
            resetVariableNameSuffix(obj);
            varNameValidFlag = false;
            while ~varNameValidFlag
                varName = variableNamePrefix+"_"+num2str(obj.WorkspaceVarSuffix);
                if ~obj.validateWorkspaceVarName(varName) &&...
                        ~arduinoioapplet.internal.Utility.isVariablePresentInBaseWorkspace(varName)
                    varNameValidFlag = true;
                end
                obj.WorkspaceVarSuffix = obj.WorkspaceVarSuffix + 1;
            end
        end

        function addWidgetEventListeners(obj)
            % All event listeners that need to be added to the toolstrip
            obj.NewSessionButtonListener = obj.NewSessionButton.listener('ButtonPushed',@(src,event)obj.handleNewSessionRequest());
            obj.ViewPinoutButtonListener = obj.ViewPinoutButton.listener('ButtonPushed',@(src,event)obj.handlePinoutRequest());
            obj.ConfigurePlotButtonListener = obj.ConfigurePlotButton.listener('ButtonPushed',@(src,event)obj.handleConfigurePlotRequest());
            obj.DurationFieldListener = obj.DurationEditField.listener('ValueChanged',@(src,event)obj.handleDurationChangeRequest(event.EventData));
            obj.WorkspaceVarFieldListener = obj.WorkspaceVariableNameEditField.listener('ValueChanged',@(src,event)obj.handleWorkspaceVarChangeRequest(event.EventData));
            obj.DataLogButtonListener = obj.DataLoggingButton.listener('ButtonPushed',@(src,event)obj.handleDataLoggingRequest());
            obj.SignalAnalyzerButtonListener = obj.SignalAnalyzerButton.listener('ButtonPushed',@(src, event)obj.handleSignalAnalyzerRequest());
            obj.CodeGenButtonListener = obj.CodeGenButton.listener('ButtonPushed',@(src, event)obj.handleCodeGenRequest());
        end
    end

    %% Set observable property values
    methods(Access = private)

        function setUserConfirmedNewSessionProperty(obj)
            obj.UserConfirmedNewSession = true;
        end

        function setUserClickedViewPinoutProperty(obj)
            obj.UserClickedViewPinout = true;
        end

        function setUserClickedConfigurePlotProperty(obj)
            obj.UserClickedConfigurePlot = true;
        end

        function setUserRequestedStartRecordingProperty(obj)
            obj.UserRequestedStartRecording = true;
        end

        function setUserRequestedStopRecordingProperty(obj)
            obj.UserRequestedStopRecording = true;
        end

        function setUserRequestedSignalAnalyzerLaunchProperty(obj)
            obj.UserRequestedSignalAnalyzerLaunch = true;
        end

        function setUserRequestedCodeGenProperty(obj)
            obj.UserRequestedCodeGen = true;
        end

        function setLoggingButton(obj,status)
            % Function to set the state of the record button
            if strcmpi(status, 'Stop')
                obj.StartRecordStatus = false;
                obj.DataLoggingButton.Icon = obj.StopRecordingButtonIcon;
                obj.DataLoggingButton.Text = obj.StopRecordingButtonText;
                obj.DataLoggingButton.Description = obj.StopRecordingDescription;

            elseif strcmpi(status, 'Start')
                obj.StartRecordStatus = true;
                obj.DataLoggingButton.Icon = obj.StartRecordingButtonIcon;
                obj.DataLoggingButton.Text = obj.StartRecordingButtonText;
                obj.DataLoggingButton.Description = obj.StartRecordingDescription;
            end
        end

        function disableWidgetsBeforeRecording(obj)
            % Duration and variable name Section

            obj.NewSessionButton.Enabled = false;
            obj.DurationEditField.Enabled = false;
            obj.DurationLabel.Enabled = false;
            obj.WorkspaceVarLabel.Enabled = false;
            obj.WorkspaceVariableNameEditField.Enabled = false;
            obj.SignalAnalyzerButton.Enabled = false;
            obj.CodeGenButton.Enabled = false;
        end

        function enableWidgetsAfterRecording(obj)
            % Duration and variable name Section
            obj.NewSessionButton.Enabled = true;
            obj.DurationEditField.Enabled = true;
            obj.DurationLabel.Enabled = true;
            obj.WorkspaceVarLabel.Enabled = true;
            obj.WorkspaceVariableNameEditField.Enabled = true;
            obj.SignalAnalyzerButton.Enabled = true;
            obj.CodeGenButton.Enabled = true;
        end

    end
end

% LocalWords:  Pinout arduinoapp app's pinout
