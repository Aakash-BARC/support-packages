classdef ConfigurePlotDialogManager < handle

    % CONFIGUREPLOTDIALOGMANAGER - Class that handles creation and interaction
    % of the modal dialog that handles plot settings

    % Copyright 2021 The MathWorks, Inc.

    properties(Access = private)
        % Handle to the plot manager module
        PlotManagerHandle

        % Parent figure and grid handles
        ParentFigure
        ParentFigureGrid
        ParentFigurePosition

        % Grids to host property sections and call to action buttons
        GeneralSettingGrid
        YAxisSettingGrid
        ConfirmButtonGrid

        % Checkboxes in the modal dialog
        LegendCheckBox
        GridCheckBox
        MultipleYAxisCheckBox

        % Axes controls
        YAxisSettingTitle
        YLimAutoScaleCheckbox
        YLimMinLabel
        YLimMinEditField
        YLimMaxLabel
        YLimMaxEditField

        % Confirm buttons
        OkButton
        CancelButton
        ApplyButton

        % Listener handles
        LegendCheckBoxListener
        GridCheckBoxListener
        MultipleYAxisCheckBoxListener
        AutoScaleCheckboxListener
        YLimMinEditFieldListener
        YLimMaxEditFieldListener
        OkButtonListener
        CancelButtonListener
        ApplyButtonListener
    end

    %% Constant properties
    properties(Constant,Access=private)
        DialogLeftPosition = 500
        DialogBottomPosition = 200

        % Parent grid dimensions
        ParentGridRowHeight = {'fit',2,'fit','fit'}
        ParentGridColumnWidth = {'1x'};

        % Nested grid posiitons within parent grid
        GeneralSettingGridPosition = {1,1}
        SeparatorPanelPosition = {2,1}
        YAxisSettingGridPosition = {3,1}
        ConfirmButtonGridPosition = {4,1}

        % Nested grid dimensions
        GeneralSettingGridRowHeight = {'fit'}
        GeneralSettingGridColumnWidth = {'1x','1x','1x'}
        YAxisSettingGridRowHeight = {'fit','fit'}
        YAxisSettingGridColumnWidth = {'1x','0.2x','0.5x','0.2x','0.5x','0.5x'}
        ConfirmButtonGridRowHeight = {'fit'}
        ConfirmButtonGridColumnWidth = {'1x','1x','1x','1x','1x'}

        % Widget positions within nested grids
        LegendCheckBoxPosition = {1,1}
        GridCheckBoxPosition = {1,2}
        MultipleYAxisCheckBoxPosition = {1,3}

        YAxisSettingTitlePosition = {1,1}
        AutoScaleCheckBoxPosition = {2,1}
        YMinLabelPosition = {2,2}
        YMinEditFieldPosition = {2,3}
        YMaxLabelPosition = {2,4}
        YMaxEditFieldPosition = {2,5}

        OkButtonPosition = {1,3};
        CancelButtonPosition = {1,4};
        ApplyButtonPosition = {1,5}

        % Font and background colors for the modal dialog and widgets
        TextColor = "#242424"
        SectionSeparatorColor = "#D8D8D8"
        DefaultBackgroundColor = "#F0F0F0"
        ButtonBackgroundColor = arduinoioapplet.internal.ArduinoAppConstants.DefaultBackgroundColor
        TitleFontSize = 14
    end

    %% Public methods
    methods
        %Constructor
        function obj = ConfigurePlotDialogManager(plotManager)
            % Call the superclass constructors

            obj.PlotManagerHandle = plotManager;
        end

        function launchConfigurePlotDialog(obj)
            % Function to launch the configure plot modal dialog

            createDialog(obj);
            populateDialog(obj);
            addWidgetListeners(obj);
        end

        function handleSettingsChanged(obj)
            % Generic function to react to any plot setting change

            obj.ApplyButton.Enable = "on";
        end

        function handleAutoScaleSelectionChanged(obj,eventData)
            % Enable Min and Max limits if user chooses manual Y-axis scaling

            % Get current Y-axis limits from the scope
            [~,limits] = getScopeYLimits(obj.PlotManagerHandle);
            obj.YLimMinEditField.Value = limits(1);
            obj.YLimMaxEditField.Value = limits(2);
            if eventData.Value
                obj.YLimMinLabel.Enable = "off";
                obj.YLimMaxLabel.Enable = "off";
                obj.YLimMinEditField.Enable = "off";
                obj.YLimMaxEditField.Enable = "off";
            else
                obj.YLimMinLabel.Enable = "on";
                obj.YLimMaxLabel.Enable = "on";
                obj.YLimMinEditField.Enable = "on";
                obj.YLimMaxEditField.Enable = "on";
                obj.YLimMinEditField.Value = limits(1);
                obj.YLimMaxEditField.Value = limits(2);
            end
            obj.ApplyButton.Enable = "on";
        end

        function handleOkButtonClick(obj)
            % Callback function when user clicks "OK" in the configure plot modal dialog

            applySettings(obj);
            closeDialog(obj);
        end

        function handleCancelButtonClick(obj)
            % Close the modal dialog when user clicks cancel

            closeDialog(obj);
        end

        function handleApplyButtonClick(obj)
            % Callback function to handle apply button click
            % Apply changes and do keep the modal window open

            applySettings(obj);
            obj.ApplyButton.Enable = "off";
        end
    end

    methods(Access = private)
        function createDialog(obj)
            % Create modal tab for the configure plot dialog

            % Determine screen position for the modal dialog
            screenSize = get(groot,'ScreenSize');
            left = (screenSize(3) - obj.DialogLeftPosition )/2;
            bottom = (screenSize(4) - obj.DialogBottomPosition )/2;
            obj.ParentFigurePosition = [left bottom obj.DialogLeftPosition obj.DialogBottomPosition];

            % Create modal figure
            obj.ParentFigure = uifigure("Position",obj.ParentFigurePosition);
            obj.ParentFigure.WindowStyle = "modal";
            obj.ParentFigure.Name = getString(message("MATLAB:arduinoio:arduinoapp:configPlotTitle"));
            obj.ParentFigure.Resize = "off";
            obj.ParentFigure.Tag = "Configure Plot Dialog";

            % Create parent grid layout for the modal dialog
            obj.ParentFigureGrid = uigridlayout(obj.ParentFigure,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.ParentFigureGrid.RowHeight = obj.ParentGridRowHeight;
            obj.ParentFigureGrid.ColumnWidth = obj.ParentGridColumnWidth;

            % Create grid for hosting general setting controls
            obj.GeneralSettingGrid = uigridlayout(obj.ParentFigureGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.GeneralSettingGrid.Layout.Row = obj.GeneralSettingGridPosition{1};
            obj.GeneralSettingGrid.Layout.Column = obj.GeneralSettingGridPosition{2};
            obj.GeneralSettingGrid.RowHeight = obj.GeneralSettingGridRowHeight;
            obj.GeneralSettingGrid.ColumnWidth = obj.GeneralSettingGridColumnWidth;

            % Create grid for hosting YAxis limit settings
            obj.YAxisSettingGrid = uigridlayout(obj.ParentFigureGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.YAxisSettingGrid.Layout.Row = obj.YAxisSettingGridPosition{1};
            obj.YAxisSettingGrid.Layout.Column = obj.YAxisSettingGridPosition{2};
            obj.YAxisSettingGrid.RowHeight = obj.YAxisSettingGridRowHeight;
            obj.YAxisSettingGrid.ColumnWidth = obj.YAxisSettingGridColumnWidth;

            % Create grid for hosting confirm buttons
            obj.ConfirmButtonGrid = uigridlayout(obj.ParentFigureGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.ConfirmButtonGrid.Layout.Row = obj.ConfirmButtonGridPosition{1};
            obj.ConfirmButtonGrid.Layout.Column = obj.ConfirmButtonGridPosition{2};
            obj.ConfirmButtonGrid.RowHeight = obj.ConfirmButtonGridRowHeight;
            obj.ConfirmButtonGrid.ColumnWidth = obj.ConfirmButtonGridColumnWidth;
        end

        function populateDialog(obj)
            % Populate various sections of the modal dialog

            populateGeneralSettings(obj);
            populateYAxisSettings(obj);
            populateButtons(obj);
        end

        function populateGeneralSettings(obj)
            % Populate the general plot settings

            obj.LegendCheckBox = uicheckbox(obj.GeneralSettingGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:showLegendLabel")),...
                "FontColor",obj.TextColor);
            obj.LegendCheckBox.Layout.Row = obj.LegendCheckBoxPosition{1};
            obj.LegendCheckBox.Layout.Column = obj.LegendCheckBoxPosition{2};
            obj.LegendCheckBox.Value = getScopeLegend(obj.PlotManagerHandle);
            obj.LegendCheckBox.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:showLegendDescription"));
            obj.LegendCheckBox.Tag = "Legend Checkbox";

            obj.GridCheckBox = uicheckbox(obj.GeneralSettingGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:showGridLabel")),...
                "FontColor",obj.TextColor);
            obj.GridCheckBox.Layout.Row = obj.GridCheckBoxPosition{1};
            obj.GridCheckBox.Layout.Column = obj.GridCheckBoxPosition{2};
            obj.GridCheckBox.Value = getScopeGrid(obj.PlotManagerHandle);
            obj.GridCheckBox.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:showGridDescription"));
            obj.GridCheckBox.Tag = "Grid Checkbox";

            obj.MultipleYAxisCheckBox = uicheckbox(obj.GeneralSettingGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:showMultiYAxesLabel")),...
                "FontColor",obj.TextColor);
            obj.MultipleYAxisCheckBox.Layout.Row = obj.MultipleYAxisCheckBoxPosition{1};
            obj.MultipleYAxisCheckBox.Layout.Column = obj.MultipleYAxisCheckBoxPosition{2};
            obj.MultipleYAxisCheckBox.Value = getMultipleYAxesState(obj.PlotManagerHandle);
            obj.MultipleYAxisCheckBox.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:showMultiYAxesDescription"));
            obj.MultipleYAxisCheckBox.Tag = "Multiple YAxis Checkbox";

            panelSeparator = uipanel(obj.ParentFigureGrid,...
                "BackgroundColor",obj.SectionSeparatorColor);
            panelSeparator.Layout.Row = obj.SeparatorPanelPosition{1};
            panelSeparator.Layout.Column = obj.SeparatorPanelPosition{2};
        end

        function populateYAxisSettings(obj)
            % Populate Y-Axis settings in the modal dialog

            % Populate setting widgets within the grid
            obj.YAxisSettingTitle = uilabel(obj.YAxisSettingGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:YAxisScalingTitle")),...
                "FontColor",obj.TextColor,...
                "FontWeight","bold",...
                "FontSize",obj.TitleFontSize);
            obj.YAxisSettingTitle.Layout.Row = obj.YAxisSettingTitlePosition{1};
            obj.YAxisSettingTitle.Layout.Column = obj.YAxisSettingTitlePosition{2};
            obj.YAxisSettingTitle.Tag = "YAxis Scaling";

            [mode,limits] = getScopeYLimits(obj.PlotManagerHandle);
            if strcmpi(mode,"auto")
                autoMode = true;
            else
                % Get limits for signals instead of scope, if multiple Y-Axis
                % option is selected
                if(obj.MultipleYAxisCheckBox.Value)
                    limits = getSignalYLimits(obj.PlotManagerHandle);
                end
                autoMode = false;
            end

            obj.YLimAutoScaleCheckbox = uicheckbox(obj.YAxisSettingGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:autoScaleLabel")),...
                "FontColor",obj.TextColor);
            obj.YLimAutoScaleCheckbox.Layout.Row = obj.AutoScaleCheckBoxPosition{1};
            obj.YLimAutoScaleCheckbox.Layout.Column = obj.AutoScaleCheckBoxPosition{2};
            obj.YLimAutoScaleCheckbox.Value = 1;

            obj.YLimMinLabel = uilabel(obj.YAxisSettingGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:minLabel")),...
                "HorizontalAlignment","right",...
                "FontColor",obj.TextColor);
            obj.YLimMinLabel.Layout.Row = obj.YMinLabelPosition{1};
            obj.YLimMinLabel.Layout.Column = obj.YMinLabelPosition{2};
            obj.YLimMinLabel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:minYDescription"));
            obj.YLimMinLabel.Tag = "YMin Label";
            obj.YLimMinLabel.Enable = "off";

            obj.YLimMinEditField = uieditfield(obj.YAxisSettingGrid,"numeric");
            obj.YLimMinEditField.Layout.Row = obj.YMinEditFieldPosition{1};
            obj.YLimMinEditField.Layout.Column = obj.YMinEditFieldPosition{2};
            obj.YLimMinEditField.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:minYDescription"));
            obj.YLimMinEditField.Tag = "YMin EditField";
            obj.YLimMinEditField.Enable = "off";

            obj.YLimMaxLabel = uilabel(obj.YAxisSettingGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:maxLabel")),...
                "HorizontalAlignment","right",...
                "FontColor",obj.TextColor);
            obj.YLimMaxLabel.Layout.Row = obj.YMaxLabelPosition{1};
            obj.YLimMaxLabel.Layout.Column = obj.YMaxLabelPosition{2};
            obj.YLimMaxLabel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:maxYDescription"));
            obj.YLimMaxLabel.Tag = "YMax Label";
            obj.YLimMaxLabel.Enable = "off";

            obj.YLimMaxEditField = uieditfield(obj.YAxisSettingGrid,"numeric");
            obj.YLimMaxEditField.Layout.Row = obj.YMaxEditFieldPosition{1};
            obj.YLimMaxEditField.Layout.Column = obj.YMaxEditFieldPosition{2};
            obj.YLimMaxEditField.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:maxYDescription"));
            obj.YLimMaxEditField.Tag = "YMax EditField";
            obj.YLimMaxEditField.Enable = "off";

            obj.YLimMinEditField.Value = limits(1);
            obj.YLimMaxEditField.Value = limits(2);

            % Enable min and max edit fields if user has selected manual scaling
            if ~autoMode
                obj.YLimAutoScaleCheckbox.Value = 0;
                obj.YLimMinLabel.Enable = "on";
                obj.YLimMinEditField.Enable = "on";
                obj.YLimMaxLabel.Enable = "on";
                obj.YLimMaxEditField.Enable = "on";
            end

        end

        function populateButtons(obj)
            % Function to populate confirm buttons in the modal dialog

            % Create OK button
            obj.OkButton = uibutton(obj.ConfirmButtonGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:okButtonLabel")),...
                "FontColor",obj.TextColor,...
                "BackgroundColor",obj.ButtonBackgroundColor);
            obj.OkButton.Layout.Row = obj.OkButtonPosition{1};
            obj.OkButton.Layout.Column = obj.OkButtonPosition{2};
            obj.OkButton.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:okButtonDescription"));
            obj.OkButton.Tag = "OK Button";

            % Create Cancel button
            obj.CancelButton = uibutton(obj.ConfirmButtonGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:cancelButtonLabel")),...
                "FontColor",obj.TextColor,...
                "BackgroundColor",obj.ButtonBackgroundColor);
            obj.CancelButton.Layout.Row = obj.CancelButtonPosition{1};
            obj.CancelButton.Layout.Column = obj.CancelButtonPosition{2};
            obj.CancelButton.Tag = "Cancel Button";

            % Create Apply button
            obj.ApplyButton = uibutton(obj.ConfirmButtonGrid,...
                "Text",getString(message("MATLAB:arduinoio:arduinoapp:applyButtonLabel")),...
                "FontColor",obj.TextColor,...
                "BackgroundColor",obj.ButtonBackgroundColor);
            obj.ApplyButton.Layout.Row = obj.ApplyButtonPosition{1};
            obj.ApplyButton.Layout.Column = obj.ApplyButtonPosition{2};
            obj.ApplyButton.Enable = "off";
            obj.ApplyButton.Tag = "Apply Button";
        end

        function closeDialog(obj)
            delete(obj.ParentFigure);
        end

        function applySettings(obj)
            % Internal function to apply selected plot settings

            setScopeGrid(obj.PlotManagerHandle,obj.GridCheckBox.Value);
            setScopeLegend(obj.PlotManagerHandle,obj.LegendCheckBox.Value);
            setMultipleYAxes(obj.PlotManagerHandle,obj.MultipleYAxisCheckBox.Value);

            % Set the scope limits if single Y-Axis view is selected
            % Set the signal limits if multiple Y-Axis view is selected
            if ~obj.MultipleYAxisCheckBox.Value
                setScopeYLimits(obj.PlotManagerHandle,obj.YLimAutoScaleCheckbox.Value,...
                    [obj.YLimMinEditField.Value,obj.YLimMaxEditField.Value]);
            else
                setSignalYLimits(obj.PlotManagerHandle,obj.YLimAutoScaleCheckbox.Value,...
                    [obj.YLimMinEditField.Value,obj.YLimMaxEditField.Value]);
            end
        end

        function addWidgetListeners(obj)
            % Register listeners for modal dialog buttons
            obj.OkButtonListener = obj.OkButton.listener('ButtonPushed',@(src,event)obj.handleOkButtonClick());
            obj.CancelButtonListener = obj.CancelButton.listener('ButtonPushed',@(src,event)obj.handleCancelButtonClick());
            obj.ApplyButtonListener = obj.ApplyButton.listener('ButtonPushed',@(src,eventData)obj.handleApplyButtonClick());
            obj.AutoScaleCheckboxListener = obj.YLimAutoScaleCheckbox.listener('ValueChanged',@(src,eventData)obj.handleAutoScaleSelectionChanged(eventData));
            obj.LegendCheckBoxListener = obj.LegendCheckBox.listener('ValueChanged',@(src,eventData)obj.handleSettingsChanged());
            obj.GridCheckBoxListener = obj.GridCheckBox.listener('ValueChanged',@(src,eventData)obj.handleSettingsChanged());
            obj.MultipleYAxisCheckBoxListener = obj.MultipleYAxisCheckBox.listener('ValueChanged',@(src,eventData)obj.handleSettingsChanged());
            obj.YLimMinEditFieldListener = obj.YLimMinEditField.listener('ValueChanged',@(src,eventData)obj.handleSettingsChanged());
            obj.YLimMaxEditFieldListener = obj.YLimMaxEditField.listener('ValueChanged',@(src,eventData)obj.handleSettingsChanged());
        end
    end
end
