classdef PlotManager < matlabshared.mediator.internal.Publisher...
        & matlabshared.mediator.internal.Subscriber...
        &arduinoioapplet.modules.internal.ErrorSource
    % PLOTMANAGER - Class that manages the Arduino Explorer's time scope panel

    % Copyright 2021 The MathWorks, Inc.

    properties(Access = private)
        % Handle to mediator and pin table for sharing data across UI modules
        Mediator
        PinTableManager

        % Main UI panel for plot area and the corresponding UI grid
        PlotPanel
        PlotGrid

        % Grid to host the plot table to select pins to plot
        PlotTableGrid
        PlotTableHeaderPanel
        PlotTableHeader

        % Time Scope UI panel and Time Scope handle
        TimeScopePanel

        % Handle to the "Configure Plot" modal dialog
        ConfigurePlotDialogHandle

        % Table to select signals to plot
        SignalSelectionTable

        % Map to track the pin and corresponding plot state
        SignalPlotMap

        % Map holding the signal handles corresponding to pins
        % currently in the signal selection table
        ScopeSignalMap

        % Holds the list of pin numbers that are currently selected for plotting
        SignalsToPlot

        % Listener handle for signal selection/deselection in the signal table
        SignalSelectionListener

        % Current time stamp of the data being plotted in the time scope
        CurrentTimeStamp = 0

        % Handle to the timer object responsible for updating the time scope plot
        PlotTimerObj
        PlotTimerPeriod = arduinoioapplet.internal.ArduinoAppConstants.PollingInterval
    end

    properties(SetAccess = private, GetAccess = ?arduino.accessor.UnitTest)
        TimeScope
    end

    %% Constant properties
    properties(Constant,Access=private)

        % Plot area grid dimensions
        PlotGridRowHeight = {'1x'}
        PlotGridColumnWidth = {'1x',10,'0.25x'}
        PlotGridPadding = [10 10 10 10]

        % Plot Table grid dimensions
        PlotTableGridRowHeight = {36,'1x'}
        PlotTableGridColumnWidth = {'0.25x'}
        PlotTableGridPadding = [0 0 0 0]
        PlotTableGridPosition = {1,3}

        % Plot table header position within plot grid
        PlotTableHeaderPanelPosition = {1,1}
        PlotTableTitlePosition = [7 2 100 30]

        % Time scope position inside Plot grid
        TimeScopePosition = {1,[1,2]}

        % Signal selection table position within PlotTable grid
        SignalSelectionTablePosition = {2,1}

        % Signal selection table properties
        SignalSelectionColumnNames = {getString(message("MATLAB:arduinoio:arduinoapp:signalSelectionColumnName")),...
            getString(message("MATLAB:arduinoio:arduinoapp:signalColumnName")),...
            getString(message("MATLAB:arduinoio:arduinoapp:customNameLabel"))}

        SignalSelectionColumnWidth = {'1x','1x','2x'}
        SignalSelectionTableEditable = [true,false,false]
        SignalSelectionVarNames = ["Add","Pin","CustomName"]

        PlotTablePanelColor = "#D8D8D8"
        PlotTableHeaderFontColor = "#535353"
        PlotTableHeaderFontSize = 16
        DefaultBackgroundColor = arduinoioapplet.internal.ArduinoAppConstants.DefaultBackgroundColor

        % Time scope plot properties
        PlotLineWidth = 2
        AnalogPlotType = "line"
        DigitalPlotType = "stairs"
        YLimits = [0 5]
        TimeSpan = 10
    end


    %% Public class methods
    methods
        function obj = PlotManager(mediator, parentGrid, position, tableManager)
            % Call the superclass constructor.
            obj@matlabshared.mediator.internal.Publisher(mediator);
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            % Save references.
            obj.Mediator = mediator;
            obj.PinTableManager = tableManager;

            % Create plot panel with time scope and signal selection table .
            createTimeScope(obj,parentGrid, position);
            createSignalSelectionTable(obj);

            % Instantiate the "Configure Plot" modal dialog class
            obj.ConfigurePlotDialogHandle= arduinoioapplet.modules.internal.ConfigurePlotDialogManager(obj);

            % Initialize pin plot map and signals to plot list
            initResources(obj);

            % Initialize plot area listeners
            addWidgetListeners(obj);

            % Initialize and start timer to plot signals
            obj.PlotTimerObj = internal.IntervalTimer(obj.PlotTimerPeriod);
            addlistener(obj.PlotTimerObj,'Executing',@(~,~)obj.plotSignals);
        end

        function delete(obj)

            if(~isempty(obj.PlotTimerObj) && isvalid(obj.PlotTimerObj))
                obj.PlotTimerObj.stop();
                obj.PlotTimerObj = [];
            end
        end

        function subscribeToMediatorProperties(obj,~,~)
            % Function to subscribe to mediator events
            obj.subscribe('UserConfirmedNewSession', @(src, event)obj.handleNewSessionRequest());
            obj.subscribe('UserClickedConfigurePlot', @(src, event)obj.handleConfigurePlotLaunch());
            obj.subscribe('UserConfiguredPins', @(src, event)obj.handlePostPinConfigurations());
            obj.subscribe('IsPinsToReadEmpty', @(src, event)obj.handlePinsToReadUpdate(event.AffectedObject));
            obj.subscribe('PinReadStopped', @(src, event)obj.handlePinReadStop());
        end
    end

    %% Set and get method of the Time Scope property
    methods(Hidden)
        function setScopeLegend(obj,state)
            % Update Legend

            if state
                obj.TimeScope.LegendVisible = "on";
            else
                obj.TimeScope.LegendVisible = "off";
            end
        end

        function setScopeGrid(obj,state)
            % Update Grid
            if state
                obj.TimeScope.Grid = "on";
            else
                obj.TimeScope.Grid = "off";
            end
        end

        function setMultipleYAxes(obj,state)
            % Update multiple Y-Axis setting

            if state
                obj.TimeScope.MultipleYAxis = "on";
            else
                obj.TimeScope.MultipleYAxis = "off";
            end
        end

        function setScopeYLimits(obj,autoScale,limits)
            % Update the scope's Y-Axis limits

            if autoScale
                obj.TimeScope.YLimitsMode = "auto";
            else
                obj.TimeScope.YLimitsMode = "manual";
                obj.TimeScope.YLimits = limits;
            end
        end

        function setSignalYLimits(obj,autoScale,limits)
            % Update the scope signal's Y-Axis limits

            if autoScale
                obj.TimeScope.YLimitsMode = "auto";
            else
                % Update YLimits of each signal in the scope
                obj.TimeScope.YLimitsMode = "manual";
                signals = values(obj.ScopeSignalMap);
                for signalIndex = 1:length(signals)
                    signals{signalIndex}.YLimits = limits;
                end
            end
        end

        function state = getScopeLegend(obj)
            % Return current state of legend setting

            if strcmpi(obj.TimeScope.LegendVisible,"on")
                state = true;
            else
                state = false;
            end
        end

        function state = getScopeGrid(obj)
            % Return current state of legend setting
            if strcmpi(obj.TimeScope.Grid,"on")
                state = true;
            else
                state = false;
            end
        end

        function state = getMultipleYAxesState(obj)
            % Return current state of legend setting
            if strcmpi(obj.TimeScope.MultipleYAxis,"on")
                state = true;
            else
                state = false;
            end
        end

        function [mode,limits] = getScopeYLimits(obj)
            % Return the Y-Axis scaling mode and limits

            if strcmpi(obj.TimeScope.YLimitsMode,"auto")
                mode = "auto";
            else
                mode = "manual";
            end
            limits = obj.TimeScope.YLimits;
        end

        function limits = getSignalYLimits(obj)
            % Return the Y-Axis scaling limits for signals

            limits = [];
            signals = obj.ScopeSignalMap.values;
            if ~isempty(signals)
                limits = signals{1}.YLimits;
            end
        end
    end

    methods(Access = private)
        function createTimeScope(obj,parentGrid,position)

            % Create plot panel
            obj.PlotPanel = uipanel(parentGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.PlotPanel.Layout.Row = position{1};
            obj.PlotPanel.Layout.Column = position{2};
            obj.PlotPanel.Tag = "Plot Panel";

            % Create gridlayout within the plot panel
            obj.PlotGrid = uigridlayout(obj.PlotPanel,...
                'RowHeight',obj.PlotGridRowHeight,...
                "ColumnWidth",obj.PlotGridColumnWidth,...
                'Padding',obj.PlotGridPadding,...
                "BackgroundColor",obj.DefaultBackgroundColor);

            % Create the uipanel for placing time scope
            obj.TimeScopePanel = uipanel(obj.PlotGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.TimeScopePanel.Layout.Row = obj.TimeScopePosition{1};
            obj.TimeScopePanel.Layout.Column = obj.TimeScopePosition{2};
            obj.TimeScopePanel.Tag = "TimeScope Panel";

            % Create time scope
            obj.TimeScope = matlab.hwmgr.scopes.TimeScope(obj.TimeScopePanel);
            obj.TimeScope.PlayButtonEnabled = "on";
            obj.TimeScope.Title = "";
            obj.TimeScope.XLabel = getString(message("MATLAB:arduinoio:arduinoapp:xLabelScope"));
            obj.TimeScope.YLabel = getString(message("MATLAB:arduinoio:arduinoapp:yLabelScope"));
            obj.TimeScope.TimeSpan = obj.TimeSpan;
            obj.TimeScope.YLimitsMode = 'manual';
            obj.TimeScope.YLimits = obj.YLimits;
        end

        function createSignalSelectionTable(obj)
            % Function to create signal selection table

            % Create Signal Selection Table
            obj.PlotTableGrid = uigridlayout(obj.PlotGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.PlotTableGrid.Padding = obj.PlotTableGridPadding;
            obj.PlotTableGrid.Layout.Row = obj.PlotTableGridPosition{1};
            obj.PlotTableGrid.Layout.Column = obj.PlotTableGridPosition{2};
            obj.PlotTableGrid.RowHeight = obj.PlotTableGridRowHeight;
            obj.PlotTableGrid.ColumnWidth = obj.PlotTableGridColumnWidth;

            obj.PlotTableHeaderPanel = uipanel(obj.PlotTableGrid);
            obj.PlotTableHeaderPanel.Layout.Row = obj.PlotTableHeaderPanelPosition{1};
            obj.PlotTableHeaderPanel.Layout.Column = obj.PlotTableHeaderPanelPosition{2};
            obj.PlotTableHeaderPanel.BackgroundColor = obj.PlotTablePanelColor;
            obj.PlotTableHeader = uilabel(obj.PlotTableHeaderPanel);
            obj.PlotTableHeader.Tag = "Plot Table Header";
            obj.PlotTableHeader.Text = getString(message("MATLAB:arduinoio:arduinoapp:plotTableTitle"));
            obj.PlotTableHeader.FontSize = obj.PlotTableHeaderFontSize;
            obj.PlotTableHeader.HorizontalAlignment = "left";
            obj.PlotTableHeader.Position = obj.PlotTableTitlePosition;
            obj.PlotTableHeader.FontWeight = "bold";
            obj.PlotTableHeader.FontColor = obj.PlotTableHeaderFontColor;

            obj.SignalSelectionTable = uitable(obj.PlotTableGrid);
            obj.SignalSelectionTable.Layout.Row = obj.SignalSelectionTablePosition{1};
            obj.SignalSelectionTable.Layout.Column = obj.SignalSelectionTablePosition{2};
            obj.SignalSelectionTable.ColumnName = obj.SignalSelectionColumnNames;
            obj.SignalSelectionTable.ColumnWidth = obj.SignalSelectionColumnWidth;
            obj.SignalSelectionTable.ColumnEditable = obj.SignalSelectionTableEditable;
            obj.SignalSelectionTable.SelectionType = "row";
            obj.SignalSelectionTable.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:signalTableDescription"));
            obj.SignalSelectionTable.Tag = "Signal Selection Table";
            obj.SignalSelectionTable.Enable = "off";
        end

        function handleNewSessionRequest(obj)
            % Function to reset the scope and table

            obj.resetScope();
            obj.SignalSelectionTable.Data = table({},{},{});
            obj.SignalSelectionTable.Data.Properties.VariableNames = obj.SignalSelectionColumnNames;
            obj.SignalSelectionTable.Enable = "off";
            initResources(obj);
        end

        function handleConfigurePlotLaunch(obj)
            % Callback function to launch "Configure Plot" dialog
            launchConfigurePlotDialog(obj.ConfigurePlotDialogHandle);
        end

        function handlePostPinConfigurations(obj)
            % Callback function to handle plot area changes after
            % users has configured Arduino pins

            % Get the pins that are currently configured in one of the read modes
            pinsToRead = string(getPinsToRead(obj.PinTableManager));

            % Get the list of current pins in the SignalPlot map
            pinKeys = string(keys(obj.SignalPlotMap));

            % Add new pins to list, unselected by default
            % Create signal objects for these pins and store them in the ScopeSignal map
            for index = 1:length(pinsToRead)
                % Get pin number and custom name for each pin
                pin = pinsToRead(index);
                customName = getCustomName(obj.PinTableManager,pin);
                % If the pin is not a member of the SignalPlot Map:
                % Add to SignalPlotMap with default selection as false.
                % Create time scope signal object for the pin and add to ScopeSignal map.
                if ~ismember(pin,pinKeys)
                    obj.SignalPlotMap(pin) = true;
                    signalObj = createTimeScopeSignal(obj,pin,customName);
                    signalObj.Visible = true;
                    obj.ScopeSignalMap(pin) = signalObj;
                    updateSignalsToPlot(obj,pin,true);
                else
                    % Check if custom name has changed
                    signalObj = obj.ScopeSignalMap(pin);
                    if ~isequal(signalObj.Name, customName)
                        signalObj.Name = customName;
                        obj.ScopeSignalMap(pin) = signalObj;
                    end
                    % Update plot type if pin mode has changed
                    if startsWith(obj.PinTableManager.getPinMode(pin),"Analog")
                        signalObj.PlotType = obj.AnalogPlotType;
                    else
                        signalObj.PlotType = obj.DigitalPlotType;
                    end
                end
            end

            % Remove pins that are not in the read mode from maps
            pins = string(keys(obj.SignalPlotMap));
            pinsToRemove = setdiff(pins,pinsToRead);
            if(~isempty(pinsToRemove))
                removeSignals(obj,pinsToRemove);
            end

            % Update signal selection table
            updateSignalSelectionTable(obj);

            % Enable the pin/signal selection table
            obj.SignalSelectionTable.Enable = "on";
        end

        function handlePinsToReadUpdate(obj,eventObj)
            % Function to reset scope if there are no pins to read and to
            % start timer when the first pins is added to read

            if eventObj.IsPinsToReadEmpty
                obj.PlotTimerObj.stop();
                resetScope(obj);
            else
                obj.PlotTimerObj.start();
            end
        end

        function handlePinReadStop(obj,eventObj)
            % Function to stop plotting pins when the read pin stop event
            % is triggered

            obj.PlotTimerObj.stop();
        end

        function handlePlotStatusChanged(obj,event)
            % Callback function to handle the change in plot selection status

            % Get the current state of the selection
            plotState = logical(event.NewData);

            % Get the pin number whose plot status was changed from the signal selection table
            pin = obj.SignalSelectionTable.Data.Pin(event.Indices(1));
            pin = char(extractPinNumber(obj,pin));

            % Update the list of signals to plot
            updateSignalsToPlot(obj,pin,plotState);

            % Update signals being displayed in the scope
            updateSignalsInScope(obj,pin,plotState);

            % Update the new plot status of that pin in the map
            obj.SignalPlotMap(pin) = plotState;

        end

        function updateSignalsToPlot(obj,pins,state)
            % Function to update the list of signals to be plotted in time scope

            % Add to cell array if pin is selected for plotting
            % Remove from cell array if pin is deselected for plotting
            if(state)
                obj.SignalsToPlot = [obj.SignalsToPlot pins];
            else
                obj.SignalsToPlot = setdiff(obj.SignalsToPlot,pins);
            end
            obj.SignalsToPlot = unique(obj.SignalsToPlot);
        end

        function updateSignalsInScope(obj,pin,state)
            % Function to remove or add a signal to scope

            % Toggle signal visibility based on signal selection
            signalHandle = obj.ScopeSignalMap(pin);
            if state
                signalHandle.Visible = "on";
            else
                signalHandle.Visible = "off";
            end
        end

        function updateSignalSelectionTable(obj)
            % Function to update the signal selection table

            % Get list of pins and corresponding plot statuses from the map
            pins = string(keys(obj.SignalPlotMap));

            % Get custom names of pin
            customNames = cellfun(@(pin)obj.PinTableManager.getCustomName(pin),pins,...
                "UniformOutput",false);

            plotStatuses = values(obj.SignalPlotMap);

            % Update the signal selection table
            obj.SignalSelectionTable.Data = table(plotStatuses',pins',customNames');
            obj.SignalSelectionTable.Data.Properties.VariableNames = obj.SignalSelectionVarNames;
        end

        function initResources(obj)
            % Initialize plot resources
            obj.SignalPlotMap = containers.Map();
            obj.ScopeSignalMap = containers.Map();
            obj.SignalsToPlot = {};
        end

        function plotSignals(obj)
            % Timer callback function to plot signal data from pins added for plot

            % Exit if there are no signals selected for plotting
            if isempty(obj.SignalsToPlot)
                obj.CurrentTimeStamp = 0;
                obj.TimeScope.clearData();
                return;
            end

            try
                % Flag to indicate if at least one signal sample was plotted
                signalPlotted = false;
                for index = 1:length(obj.SignalsToPlot)
                    pin = obj.SignalsToPlot{index};
                    readValue = getReadValue(obj.PinTableManager,pin);
                    % Update the scope if signal is present in the map and the read value is not empty
                    if isKey(obj.ScopeSignalMap,pin) && readValue~=""
                        signalHandle = obj.ScopeSignalMap(pin);
                        addData(signalHandle,obj.CurrentTimeStamp,str2double(readValue));
                        signalPlotted = true;
                    end
                end
                % Increment timestamp only if at least one read value was plotted
                if signalPlotted
                    % Increment the timestamp after updating time of all signals in scope
                    obj.CurrentTimeStamp = obj.CurrentTimeStamp+1;
                end
            catch e
                % Stop timer if error occurs
                obj.PlotTimerObj.stop();
                errObj = MException(e.identifier, e.message);
                obj.setErrorObjProperty(errObj);
                throwAsCaller(e);
            end
        end

        function signalObj = createTimeScopeSignal(obj,pin,customPinName)
            % Function to create a new Time Scope signal object

            signalObj = obj.TimeScope.createSignal(customPinName);
            % Use line plot for Analog signals and step for other signals
            if startsWith(obj.PinTableManager.getPinMode(pin),"Analog")
                signalObj.PlotType = obj.AnalogPlotType;
            else
                signalObj.PlotType = obj.DigitalPlotType;
            end
            signalObj.LineProperties.LineWidth = obj.PlotLineWidth;
            signalObj.YLabel = customPinName;
        end

        function removeSignals(obj,pinsToRemove)
            % Function to remove "Unset" pins from the maps and time scope

            % Remove each signal from scope
            if ~isempty(obj.TimeScope.Signals)
                for index = 1:length(pinsToRemove)
                    obj.TimeScope.removeSignal(obj.ScopeSignalMap(pinsToRemove{index}));
                end
            end
            % Remove from maps
            remove(obj.SignalPlotMap,cellstr(pinsToRemove));
            remove(obj.ScopeSignalMap,cellstr(pinsToRemove));
            % Remove from list of signals to plot
            if ~isempty(obj.SignalsToPlot)
                obj.SignalsToPlot = setdiff(obj.SignalsToPlot,pinsToRemove);
            end
        end

        function resetScope(obj)
            % Function to reset the time scope
            obj.TimeScope.reset();
            obj.TimeScope.XLabel = getString(message("MATLAB:arduinoio:arduinoapp:xLabelScope"));
            obj.TimeScope.YLabel = getString(message("MATLAB:arduinoio:arduinoapp:yLabelScope"));
            obj.TimeScope.YLimitsMode = 'manual';
            obj.TimeScope.YLimits = obj.YLimits;
        end

        function pin = extractPinNumber(~,pin)
            % Function to extract pin number from the formatted table display
            pin = strsplit(pin,"(");
            pin = strtrim(pin{1});
        end

        function addWidgetListeners(obj)
            % Function to add listeners for plot selection table
            obj.SignalSelectionListener = obj.SignalSelectionTable.listener('CellEdit',@(src,event)obj.handlePlotStatusChanged(event));
        end
    end
end
