classdef WiFiDeviceDescriptor < arduinoioapplet.descriptors.DeviceDescriptor &...
        matlab.hwmgr.internal.DeviceParamsDescriptor
    % This is the Arduino Hardware Device Descriptor subclass to manually add
    % non-enumerable WiFi Arduino device

    % Copyright 2021 The MathWorks, Inc.

    properties
        % Active connection type
        ConnectionType

        % Primary fields for any Arduino connection
        % WiFi IP Address
        Address

        % Name of the Arduino board as shown in the drop-down list
        Board

        % List of all supported Arduino boards for a specific connection type
        SupportedBoards

        % TCP/IP port for the WiFi connection
        TCPPort

        % Flag indicating if the friendly name field was edited
        IsDefaultFriendlyName
    end

    %% Hardware Manager Device Descriptor functions
    methods
        function obj = WiFiDeviceDescriptor(name)
            % Constructor - As a general guideline, the parameters should
            % be added in the constructor

            import arduinoioapplet.internal.ArduinoAppConstants
            % Create HardwareManager Device parameter descriptor instance
            obj@matlab.hwmgr.internal.DeviceParamsDescriptor(name,...
                arduinoio.internal.getDocMap,...
                'arduinoexplorer_addwifidevice',...
                getString(message("MATLAB:arduinoio:arduinoapp:addWiFiDeviceDescription")),true);

            % Syntax: addParameter(<paramID>, <paramName>, <Type>, <allowedValuesFunction>, <enableFunction>);
            % Syntax: addButton(<paramID>, <label>, <icon>, <style>, <buttonPushedFunction>, <enableFunction>, <sectionLabel>);
            obj.addButton('HardwareSetup', obj.HardwareSetupLabel, ...
                matlab.ui.internal.toolstrip.Icon(fullfile(ArduinoAppConstants.IconFolder,ArduinoAppConstants.HardwareSetupIcon)),...
                'Vertical', @obj.launchHardwareSetup, function_handle.empty,obj.SetupSectionName);
            obj.addParameter('Board',getString(message("MATLAB:arduinoio:arduinoapp:boardLabel")),...
                'DropDown', @obj.updateBoards, function_handle.empty, obj.SetupSectionName);
            obj.addParameter('Address',getString(message("MATLAB:arduinoio:arduinoapp:IPaddressLabel")),...
                'EditField', function_handle.empty, function_handle.empty, obj.SetupSectionName);
            obj.addParameter('TCPPort', getString(message("MATLAB:arduinoio:arduinoapp:TCPPortLabel")),...
                'EditField', function_handle.empty, function_handle.empty, obj.SetupSectionName);
            obj.addParameter('FriendlyName',obj.FriendlyNameLabel,...
                'EditField',@obj.updateName, function_handle.empty, obj.SetupSectionName);

            obj.ConnectionType = matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi;
            obj.IsDefaultFriendlyName = true;
        end
    end

    %% Toolstrip fields allowedValueFcn and enableFcn callback function
    methods(Access = private)
        function status = launchHardwareSetup(obj,~)
            % Callback function to launch the Arduino Hardware Setup
            % from the second screen(after selecting the corresponding connection type)

            status = 0;
            appDialogParent = obj.getDialogParent();
            workflow = matlab.hwmgr.internal.hwsetup.register.ArduinoWorkflow('tripwire', 'arduinoExplorer',...
                'ConnectionType', obj.ConnectionType);
            appDialogParent.Busy = 1;
            workflow.launch;
            appDialogParent.Busy = 0;
        end

        function boards = updateBoards(obj,~)
            % Callback function for the board drop-down field
            % Update list of supported boards based on the connection type chosen.

            obj.SupportedBoards = [{'Select board'}, sort(arduinoio.internal.ArduinoConstants.WiFiSupportedBoards)];
            boards = obj.SupportedBoards;

            % remove when ESP32 is supported from app
            boards = setdiff(boards,{'ESP32-WROOM-DevKitV1', 'ESP32-WROOM-DevKitC'},'stable');
        end
    end

    %% Internal utility functions used for adding device
    methods(Access = protected)
        function validateInputParams(obj, paramValMap)
            % Function to validate the input parameters provided by users
            % in the modal toolstrip

            % Validate board name
            validateBoard(obj,paramValMap('Board').NewValue);
            obj.Board = paramValMap('Board').NewValue;

            % Validate connection address
            validateAddress(obj, paramValMap('Address').NewValue);
            obj.Address = paramValMap('Address').NewValue;

            % Validate TCP port number for WiFi connection
            validatePort(obj, paramValMap('TCPPort').NewValue);
            obj.TCPPort = strrep(char(paramValMap('TCPPort').NewValue),' ','');
        end

        function status = deviceExists(obj, varargin)
            % Check if the Arduino device already exists in the device panel

            status = 0;
            address = obj.Address;
            port  = obj.TCPPort;
            for bIndex = 1:length(obj.Provider.DevicesProvided)
                if contains(obj.Provider.DevicesProvided(bIndex).VendorName,"Arduino") && ...
                        strcmpi(address,obj.Provider.DevicesProvided(bIndex).CustomData.Address) &&...
                        strcmpi(port,obj.Provider.DevicesProvided(bIndex).CustomData.WiFiPort)
                    status = 1;
                    return;
                end
            end
        end

        function [status,errorMsg] = testArduinoConnection(obj, varargin)
            % Function to create Arduino connection to ensure the board is
            % connected successfully

            status = 0;
            errorMsg = [];
            boardName = obj.Board;
            address = obj.Address;
            try
                if isempty(obj.TCPPort)
                    obj.TCPPort = num2str(arduinoioapplet.internal.ArduinoAppConstants.DefaultWiFiPort);
                end
                port = obj.TCPPort;
                aObj = arduino(address,boardName,str2double(port));
                aObj = [];
            catch e
                status = 1;
                errorMsg = e.message;
            end
        end
    end
end

% LocalWords:  WiFi TCP bluetooth
