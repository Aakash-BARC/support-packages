classdef ErrorSource < handle
    % ERRORSOURCE - Any Arduino Explorer app modules that could be a source of Error
    % should inherit from this class. This class provides the property
    % 'ErrorObj' to which the 'Error Display Manager' module is listening
    % to.

    % Copyright 2021 The MathWorks, Inc.

    properties (SetObservable)
        ErrorObj
    end

    methods
        function setErrorObjProperty(obj, errObj)
            obj.ErrorObj = errObj;
        end
    end
end