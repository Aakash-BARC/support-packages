classdef DeviceDescriptor < handle
    % This is the abstract superclass interface for other Arduino Device
    % descriptors

    % Copyright 2021 The MathWorks, Inc.

    % Abstract properties redefined in the device descriptor subclasses
    properties(Abstract)
        % Primary fields for any Arduino connection
        % Address corresponds to the COM port in USB, IP Address in WiFi
        % connection and Bluetooth Address in Bluetooth connection
        Address

        % The active connection type
        ConnectionType

        % Name of the Arduino board as shown in the drop-down list
        Board

        % List of all supported Arduino boards for a specific connection type
        SupportedBoards

        % Flag indicating if the friendly name in use is the default one
        IsDefaultFriendlyName
    end

    properties(Access = private)
        % Progress dialog handle
        ProgressDialog
    end

    properties(Access = protected, Constant)

        HardwareSetupLabel = getString(message("MATLAB:arduinoio:arduinoapp:hardwareSetupLabel"))
        SetupSectionName = getString(message("MATLAB:arduinoio:arduinoapp:deviceSetupLabel"))
        FriendlyNameLabel = getString(message("MATLAB:arduinoio:arduinoapp:friendlyNameLabel"))
        % Support Package base code for the app
        AppletPluginClass = "arduinoioapplet.ArduinoExplorerApplet"
        ArduinoIOBaseCode = "ML_ARDUINO"
    end

    %% Hardware Manager Device Descriptor abstract functions redefined by the device descriptor subclasses
    methods (Abstract, Access=protected)

        % Validate input parameters in the modal toolstrip
        validateInputParams(obj, paramValMap);

        % Abstract method that checks if the same device already exists
        deviceExists(obj, varagin);

        % Abstract method to check if connection is successful
        testArduinoConnection(obj, varargin);
    end

    methods

        % Method to validate the params on confirming params
        function validateParams(obj, paramValMap)

            % Start adding the board to device list and show progress
            appDialogParent = obj.getDialogParent();
            obj.ProgressDialog = uiprogressdlg(appDialogParent,  'Title',getString(message("MATLAB:arduinoio:arduinoapp:progressDlgTitle")),...
                'Indeterminate','off','Cancelable','off');

            % Validate all the parameters entered by the user. Also check
            % if device is already added.

            % 1. Validate and assign parameters
            obj.ProgressDialog.Value = 0.4;
            obj.ProgressDialog.Message = getString(message("MATLAB:arduinoio:arduinoapp:checkConnectionMsg"));
            validateInputParams(obj, paramValMap);

            % 2. Check if the device is already in the device panel
            obj.ProgressDialog.Value = 0.6;
            obj.ProgressDialog.Message = getString(message("MATLAB:arduinoio:arduinoapp:checkDeviceList"));
            if obj.deviceExists
                close(obj.ProgressDialog);
                obj.showErrorDlg(getString(message("MATLAB:arduinoio:arduinoapp:boardExists")));
            end

            % 3. Testing Arduino connection
            obj.ProgressDialog.Value = 0.7;
            obj.ProgressDialog.Message = getString(message("MATLAB:arduinoio:arduinoapp:connectionMsg",paramValMap('Board').NewValue,paramValMap('Address').NewValue));

            [status, errorMsg] = testArduinoConnection(obj);
            if status
                close(obj.ProgressDialog);
                obj.showErrorDlg(errorMsg);
                return;
            end

            obj.ProgressDialog.Value = 1;
            close(obj.ProgressDialog);
        end

        % Method to return a HWMGR device on confirming params
        function device = createHwmgrDevice(obj, paramValMap)

            % Create the non-enumerated device card
            friendlyName = paramValMap('FriendlyName').NewValue;
            if isempty(friendlyName)
                friendlyName = arduinoioapplet.internal.Utility.getFriendlyName(obj.Board);
            end

            % Add information about the device to the CustomData field
            customDeviceData.Board = obj.Board;
            customDeviceData.Address = obj.Address;
            customDeviceData.ConnectionType = obj.ConnectionType;
            customDeviceData.WiFiPort = [];

            deviceAddressPortPair = obj.Address;

            % Get the label for address/port to be displayed in the device card
            addressLabel = getString(message("MATLAB:arduinoio:arduinoapp:addressLabel"));
            if strcmpi(obj.ConnectionType,"Serial")
                addressLabel = getString(message("MATLAB:arduinoio:arduinoapp:portLabel"));
            end

            % Store TCP/IP Port number for WiFi connection
            if strcmpi(obj.ConnectionType, "WiFi")
                customDeviceData.WiFiPort = obj.TCPPort;
                deviceAddressPortPair = sprintf("%s:%s",obj.Address,obj.TCPPort);
            end

            % Create info to be displayed in the non-enumerable device
            % cards
            deviceCardDisplayInfo = {getString(message("MATLAB:arduinoio:arduinoapp:boardLabel")), obj.Board; ...
                getString(message("MATLAB:arduinoio:arduinoapp:connectionLabel")),...
                regexprep(string(obj.ConnectionType),{'Serial','Bluetooth','WiFi'},...
                {getString(message("MATLAB:arduinoio:arduinoapp:usbLabel")),getString(message("MATLAB:arduinoio:arduinoapp:btLabel")),getString(message("MATLAB:arduinoio:arduinoapp:wifiLabel"))});...
                addressLabel, deviceAddressPortPair};

            % Create the HWMgr device object
            device = matlab.hwmgr.internal.Device(friendlyName);
            device.DeviceCardDisplayInfo = deviceCardDisplayInfo;
            device.IconPath = getDeviceIconPath(obj,obj.Board);
            device.VendorName = "Arduino";
            device.DeviceAppletData = matlab.hwmgr.internal.data.DataFactory.createDeviceAppletData(...
                obj.AppletPluginClass,obj.ArduinoIOBaseCode);
            device.CustomData = customDeviceData;
        end

        % Method to return an icon to show on the non-enumerated device
        % gallery (Add-device button drop-down gallery)
        function icon = getIcon(obj)
            % The toolstrip Icon class must be used since Hardware Manager
            % is a toolstrip based application
            import arduinoioapplet.internal.ArduinoAppConstants
            switch char(obj.ConnectionType)
                case 'Serial'
                    source = fullfile(ArduinoAppConstants.IconFolder,ArduinoAppConstants.AddUSBIcon);
                case 'Bluetooth'
                    source = fullfile(ArduinoAppConstants.IconFolder,ArduinoAppConstants.AddBluetoothIcon);
                case 'WiFi'
                    source = fullfile(ArduinoAppConstants.IconFolder,ArduinoAppConstants.AddWiFiIcon);
            end
            icon = matlab.ui.internal.toolstrip.Icon(source);
        end
    end

    methods(Access=protected)
        function friendlyName = updateName(obj,paramValMap)
            % Function to update the board's friendly name

            % Reset the default friendly name flag for the first time
            if strcmpi(paramValMap("Board").NewValue,"Select Board") &&...
                    isempty(paramValMap("FriendlyName").NewValue)
                obj.IsDefaultFriendlyName = true;
            end

            friendlyName = paramValMap('FriendlyName').NewValue;

            % If the previous and new friendly names are different, then user has edited the field
            if ~isempty(paramValMap('FriendlyName').OldValue) && ...
                    ~strcmpi(paramValMap('FriendlyName').NewValue,paramValMap('FriendlyName').OldValue)
                obj.IsDefaultFriendlyName = false;
            end

            % Use default friendly name if the field is not edited
            if obj.IsDefaultFriendlyName
                friendlyName = arduinoioapplet.internal.Utility.getFriendlyName();
            end
        end

        function validateBoard(obj, boardName)
            % Function to validate the user selected board name

            if strcmpi(boardName, "Select board")
                obj.showErrorDlg(getString(message("MATLAB:arduinoio:arduinoapp:boardInvalid")));
            end
        end

        function validateAddress(obj, address)
            % Function to validate the user selected port number

            IPAddressPattern = digitsPattern(1,3)+"."+digitsPattern(1,3)+"."+digitsPattern(1,3)+"."+digitsPattern(1,3);
            % For USB connections
            if strcmpi(address, "Select port")
                obj.showErrorDlg(getString(message("MATLAB:arduinoio:arduinoapp:COMPortInvalid")));
            end
            % For Bluetooth and WiFi connections
            if isempty(address) ||...
                    (strcmpi(obj.ConnectionType,"WiFi") && ~matches(address,IPAddressPattern))
                obj.showErrorDlg(getString(message("MATLAB:arduinoio:arduinoapp:addressInvalid")));
            end
        end

        function validatePort(obj, port)
            % Function to validate the user selected port number

            % Port input is optional. Validate port only if user has entered a value.
            if port~="" && isnan(str2double(port))
                obj.showErrorDlg(getString(message("MATLAB:arduinoio:arduinoapp:portInvalid")));
            end
            obj.TCPPort = port;
        end

        function iconPath = getDeviceIconPath(~,boardName)
            % Function to pick the right display icon for Arduino in the
            % hardware device cards

            import arduinoioapplet.internal.ArduinoAppConstants
            % Get form factor type
            formFactor = arduinoioapplet.internal.Utility.getBoardFormFactor(boardName);
            if isequal(formFactor,arduinoioapplet.internal.FormFactorTypesEnum.Large)
                icon = ArduinoAppConstants.LargeFFIcon;
            elseif isequal(formFactor,arduinoioapplet.internal.FormFactorTypesEnum.Medium)
                icon = ArduinoAppConstants.MediumFFIcon;
            else
                icon = ArduinoAppConstants.SmallFFIcon;
            end
            % Form the complete icon path
            iconPath = fullfile(ArduinoAppConstants.DeviceIconFolder,icon);
        end

        function showErrorDlg(obj,errMsg)
            % Function to filter and show the error message
            errMsg = arduinoioapplet.internal.Utility.removeHyperlinks(errMsg);
            close(obj.ProgressDialog);
            error(errMsg);
        end

    end
end

% LocalWords:  Bluetooth WiFi Cancelable HWMGR TCP
