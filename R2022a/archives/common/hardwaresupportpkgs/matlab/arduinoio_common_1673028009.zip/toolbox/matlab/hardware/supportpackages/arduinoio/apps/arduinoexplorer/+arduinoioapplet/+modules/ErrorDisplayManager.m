classdef ErrorDisplayManager < matlabshared.mediator.internal.Subscriber
    % ERRORDISPLAYMANAGER - Module that is responsible for displaying the
    % Error dialogs within the Arduino Explorer app

    % Copyright 2021 The MathWorks, Inc.

    properties
        % 'AppName' will be displayed on the error dialog title
        AppName
    end

    % Properties to be published
    properties (SetObservable)
        % Main app module that is responsible for instantiating ErrorDisplayManager is
        % listening to this property, in order to request Hardware Manager
        % to display an error dialog.
        ErrorInfo
    end

    methods
        function obj = ErrorDisplayManager(mediator, appName)
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            obj.AppName = appName;
        end

        function subscribeToMediatorProperties(obj, ~, ~)
            obj.subscribe('ErrorObj', @(src, event)obj.requestErrorDialog(event.AffectedObject.ErrorObj));
        end

        function requestErrorDialog(obj, errObj)
            errorInfo.Title = getString(message('MATLAB:arduinoio:arduinoapp:errorDlgTitle',obj.AppName));
            errorInfo.Message = arduinoioapplet.internal.Utility.removeHyperlinks(errObj.message);
            obj.ErrorInfo = errorInfo;
        end
    end
end

% LocalWords:  arduinoapp
