classdef ConfigurePinPanelManager < matlabshared.mediator.internal.Publisher...
        & matlabshared.mediator.internal.Subscriber...
        & arduinoioapplet.modules.internal.ErrorSource
    % CONFIGUREPINPANELMANAGER - Class that handles creation and interaction
    % of the widgets in the configure pin property panel

    % Copyright 2021 The MathWorks, Inc.

    properties (Access = private)

        % Resources for updating pin table and getting resources
        % from the Arduino board
        PinTableManager
        ArduinoManager

        % Handle to the app container for displaying dialogs
        AppDialogParent

        % Set of all supported Arduino Pin Modes
        SupportedPinModes

        % Pin configuration panel and the grid inside the panel
        PinConfigPanel
        PinConfigPanelGrid

        % Pin configuration parent grid given by the PinTableManager
        PinConfigParentGrid

        % Area for Pin, Mode, Mode type, and Custom Name fields
        SelectPinLabel
        PanelHeader
        ModeLabel
        ModeDropDown
        ModeTypeLabel
        ModeTypeDropDown
        CustomNameLabel
        CustomNameEditField
        ConfigureButton

        % Maps listing pins- mode and pin-custom name pairs of each pin
        PinModeMap
        PinCustomNameMap

        % Listener handles for widgets in the panel
        ModeDropDownListener
        ModeTypeDropDownListener
        ConfigureButtonListener
        CustomNameListener

        % Current pin selected in the panel
        CurrentPinSelection

        % Pin modes that are not supported in the first version of the Arduino Explorer app
        UnsupportedPinModes = {'CAN','I2C','Serial','SPI','Ultrasonic'};
    end

    %% Constant properties
    properties(Constant,Access=private)

        % Mode types for Tone and PWM tone modes
        ToneModes = {'Duration','Frequency'};
        PWMModes = {'Voltage','Duty cycle'};

        % Parent grid dimensions
        PinConfigPanelGridRowHeight = {'fit','0.2x','fit','fit','fit','2x'}
        PinConfigPanelGridColumnWidth = {'0.5x','1x'}
        PinConfigPanelGridPadding = [10 10 10 10]
        PinConfigPanelGridSpacing = [15 10]

        % Initial grid row heights with only "Select Pin" label
        InitialPinConfigPanelGridRowHeight = {'0.5x','fit','0.5x'};

        % Select pin info label
        SelectPinLabelColor = "#535353"
        ConfiguirePinTextColor = "#535353"
        DefaultBackgroundColor = arduinoioapplet.internal.ArduinoAppConstants.DefaultBackgroundColor

        % Panel header
        PanelHeaderFontSize = 16
        ConfigureButtonFontSize = 14

        % Widget positions
        SelectPinLabelPosition = {[1,2],1}
        ConfigPinTitlePosition = {1,[1,2]}
        ModeLabelPosition = {3,1}
        ModeDropDownPosition = {3,2}
        ModeTypeLabelPosition = {5,1}
        ModeTypeDropDownPosition = {5,2}
        CustomNameLabelPosition = {4,1}
        CustomNameEditFieldPosition = {4,2}

        % Confirm button position and dimensions
        ConfigureButtonPosition = {2,1}
    end

    %% Public methods
    methods
        %Constructor
        function obj = ConfigurePinPanelManager(pinTableManager,mediator,dialogParent,arduinoManager,pinConfigGrid)
            % Call the superclass constructors

            obj@matlabshared.mediator.internal.Publisher(mediator);
            obj@matlabshared.mediator.internal.Subscriber(mediator);
            obj.PinTableManager = pinTableManager;
            obj.AppDialogParent = dialogParent;
            obj.ArduinoManager = arduinoManager;
            obj.PinConfigParentGrid = pinConfigGrid;

            % Add Servo to the list of unsupported pin modes if Arduino board does not have the library
            if ~obj.ArduinoManager.isLibraryUploaded('Servo')
                obj.UnsupportedPinModes{end+1} = 'Servo';
            end
            % Get the list of all supported pin modes currently supported in the app
            obj.SupportedPinModes = setdiff(obj.ArduinoManager.AllPinModes,...
                obj.UnsupportedPinModes);

            % Display info text to select pin to configure
            obj.createSelectPinLabel();
        end

        function subscribeToMediatorProperties(obj,~,~)
            % Function to subscribe to mediator events
            obj.subscribe('UserConfirmedNewSession', @(src, event)obj.handleNewSessionRequest());
            obj.subscribe('CurrentPinSelection', @(src, event)obj.handlePinSelection(event.AffectedObject));
            obj.subscribe('UserRequestedStartRecording', @(src, event)obj.handleRecordingStartRequest());
            obj.subscribe('UserRequestedStopRecording', @(src, event)obj.handleRecordingStopRequest());
            obj.subscribe('DataLoggedToWorkspace', @(src, event)obj.handleRecordingStopRequest());
        end
    end

    methods(Access = private)
        function handleNewSessionRequest(obj)
            % Function to handle new session request

            % Destroy the existing pin selection and config grid
            delete(obj.PinConfigPanelGrid);
            delete(obj.PinConfigPanel);
            obj.createSelectPinLabel();
            obj.clearPinSelection();
        end

        function handlePinSelection(obj,eventObj)
            % Function to handle pin selection

            if isempty(obj.CurrentPinSelection)
                obj.CurrentPinSelection = eventObj.CurrentPinSelection;
                obj.renderPinConfigPanel();
            else
                obj.CurrentPinSelection = eventObj.CurrentPinSelection;
                obj.updatePinConfigPanel();
            end
        end

        function handleModeChanged(obj,eventData)
            % Callback function to handle change in pin mode selection
            obj.CustomNameEditField.Enable = "on";
            obj.updateCustomName();
            if strcmpi(eventData.Value, "PWM")
                obj.ModeTypeLabel.Text = getString(message("MATLAB:arduinoio:arduinoapp:pwmModeTypeLabel"));
                obj.ModeTypeLabel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:pwmModeTypeDescription"));
                obj.ModeTypeDropDown.Items = obj.PWMModes;
                obj.ModeTypeDropDown.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:pwmModeTypeDescription"));
                obj.ModeTypeDropDown.Visible = "on";
                obj.ModeTypeLabel.Visible = "on";
            elseif strcmpi(eventData.Value, "Tone")
                obj.ModeTypeLabel.Text = getString(message("MATLAB:arduinoio:arduinoapp:toneModeTypeLabel"));
                obj.ModeTypeLabel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:toneModeTypeDescription"));
                obj.ModeTypeDropDown.Items = obj.ToneModes;
                obj.ModeTypeDropDown.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:toneModeTypeDescription"));
                obj.ModeTypeDropDown.Visible = "on";
                obj.ModeTypeLabel.Visible = "on";
            elseif strcmpi(eventData.Value,"Unset")
                obj.CustomNameEditField.Enable = "off";
                obj.ModeTypeLabel.Text = "";
                obj.ModeTypeDropDown.Items = {};
                obj.ModeTypeDropDown.Visible = "off";
                obj.ModeTypeLabel.Visible = "off";
            else
                obj.ModeTypeLabel.Text = "";
                obj.ModeTypeDropDown.Items = {};
                obj.ModeTypeDropDown.Visible = "off";
                obj.ModeTypeLabel.Visible = "off";
            end

            % Enable configure button if selected mode is different than current mode
            % or if there are multiple pins selected
            if length(obj.CurrentPinSelection) > 1 || ~strcmpi(eventData.Value,obj.getPinMode(obj.CurrentPinSelection))
                obj.ConfigureButton.Enable = "on";
            end

        end

        function handleModeTypeChanged(obj)
            % Function to handle change in mode type
            [~,type] = obj.getPinMode(obj.CurrentPinSelection);
            % Enable configure pin button if the current mode type selection
            % is different from the pins configured mode type
            if ~strcmpi(type,obj.ModeTypeDropDown.Value)
                obj.ConfigureButton.Enable = "on";
            end
        end

        function handleCustomNameChanged(obj,eventData)
            % Function to handle custom name change

            prevName = eventData.PreviousValue;
            % Validate if custom name contains only alphanumeric character
            if(validateCustomName(obj,eventData.Value))
                errObj = MException('MATLAB:arduinoio:arduinoapp:invalidCustomName',...
                    getString(message('MATLAB:arduinoio:arduinoapp:invalidCustomName')));
                obj.setErrorObjProperty(errObj);
                obj.CustomNameEditField.Value = prevName;
                return;
            end

            if length(obj.CurrentPinSelection) == 1
                customName = getCustomName(obj.PinTableManager,obj.CurrentPinSelection);
                if ~strcmpi(customName,eventData.Value)
                    obj.ConfigureButton.Enable = "on";
                end
            else
                obj.ConfigureButton.Enable = "on";
            end
        end

        function handleConfigureButtonClick(obj)
            % Callback function when user clicks "Configure" in the configure
            % pin property panel

            % Disable configuration property panel while pins are being configured
            obj.PinConfigPanel.Enable = "off";
            obj.ConfigureButton.Enable = "off";

            % Show busy indicator while the pin configuration is in progress
            obj.AppDialogParent.Busy = 1;
            try
                mode = obj.ModeDropDown.Value;
                % Save mode type with mode value
                if ~isempty(obj.ModeTypeDropDown.Value)
                    mode = sprintf("%s  (%s)",mode,obj.ModeTypeDropDown.Value);
                end

                % Save user selected configuration in map to be used for pin configuration
                for index = 1:length(obj.CurrentPinSelection)
                    pin = obj.CurrentPinSelection{index};
                    obj.PinModeMap(pin) = mode;
                    if obj.CustomNameEditField.Value == ""
                        obj.PinCustomNameMap(pin) = pin;
                    else
                        obj.PinCustomNameMap(pin) = obj.CustomNameEditField.Value;
                    end
                end
                % Invoke the update table function of PinTableManager to
                % configure the selected pin and to update the pin configuration table
                updatePinTable(obj.PinTableManager,obj.PinModeMap, obj.PinCustomNameMap);
            catch
                % Disable busy spinner and enable back property panel widgets
                % and configure button for retry
                obj.AppDialogParent.Busy = 0;
                obj.PinConfigPanel.Enable = "on";
                obj.ConfigureButton.Enable = "on";
                obj.clearMaps();
            end

            % Disable busy spinner and enable back property panel widgets.
            % Keep configure button disabled if config was successful.
            obj.AppDialogParent.Busy = 0;
            obj.PinConfigPanel.Enable = "on";
            obj.clearMaps();
        end

        function handleRecordingStartRequest(obj)
            % Callback function to react to start of recording
            obj.PinConfigPanel.Enable = "off";
            obj.ConfigureButton.Enable = "off";
        end

        function handleRecordingStopRequest(obj)
            % Callback function to react to end of recording
            obj.PinConfigPanel.Enable = "on";
            obj.ConfigureButton.Enable = "on";
        end
    end

    methods(Access = private)

        function createSelectPinLabel(obj)
            % Function to create info message asking users to select a pin to configure

            % Create initial pin configuration panel
            obj.PinConfigPanel = uipanel(obj.PinConfigParentGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.PinConfigPanel.Layout.Row = obj.SelectPinLabelPosition{1};
            obj.PinConfigPanel.Layout.Column = obj.SelectPinLabelPosition{2};

            % Create the grid to host the pin configuration property panel
            obj.PinConfigPanelGrid = uigridlayout(obj.PinConfigPanel,"Scrollable","on",...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.PinConfigPanelGrid.RowHeight = obj.InitialPinConfigPanelGridRowHeight;
            obj.PinConfigPanelGrid.ColumnWidth = obj.PinConfigPanelGridColumnWidth;
            obj.PinConfigPanelGrid.Padding = obj.PinConfigPanelGridPadding;

            % Place info label in the center of the initial grid layout
            obj.SelectPinLabel = uilabel(obj.PinConfigPanelGrid);
            obj.SelectPinLabel.Tag = "Select Pin Message";
            obj.SelectPinLabel.Text = getString(message("MATLAB:arduinoio:arduinoapp:selectPinText"));
            obj.SelectPinLabel.Layout.Row = 2;
            obj.SelectPinLabel.Layout.Column = [1 2];
            obj.SelectPinLabel.FontColor = obj.SelectPinLabelColor;
            obj.SelectPinLabel.FontWeight = 'bold';
            obj.SelectPinLabel.HorizontalAlignment = "center";
            obj.SelectPinLabel.WordWrap = "on";
            obj.SelectPinLabel.FontSize = obj.PanelHeaderFontSize;
        end

        function renderPinConfigPanel(obj)
            % Function to render the widgets in the configure pin property panel
            createPinConfigPanel(obj);
            updatePinConfigPanel(obj);
            addWidgetListeners(obj);
        end

        function createPinConfigPanel(obj)
            % Container to store pin and corresponding mode
            obj.PinModeMap = containers.Map();
            obj.PinCustomNameMap = containers.Map();

            % Delete the select pin label
            delete(obj.SelectPinLabel);
            delete(obj.PinConfigPanelGrid);
            delete(obj.PinConfigPanel);

            % Create initial pin configuration panel
            obj.PinConfigPanel = uipanel(obj.PinConfigParentGrid);
            obj.PinConfigPanel.Layout.Row = 1;
            obj.PinConfigPanel.Layout.Column = 1;

            % Create parent grid layout in the property panel
            obj.PinConfigPanelGrid = uigridlayout(obj.PinConfigPanel,"Scrollable","on",...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.PinConfigPanelGrid.RowHeight = obj.PinConfigPanelGridRowHeight;
            obj.PinConfigPanelGrid.ColumnWidth = obj.PinConfigPanelGridColumnWidth;
            obj.PinConfigPanelGrid.Padding = obj.PinConfigPanelGridPadding;
            obj.PinConfigPanelGrid.RowSpacing = obj.PinConfigPanelGridSpacing(1);

            % Create pin selection header
            obj.PanelHeader = uilabel(obj.PinConfigPanelGrid);
            obj.PanelHeader.Tag = "Configure Pin";
            obj.PanelHeader.HorizontalAlignment = "left";
            obj.PanelHeader.Text = " ";
            obj.PanelHeader.FontColor = obj.ConfiguirePinTextColor;
            obj.PanelHeader.Layout.Row = obj.ConfigPinTitlePosition{1};
            obj.PanelHeader.Layout.Column = obj.ConfigPinTitlePosition{2};
            obj.PanelHeader.FontWeight = "bold";
            obj.PanelHeader.FontSize = obj.ConfigureButtonFontSize;

            % Create Arduino pin mode section
            obj.ModeLabel = uilabel(obj.PinConfigPanelGrid);
            obj.ModeLabel.Tag = "Pin Mode";
            obj.ModeLabel.HorizontalAlignment = "right";
            obj.ModeLabel.Text = getString(message("MATLAB:arduinoio:arduinoapp:modeLabel"));
            obj.ModeLabel.Layout.Row = obj.ModeLabelPosition{1};
            obj.ModeLabel.Layout.Column = obj.ModeLabelPosition{2};
            obj.ModeLabel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:modeDescription"));
            obj.ModeLabel.WordWrap = "off";

            obj.ModeDropDown = uidropdown(obj.PinConfigPanelGrid);
            obj.ModeDropDown.Layout.Row = obj.ModeDropDownPosition{1};
            obj.ModeDropDown.Layout.Column = obj.ModeDropDownPosition{2};
            obj.ModeDropDown.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:modeDescription"));
            obj.ModeDropDown.Tag = "PinMode DropDown";

            % Create Arduino mode type contextual section
            obj.ModeTypeLabel = uilabel(obj.PinConfigPanelGrid);
            obj.ModeTypeLabel.HorizontalAlignment = "right";
            obj.ModeTypeLabel.Text = "";
            obj.ModeTypeLabel.Layout.Row = obj.ModeTypeLabelPosition{1};
            obj.ModeTypeLabel.Layout.Column = obj.ModeTypeLabelPosition{2};
            obj.ModeTypeLabel.Visible = "off";
            obj.ModeTypeLabel.WordWrap = "off";

            obj.ModeTypeDropDown = uidropdown(obj.PinConfigPanelGrid);
            obj.ModeTypeDropDown.Items = {};
            obj.ModeTypeDropDown.Layout.Row = obj.ModeTypeDropDownPosition{1};
            obj.ModeTypeDropDown.Layout.Column = obj.ModeTypeDropDownPosition{2};
            obj.ModeTypeDropDown.Visible = "off";
            obj.ModeTypeDropDown.Tag = "PinModeType DropDown";

            % Create Arduino pin custom name section
            obj.CustomNameLabel = uilabel(obj.PinConfigPanelGrid);
            obj.CustomNameLabel.Tag = "Custom Name";
            obj.CustomNameLabel.Text = getString(message("MATLAB:arduinoio:arduinoapp:customNameLabel"));
            obj.CustomNameLabel.Layout.Row = obj.CustomNameLabelPosition{1};
            obj.CustomNameLabel.Layout.Column = obj.CustomNameLabelPosition{2};
            obj.CustomNameLabel.HorizontalAlignment = "right";
            obj.CustomNameLabel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:customNameDescription"));
            obj.CustomNameLabel.WordWrap = "off";

            obj.CustomNameEditField = uieditfield(obj.PinConfigPanelGrid);
            obj.CustomNameEditField.Layout.Row = obj.CustomNameEditFieldPosition{1};
            obj.CustomNameEditField.Layout.Column = obj.CustomNameEditFieldPosition{2};
            obj.CustomNameEditField.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:customNameDescription"));
            obj.CustomNameEditField.Tag = "CustomName Field";

            % Create configure button
            obj.ConfigureButton = uibutton(obj.PinConfigParentGrid,...
                "BackgroundColor",obj.DefaultBackgroundColor);
            obj.ConfigureButton.Layout.Row = obj.ConfigureButtonPosition{1};
            obj.ConfigureButton.Layout.Column = obj.ConfigureButtonPosition{2};
            obj.ConfigureButton.FontSize = obj.ConfigureButtonFontSize;
            obj.ConfigureButton.FontWeight = "bold";
            obj.ConfigureButton.FontColor = obj.ConfiguirePinTextColor;
            obj.ConfigureButton.Enable = "off";
            obj.ConfigureButton.Text = getString(message("MATLAB:arduinoio:arduinoapp:configButtonLabel"));
            obj.ConfigureButton.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:configButtonDescription"));
            obj.ConfigureButton.Tag = "Configure Button";
        end

        function updatePinConfigPanel(obj)
            % Function to initialize contents of the pin configuration panel

            % If single selection - populate current setting of the pin in the panel
            % If there are multiple selections, show common pin modes
            if length(obj.CurrentPinSelection) == 1
                obj.PanelHeader.Text = getString(message("MATLAB:arduinoio:arduinoapp:configPinPanelHeader",obj.CurrentPinSelection));
                obj.PanelHeader.Tooltip = obj.PanelHeader.Text;
                obj.ModeDropDown.Items = getSupportedModesFromPin(obj,obj.CurrentPinSelection);
                [mode,type] = obj.getPinMode(obj.CurrentPinSelection);
                obj.ModeDropDown.Value = mode;
                handleModeChanged(obj,obj.ModeDropDown);
                if ~isempty(type)
                    obj.ModeTypeDropDown.Value = type;
                end
                updateCustomName(obj);
            else
                obj.PanelHeader.Text = getString(message("MATLAB:arduinoio:arduinoapp:configPinPanelHeader",...
                    join(obj.CurrentPinSelection,", ")));
                obj.PanelHeader.Tooltip = obj.PanelHeader.Text;
                obj.ModeDropDown.Items = obj.getCommonPinModes(obj.CurrentPinSelection);
                obj.ModeDropDown.Value = "Unset";
                obj.CustomNameEditField.Enable = "off";
                obj.ModeTypeLabel.Text = "";
                obj.ModeTypeDropDown.Items = {};
                obj.ModeTypeDropDown.Visible = "off";
                obj.ModeTypeLabel.Visible = "off";
                obj.ConfigureButton.Enable = "on";
                updateCustomName(obj);
            end

            % Disable the configure pin panel if pin is reserved by some other mode
            checkIfPinReserved(obj);
        end

        function checkIfPinReserved(obj)
            % Function to check if one of the pin selected is reserved by some
            % other pin mode or interface. If the pin is reserved, disable the
            % pin configuration panel and show tooltip informing user of this.

            pinModes = cellfun(@(x)obj.ArduinoManager.getPinMode(x),obj.CurrentPinSelection,...
                'UniformOutput',false);
            % Find the index of reserved pin
            reservedPinIndex = find(ismember(pinModes,"Reserved"),1);

            if ~isempty(reservedPinIndex)
                pin = obj.CurrentPinSelection(reservedPinIndex);
                [resourceOwner, mode] = obj.ArduinoManager.getPinInfo(pin);
                obj.PinConfigPanel.Enable = "off";
                obj.ConfigureButton.Enable = "off";
                obj.PinConfigPanel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:reservedPin",...
                    pin,resourceOwner,mode));
                obj.ConfigureButton.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:reservedPin",...
                    pin,resourceOwner,mode));
            else
                obj.PinConfigPanel.Enable = "on";
                obj.PinConfigPanel.Tooltip = "";
                obj.ConfigureButton.Enable = "on";
                obj.ConfigureButton.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:configButtonDescription"));
            end
        end

        function updateCustomName(obj)
            % Function to update the custom name field

            if length(obj.CurrentPinSelection) == 1
                customName = getCustomName(obj.PinTableManager,obj.CurrentPinSelection);
                if(~isempty(customName))
                    obj.CustomNameEditField.Value = customName;
                else
                    obj.CustomNameEditField.Value = obj.CurrentPinSelection;
                end
            end
            % Set custom name as empty if the selected mode is unset
            if strcmpi(obj.ModeDropDown.Value,"Unset")
                obj.CustomNameEditField.Value = "";
            end
        end

        function status = validateCustomName(~,name)
            % Function to validate the custom name.
            % Return status = 1 if the custom name contains special symbols other than alphanumeric characters
            status = 0;
            if ~isempty(name) && ~matches(name,alphanumericsPattern)
                status = 1;
            end
        end

        function modes = getSupportedModesFromPin(obj,pin)
            % Get a list of all supported modes for the specified pin
            modes = getSupportedModesFromPin(obj.ArduinoManager,pin);
            modes = setdiff(modes,obj.UnsupportedPinModes);
        end

        function commonModes = getCommonPinModes(obj,pins)
            % Find common available pin modes
            commonModes = [];
            modes = arrayfun(@(x) obj.getSupportedModesFromPin(x),pins,'UniformOutput',false);
            for index = 1:length(modes)-1
                commonModes = intersect(modes{index},modes{index+1});
            end
        end

        function [mode,type] = getPinMode(obj,pin)
            % Function to get the current mode of a specified Arduino pin
            [mode,type] = getPinMode(obj.PinTableManager,pin);
        end

        function addWidgetListeners(obj)
            % Register listeners for property panel buttons
            obj.ModeDropDownListener = obj.ModeDropDown.listener('ValueChanged',@(src,event)obj.handleModeChanged(event));
            obj.ModeTypeDropDownListener = obj.ModeTypeDropDown.listener('ValueChanged',@(src,event)obj.handleModeTypeChanged());
            obj.CustomNameListener = obj.CustomNameEditField.listener('ValueChanged',@(src,event)obj.handleCustomNameChanged(event));
            obj.ConfigureButtonListener = obj.ConfigureButton.listener('ButtonPushed',@(src,event)obj.handleConfigureButtonClick());
        end

        function clearMaps(obj)
            % Function to clear the maps
            obj.PinModeMap = containers.Map();
            obj.PinCustomNameMap = containers.Map();
        end

        function clearPinSelection(obj)
            obj.CurrentPinSelection = [];
        end
    end
end

% LocalWords:  SPI
