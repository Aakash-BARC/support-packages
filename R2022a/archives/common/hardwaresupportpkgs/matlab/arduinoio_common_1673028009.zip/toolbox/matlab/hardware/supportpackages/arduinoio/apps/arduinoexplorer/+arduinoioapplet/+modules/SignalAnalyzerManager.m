classdef SignalAnalyzerManager < matlabshared.mediator.internal.Publisher...
        & matlabshared.mediator.internal.Subscriber

    % SIGNALANALYZERMANAGER - Module that handles the launch of Signal
    % Processing Toolbox's Signal Analyzer App.

    % Copyright 2021 The MathWorks, Inc.

    properties(Access = private)

        AppName = getString(message('MATLAB:arduinoio:arduinoapp:signalAnalyzerAppTitle'))
        ToolboxInstalled = ~isempty(ver('signal'))

        LastRecordedVariableName = ''
        AppDialogParent
    end

    % Properties to be published
    properties (SetObservable)
        % Note: Applet main class (i.e.'ArduinoExplorerApplet') that is responsible
        % for instantiating this class is listening to this property, in
        % order to request Hardware Manager to display an error dialog.
        ErrorInfo
    end

    methods
        function obj =  SignalAnalyzerManager(mediator,dialogParent)
            % Call the superclass constructor
            obj@matlabshared.mediator.internal.Publisher(mediator);
            obj@matlabshared.mediator.internal.Subscriber(mediator);
            obj.AppDialogParent = dialogParent;
        end

        function subscribeToMediatorProperties(obj, ~, ~)
            obj.subscribe('LastRecordedVariableName', @(src, event)obj.updateLastRecordedVariableName(event.AffectedObject.LastRecordedVariableName));
            obj.subscribe('UserRequestedSignalAnalyzerLaunch', @(src, event)obj.handleSignalAnalyzerLaunch());
        end

        function handleSignalAnalyzerLaunch(obj)

            yesOptionText = getString(message('MATLAB:arduinoio:arduinoapp:yesOptionText'));
            noOptionText = getString(message('MATLAB:arduinoio:arduinoapp:noOptionText'));

            % Installation check
            if ~obj.ToolboxInstalled
                warningStr = getString(message('MATLAB:arduinoio:arduinoapp:SPTNotIntalled'));
                selection = matlab.hwmgr.internal.DialogFactory.constructConfirmationDialog(obj.AppDialogParent,...
                    warningStr, obj.AppName,...
                    'Options', {yesOptionText, noOptionText},...
                    'DefaultOption', yesOptionText);
                result = strcmp(selection, yesOptionText);

                if result == 1
                    matlab.internal.addons.launchers.showExplorer("ArduinoExplorer", "identifier", "SG");
                end
                return
            end

            % License check
            [checkoutLicense, errorMsg] = builtin('license','checkout','Signal_Toolbox');
            if ~checkoutLicense

                % Pop the error dialog
                errorInfo.Title = getString(message(...
                    'MATLAB:arduinoio:arduinoapp:errorDlgTitle',...
                    obj.AppName));
                errorInfo.Message = errorMsg;

                obj.ErrorInfo = errorInfo;
                return
            end
            % Open signal Analyzer app
            if ~arduinoioapplet.internal.Utility.isVariablePresentInBaseWorkspace(obj.LastRecordedVariableName)
                evalin('base', 'signalAnalyzer');
            else
                evalin('base', ['signalAnalyzer(' char(obj.LastRecordedVariableName) ')']);
            end
        end
    end

    methods(Access = private)
        function updateLastRecordedVariableName(obj, varName)
            obj.LastRecordedVariableName = varName;
        end
    end
end

% LocalWords:  arduinoapp SPTNotIntalled
