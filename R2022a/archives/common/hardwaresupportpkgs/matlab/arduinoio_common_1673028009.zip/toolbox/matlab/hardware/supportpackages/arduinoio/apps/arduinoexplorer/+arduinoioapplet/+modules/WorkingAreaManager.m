classdef WorkingAreaManager < matlabshared.mediator.internal.Subscriber
    %  WOKRINGAREAMANAGER - Module that manages the components that resides
    %  in the Applet space or working area of the Arduino Explorer app.

    %   This module manages the creation of the components that resides in
    %   the Applet space (Root pane)

    % Copyright 2021 The MathWorks, Inc.

    properties(Access = private)
        % Handle to the mediator module
        Mediator

        % Handle to the app's root window
        RootWindow

        % Handle to the app container for displaying dialogs
        AppDialogParent

        % Handle to the Arduino Manager module
        ArduinoManager

        % Parent UI app grid
        ParentGrid

        % Manager modules for the working area sections for
        % pinout, pintable, and plot area
        PinoutManager
        PinTableManager

        % Recording area and recording status objects
        RecordStatusGrid
        RecordStatusIcon
        RecordStatusText
        RecordPercentageText
        RecordProgressBar
        RemainingTimeText
        RecordingTimeText
        RecordDuration
        LastRecordedVariableName
    end

    properties(SetAccess = private, GetAccess = ?arduino.accessor.UnitTest)
        PlotManager
    end

    %% Constant properties used throughout the class
    properties(Constant, Access=private)

        % Applet space layout parameters
        RowHeight = {'1x',10,'1x','fit'}
        ColumnWidth = {'1x','0.2x'}
        RowSpacing = 0
        ColumnSpacing = 0
        Padding = [10 2 10 10]

        % Widget placements
        TablePanelPosition = {1,[1,2]}
        PlotPosition = {3,[1 2]}

        % Recording status text properties
        RecordingStatusFontSize = 12
        RecordingStatusColor = "#616161"

        % Recording area widget parameters
        RecordingProgressIcon = "Recording_Progress.png"
        RecordingCompleteIcon = "Recording_Complete.png"
        InitialRecordingPercentage = 0
        RecordingStatusPosition = {4,[1,2]}
        RecordingGridPadding = [0 5 10 10]
        RecordStatusGridRowHeight = {16}
        RecordStatusGridColumnWidth = {16,'fit',20,'fit',20,'1x','1.5x','fit','0.5x','fit'}
        RecordStatusIconPosition = {1,1}
        RecordStatusTextPosition = {1,2}
        RecordPercentageTextPosition = {1,4}
        RecordProgressBarPosition = {1,6}
        RemainingTimeTextPosition = {1,8}
        RecordingTimeTextPosition = {1,10}
    end

    %% Public methods
    methods
        % Constructor
        function obj = WorkingAreaManager(mediator,rootWindow,dialogParent,arduinoManager,initialWorkspaceVarName,initialRecordDuration)

            % Call the superclass constructor
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            obj.Mediator = mediator;
            obj.RootWindow = rootWindow;
            obj.AppDialogParent = dialogParent;
            obj.ArduinoManager = arduinoManager;
            obj.RecordDuration = initialRecordDuration;
            obj.LastRecordedVariableName = initialWorkspaceVarName;

            % Create ParentGrid- the uigridlayout that contains all components
            % of the applet space, including several
            % nested uigridlayouts.
            obj.ParentGrid = uigridlayout(obj.RootWindow,...
                'RowHeight',obj.RowHeight,...
                'ColumnWidth',obj.ColumnWidth,...
                'RowSpacing',obj.RowSpacing,...
                'ColumnSpacing',obj.ColumnSpacing,...
                'Padding', obj.Padding);

            % Create and place widgets in the working area
            % Create Pin Table and populate it
            obj.PinTableManager = arduinoioapplet.modules.internal.PinTableManager(obj.Mediator,...
                obj.AppDialogParent,obj.ParentGrid,obj.TablePanelPosition,obj.ArduinoManager);

            % Create Plot section in the working area
            obj.PlotManager = arduinoioapplet.modules.internal.PlotManager(...
                obj.Mediator,obj.ParentGrid,obj.PlotPosition,obj.PinTableManager);

            % Create the pin out dialog manager
            obj.PinoutManager = arduinoioapplet.modules.internal.PinoutManager(getBoardName(obj.ArduinoManager));
            createRecordStatusGrid(obj);
            populateRecordStatusGrid(obj);
        end

        function subscribeToMediatorProperties(obj,~,~)
            % Function to subscribe to mediator events
            obj.subscribe('UserClickedViewPinout', @(src, event)obj.handlePinoutLaunch());
            obj.subscribe('UserRequestedStartRecording', @(src, event)obj.handleStartRecording());
            obj.subscribe('UserRequestedStopRecording', @(src, event)obj.handleStopRecording());
            obj.subscribe('DataLoggedToWorkspace', @(src, event)obj.handleStopRecording());
            obj.subscribe('LastRecordedVariableName', @(src, event)obj.setLastRecordedVariableName(event));
            obj.subscribe('CurrentDuration', @(src, event)obj.handleDurationEdit(event.AffectedObject.CurrentDuration));
            obj.subscribe('LoggingPercentage', @(src, event)obj.handleRecordingPercentage(event.AffectedObject));
        end

        function delete(~)

        end
    end

    methods(Hidden)
        function pinTableHandle = getPinTableHandle(obj)
            pinTableHandle = obj.PinTableManager;
        end
    end

    methods(Access=private)
        function createRecordStatusGrid(obj)
            % Function to create the grid to display record status
            obj.RecordStatusGrid = uigridlayout(obj.ParentGrid);
            obj.RecordStatusGrid.Padding = obj.RecordingGridPadding;
            obj.RecordStatusGrid.Layout.Row = obj.RecordingStatusPosition{1};
            obj.RecordStatusGrid.Layout.Column = obj.RecordingStatusPosition{2};
            obj.RecordStatusGrid.RowHeight = obj.RecordStatusGridRowHeight;
            obj.RecordStatusGrid.ColumnWidth = obj.RecordStatusGridColumnWidth;
        end

        function populateRecordStatusGrid(obj)
            % Function to populate contents of the record status area
            obj.RecordStatusIcon = uiimage(obj.RecordStatusGrid,"ScaleMethod","none");
            obj.RecordStatusIcon.ImageSource = fullfile(arduinoioapplet.internal.ArduinoAppConstants.PinoutImageFolder,obj.RecordingProgressIcon);
            obj.RecordStatusIcon.Layout.Row = obj.RecordStatusIconPosition{1};
            obj.RecordStatusIcon.Layout.Column = obj.RecordStatusIconPosition{2};
            obj.RecordStatusIcon.Visible = false;

            obj.RecordStatusText = uilabel(obj.RecordStatusGrid);
            obj.RecordStatusText.Tag = "Record Status";
            obj.RecordStatusText.HorizontalAlignment = "left";
            obj.RecordStatusText.Layout.Row = obj.RecordStatusTextPosition{1};
            obj.RecordStatusText.Layout.Column = obj.RecordStatusTextPosition{2};
            obj.RecordStatusText.FontSize = obj.RecordingStatusFontSize;
            obj.RecordStatusText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordingProgress"));
            obj.RecordStatusText.Visible = false;

            obj.RecordPercentageText = uilabel(obj.RecordStatusGrid);
            obj.RecordPercentageText.Tag = "Record Percentage";
            obj.RecordPercentageText.HorizontalAlignment = "left";
            obj.RecordPercentageText.Layout.Row = obj.RecordPercentageTextPosition{1};
            obj.RecordPercentageText.Layout.Column = obj.RecordPercentageTextPosition{2};
            obj.RecordPercentageText.FontSize = obj.RecordingStatusFontSize;
            obj.RecordPercentageText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordingPercentage",num2str(obj.InitialRecordingPercentage)));
            obj.RecordPercentageText.Visible = false;

            obj.RecordProgressBar = matlab.ui.control.internal.ProgressIndicator('Parent',obj.RecordStatusGrid);
            obj.RecordProgressBar.Layout.Row = obj.RecordProgressBarPosition{1};
            obj.RecordProgressBar.Layout.Column = obj.RecordProgressBarPosition{2};
            obj.RecordProgressBar.Visible = false;

            obj.RemainingTimeText = uilabel(obj.RecordStatusGrid);
            obj.RemainingTimeText.Tag = "Remaining Time";
            obj.RemainingTimeText.HorizontalAlignment = "right";
            obj.RemainingTimeText.Layout.Row = obj.RemainingTimeTextPosition{1};
            obj.RemainingTimeText.Layout.Column = obj.RemainingTimeTextPosition{2};
            obj.RemainingTimeText.FontSize = obj.RecordingStatusFontSize;
            obj.RemainingTimeText.Text = getString(message("MATLAB:arduinoio:arduinoapp:remainingTime",num2str(obj.RecordDuration)));
            obj.RemainingTimeText.Visible = false;

            obj.RecordingTimeText = uilabel(obj.RecordStatusGrid);
            obj.RecordingTimeText.Tag = "Duration";
            obj.RecordingTimeText.HorizontalAlignment = "right";
            obj.RecordingTimeText.Layout.Row = obj.RecordingTimeTextPosition{1};
            obj.RecordingTimeText.Layout.Column = obj.RecordingTimeTextPosition{2};
            obj.RecordingTimeText.FontSize = obj.RecordingStatusFontSize;
            obj.RecordingTimeText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordDuration",num2str(obj.RecordDuration)));
            obj.RecordingTimeText.Visible = false;
        end

        function handlePinoutLaunch(obj)
            % Callback function to handle "View Pinout" button click
            launchPinoutDialog(obj.PinoutManager);
        end

        function handleStartRecording(obj)
            % Show recording status in the bottom panel
            obj.RecordStatusIcon.ImageSource = fullfile(arduinoioapplet.internal.ArduinoAppConstants.PinoutImageFolder,obj.RecordingProgressIcon);
            obj.RecordStatusText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordingProgress"));
            obj.RecordPercentageText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordingPercentage",num2str(obj.InitialRecordingPercentage)));
            obj.RecordProgressBar.Value = 0;
            obj.RemainingTimeText.Text = getString(message("MATLAB:arduinoio:arduinoapp:remainingTime",num2str(obj.RecordDuration)));
            obj.RecordingTimeText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordDuration",num2str(obj.RecordDuration)));

            % Show all widgets
            obj.RecordStatusIcon.Visible = true;
            obj.RecordStatusText.Visible = true;
            obj.RecordPercentageText.Visible = true;
            obj.RecordProgressBar.Visible = true;
            obj.RemainingTimeText.Visible = true;
            obj.RecordingTimeText.Visible = true;
        end

        function handleRecordingPercentage(obj,eventObj)
            % Function to display recording progress
            obj.RecordStatusText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordingProgress"));
            obj.RecordPercentageText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordingPercentage",num2str(eventObj.LoggingPercentage)));
            obj.RecordProgressBar.Value = eventObj.LoggingPercentage/100;
            remainingTime = floor((1-obj.RecordProgressBar.Value)*obj.RecordDuration);
            obj.RemainingTimeText.Text = getString(message("MATLAB:arduinoio:arduinoapp:remainingTime",num2str(remainingTime)));
        end

        function handleDurationEdit(obj,value)
            % Function to update the duration to record
            obj.RecordDuration = value;
        end

        function handleStopRecording(obj)
            % Update record status icon and text
            obj.RecordStatusIcon.ImageSource = fullfile(arduinoioapplet.internal.ArduinoAppConstants.PinoutImageFolder,obj.RecordingCompleteIcon);
            obj.RecordStatusText.Text = getString(message("MATLAB:arduinoio:arduinoapp:recordingComplete",string(obj.LastRecordedVariableName)));
            % Hide remaining widgets
            obj.RecordPercentageText.Visible = false;
            obj.RecordProgressBar.Visible = false;
            obj.RemainingTimeText.Visible = false;
            obj.RecordingTimeText.Visible = false;
        end

        function setUserClickedRootWindow(obj)
            % Callback function to notify about the app root window click
            obj.UserClickedRootWindow = true;
        end

        function setLastRecordedVariableName(obj,eventData)
            obj.LastRecordedVariableName = eventData.AffectedObject.LastRecordedVariableName;
        end
    end
end

% LocalWords:  WOKRINGAREAMANAGER app's pinout pintable uigridlayout uigridlayouts
