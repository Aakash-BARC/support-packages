classdef GenerateScriptUtil < handle
    % GENERATESCRIPTUTIL is a utility class that is used to generate MATLAB code.
    % The Text is the content of the script that gets generated.

    %  Copyright 2021 The MathWorks, Inc.

    properties(Access = private)
        % The text of the generated script, containing the comments and the
        % code.
        Text = ""

        % The limit for the number of characters in a comment line. Words
        % exceeding this limit will go to the next comment line
        CommentLength = 90
    end

    properties (Constant, Hidden)
        FourWhiteSpaces = "    "
    end

    methods
        function text = getText(obj)
            % Returns the Text of the Generate Code Helper
            text = obj.Text;
        end

        function text = setText(obj, text)
            % Set the text value of the Generate Code Helper. This could be
            % useful if the user has his string ready externally to be generated as a
            % script, assign the text and generate the script.
            obj.Text = text;
        end

        function addNewLine(obj)
            % Adds an empty new line to the Text. Syntax:
            % generateScriptUtil.addNewLine();
            % This adds a newline to text.
            obj.Text = obj.Text + newline;
        end

        function addSectionHeader(obj, sectionHeaderText)
            % Adds a Section Header to Text on a newline.
            % Syntax:
            % generateScriptUtil.addSectionHeader("This is a Section Header");
            % This adds
            % %% This is a Section Header
            % to the Text.
            sectionHeaderText = string(sectionHeaderText);
            sectionHeaderText = "%% " + sectionHeaderText;
            obj.addText(sectionHeaderText);
        end

        function addComment(obj, commentText)
            % Adds Comment to Text on a newline. The
            % comment is formatted such that words fitting inside obj.CommentLength
            % number of characters are fitted in 1 line. Words exceeding
            % obj.CommentLength are moved to a new line.
            % Syntax:
            % generateScriptUtil.addComment("This is a Multi Line Comment");
            % This adds
            %   % This is a Comment
            % to the Text.

            % Convert commentText to string.
            commentText = string(commentText);

            % Split the words in the string. Delimiter - " "
            commentTextSplit = split(commentText);

            eachCommentLine = "";
            finalCommentLine = "";

            % Split the words of the comment, based on the value of
            % numchars.
            for i = 1 : length(commentTextSplit)
                if i == 1
                    % For the first line of the multi line comment
                    eachCommentLine = eachCommentLine + "% " + commentTextSplit(i);

                elseif (strlength(eachCommentLine) + strlength(commentTextSplit(i))) < obj.CommentLength
                    % If the words have not exceeded the numChars for a line yet.
                    eachCommentLine = eachCommentLine + " " + commentTextSplit(i);

                else
                    % If the words have exceeded numChars number of
                    % characters on a line.
                    if strlength(finalCommentLine) == 0
                        % Put the created string into the first line of
                        % the comment.
                        finalCommentLine = finalCommentLine + eachCommentLine;
                    else
                        % Put the created string into the next line of
                        % the comment.
                        finalCommentLine = finalCommentLine + newline + eachCommentLine;
                    end

                    % Add the new word to the new line.
                    eachCommentLine = "% " + commentTextSplit(i);
                end
            end

            % If the finalCommentLine is not empty, add the
            % 'eachCommentLine' on a new line
            if strlength(finalCommentLine) ~= 0
                finalCommentLine = finalCommentLine + newline + eachCommentLine;
            else
                % Else add it to the same line.
                finalCommentLine = eachCommentLine;
            end
            obj.addText(finalCommentLine);
        end

        function addCodeLineWithSemiColon(obj, codeText)
            % Adds a code line to Text on a newline. If the line of code
            % does not end with semi-colon, automatically assign semicolon
            % to the end of the code line. If the line ends with a
            % semicolon, does not add new semicolon to the end of the line.
            % Syntax:
            % generateScriptUtil.addCodeLineWithSemiColon("a = 5");
            % This adds
            %   a = 5;
            % to the Text.
            %
            % generateScriptUtil.addCodeLineWithSemiColon("b = 10;");
            % This adds
            %   b = 10;
            % to the Text.
            codeText = string(codeText);

            if ~endsWith(codeText, ";")
                codeText = codeText + ";";
            end
            obj.addText(codeText);
        end

        function addCodeLine(obj, codeText)
            % Adds a code line to Text on a newline. It does not check or
            % append semicolons. This could be useful for lines of code
            % that do not terminate with a semicolon, like loops,
            % conditional statements, etc.
            % Syntax:
            % generateScriptUtil.addCodeLine("if a == 5");
            % This adds
            %  if a == 5
            % to the Text.
            codeText = string(codeText);
            obj.addText(codeText);
        end

        function insertSpaces(obj, count)
            % Adds a white space to the string.
            % count - number of white spaces to add to string.
            %         Default: 1
            % generateScriptUtil.insertSpaces();
            % This adds 1 space
            narginchk(1, 2);
            if nargin == 1
                count = 1;
            end

            validateattributes(count, ...
                {'numeric'}, {'finite', 'nonnegative', 'nonzero' ,'nonempty', 'integer', 'scalar'});
            freeSpaces = repmat(" ", 1, count);
            freeSpaces = join(freeSpaces);
            obj.Text = obj.Text + freeSpaces;
        end

        function createMFile(obj)
            % Creates an untitled script in the MATLAB editor.
            mFileInstance = matlab.desktop.editor.newDocument(obj.Text);

            % Indent the contents.
            mFileInstance.smartIndentContents;
        end

        function createMLXFile(obj)
            % Creates an untitled MLX script in the MATLAB editor. No need
            % to indent as indentation happens automatically in an MLX.

            matlab.internal.liveeditor.openAsLiveCode(obj.Text);
        end

        function clearText(obj)
            % Clears the Text of the generate code helper.
            % Syntax:
            % generateScriptUtil.clearText();
            obj.Text = "";
        end
    end

    methods (Access = private)
        function addText(obj, text)
            if strlength(obj.Text) ~= 0
                obj.Text = obj.Text + newline + text;
            else
                obj.Text = obj.Text + text;
            end
        end
    end
end

% LocalWords:  numchars MLX
