classdef AppStateManager < matlabshared.mediator.internal.Publisher...
        & matlabshared.mediator.internal.Subscriber
    % APPSTATEMANAGER - Module that keeps track of the Arduino Explorer's
    % App modes and the dirty state.

    % Copyright 2021 The MathWorks, Inc.

    properties
        % Property to save the app data for restoring later
        AppData

        % Possible Modes - 'Preview' & 'Recording'
        Mode char {mustBeMember(Mode, {'Preview', 'Recording'})} = 'Preview'
    end

    properties(Access = private)
        % Mediator and pin table handle
        Mediator
        PinTableHandle

        DeviceInfo

        % Flag that keeps track if App close has been requested by other
        % modules
        AppCloseRequested = false

        % Flag that keeps track if the user made any device configuration
        % change in the app. Any edit to the Arduino pin mode validates to be a configuration change.
        DirtyState = false
    end

    % Properties to be published
    properties (SetObservable)
        % Property to which data will be written to when opening the app
        LoadedData
        % User requests to close the app
        UserRequestedAppClose
        RequestHardwareManagerToDestroyApp
    end
    %% Class methods
    methods
        function obj = AppStateManager(mediator, pinTableHandle)
            % Call the superclass constructors
            obj@matlabshared.mediator.internal.Publisher(mediator);
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            % Save the references
            obj.Mediator = mediator;
            obj.PinTableHandle = pinTableHandle;
        end

        function subscribeToMediatorProperties(obj, ~, ~)
            obj.subscribe('UserConfirmedNewSession', @(src, event)obj.handleNewSessionRequest());

            % Arduino Pin configuration edits
            obj.subscribe('UserConfiguredPins', @(src, event)obj.handlePinConfiguration());

            % Track App Modes
            obj.subscribe('UserRequestedStartRecording', @(src, event)obj.setMode('Recording'));
            obj.subscribe('UserRequestedStopRecording', @(src, event)obj.setMode('Preview'));
            obj.subscribe('LoggingComplete', @(src, event)obj.setMode('Preview'));
        end

        function handleAppCloseRequest(obj)
            obj.AppCloseRequested = true;
            obj.setRequestHardwareManagerToDestroyApp();
        end

        function setRequestHardwareManagerToDestroyApp(obj)
            obj.RequestHardwareManagerToDestroyApp = true;
        end

        function markAppDirty(obj)
            obj.DirtyState = true;
        end

        function setUserRequestedAppClose(obj)
            obj.UserRequestedAppClose = true;
        end
    end

    methods(Access = private)
        function handleNewSessionRequest(obj)
            % Clear the app dirty state flag since all modules will
            % be in new state now.
            obj.DirtyState = false;

            % Clear the app data, since there is no user
            % configuration now.
            obj.AppData = [];
        end

        function handlePinConfiguration(obj)
            % Callback function to save pin modes to restore later
            pinsInUse = obj.PinTableHandle.getPinsInUse();
            pinModes = cell(1,length(pinsInUse));
            for index = 1:length(pinsInUse)
                [mode,type] = obj.PinTableHandle.getPinMode(pinsInUse{index});
                if ~isempty(type)
                    pinModes{index} = sprintf("%s (%s)",mode,type);
                else
                    pinModes{index} = mode;
                end
            end
            pinNames = cellfun(@(x) obj.PinTableHandle.getCustomName(x),pinsInUse, 'UniformOutput',false);
            % Save data only if there are pins in use
            if(~isempty(pinsInUse))
                obj.AppData.SavedPinModeMap = containers.Map(pinsInUse,pinModes);
                obj.AppData.SavedCustomNameMap = containers.Map(pinsInUse, pinNames);
            else
                % Clear the app data, since there is no user
                % configuration now.
                obj.AppData = [];
            end
        end

        function setMode(obj, mode)
            obj.Mode = mode;
        end
    end

end
