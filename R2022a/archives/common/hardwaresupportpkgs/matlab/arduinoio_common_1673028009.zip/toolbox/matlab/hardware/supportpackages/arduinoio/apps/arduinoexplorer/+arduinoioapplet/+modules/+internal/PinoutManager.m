classdef PinoutManager < handle
    % PINOUTMANAGER - Class that handles showing Arduino device pinout
    % diagram in a modal pop-out dialog

    % Copyright 2021 The MathWorks, Inc.

    properties(Access=private)
        % Name of the Arduino board whose pinout is being displayed
        BoardName

        % Figure properties
        ParentFigure
        FigureTag
        ParentFigurePosition

        % Initial position of the uiimage
        DefaultImagePosition

        % Pinout canvas area
        PinoutImageHandle
        PinoutImage

        % Pinout figure dimensions
        ScreenSize
        DialogLeftPosition
        DialogBottomPosition

        % Context menu
        ContextMenu

        % Properties for image pan and zoom logic implementation
        Dragging = false
        OrigPos
    end

    %% Constant properties for the figure
    properties(Constant,Access=private)

        % Background color of the svg image
        BackgroundColor = "none"

        % Zoom increments/decrements in pixels
        ZoomFactor = 60
    end

    %% Public functions
    methods
        function obj = PinoutManager(boardName)
            % Initialize board name to show in the pinout title
            obj.BoardName = boardName;
            obj.FigureTag = sprintf("%s Pinout Dialog",obj.BoardName);
        end

        function delete(obj)
            % Close figure
            delete(obj.ParentFigure);
        end

        function launchPinoutDialog(obj)
            % Function to launch the pinout figure

            % Check if a pinout figure is already opened
            figHandle = findall(0,{'Type','Figure'},'-and',{'Tag',obj.FigureTag});
            if ~isempty(figHandle)
                figure(figHandle);
                return;
            end

            % Create figure if one doesn't exist already
            createDialog(obj);
            populateDialog(obj);
        end
    end

    %% Private internal function
    methods(Access=private)

        function createDialog(obj)

            import arduinoioapplet.internal.ArduinoAppConstants

            % Function to create the view pinout figure
            % Determine screen position for the dialog
            obj.ScreenSize = get(groot,'ScreenSize');

            % Determine figure window dimension relative to the screen size based
            % on the Arduino board's form factor
            formFactor = arduinoioapplet.internal.Utility.getBoardFormFactor(obj.BoardName);
            switch formFactor
                case "Large"
                    widthReduce = 150;
                    heightReduce = widthReduce;
                case "Medium"
                    widthReduce = 400;
                    heightReduce = widthReduce/2;
                case "Small"
                    widthReduce = 750;
                    heightReduce = widthReduce/5;
            end
            obj.DialogLeftPosition = obj.ScreenSize(3) - widthReduce;
            obj.DialogBottomPosition = obj.ScreenSize(4) - heightReduce;
            left = (obj.ScreenSize(3) - obj.DialogLeftPosition)/2;
            bottom = (obj.ScreenSize(4) - obj.DialogBottomPosition)/2;
            % Set figure window position
            obj.ParentFigurePosition = [left bottom obj.DialogLeftPosition obj.DialogBottomPosition];

            % Create figure
            obj.ParentFigure = uifigure("Position",obj.ParentFigurePosition);
            obj.ParentFigure.WindowStyle = "normal";
            name = getString(message("MATLAB:arduinoio:arduinoapp:viewPinoutTitle",string(obj.BoardName)));
            % Remove Arduino Prefix for 3rd party Arduino boards
            if ismember(obj.BoardName,ArduinoAppConstants.ThirdPartyBoards)
                name = strrep(name," Arduino","");
            end
            obj.ParentFigure.Name = name;
            obj.ParentFigure.Resize = "on";
            obj.ParentFigure.Tag = obj.FigureTag;

            % Initialize zoom and pan callback functions
            % Callbacks needed for panning logic
            obj.ParentFigure.WindowButtonDownFcn = @obj.startDrag;
            obj.ParentFigure.WindowButtonUpFcn = @obj.endDrag;
            obj.ParentFigure.WindowButtonMotionFcn = @obj.moveObject;
            % Callback needed for zoom logic
            obj.ParentFigure.WindowScrollWheelFcn = @obj.scrollObject;
        end

        function populateDialog(obj)
            % Function to populate the pinout image and title in the figure

            % Create image area
            obj.PinoutImageHandle = uiimage(obj.ParentFigure);
            boardName = obj.BoardName;
            if startsWith(boardName,"ProMini")
                boardName = "ProMini";
            end
            obj.PinoutImage = sprintf("Pinout_%s.svg",string(boardName));
            obj.PinoutImageHandle.ImageSource = fullfile(arduinoioapplet.internal.ArduinoAppConstants.PinoutImageFolder,obj.PinoutImage);
            obj.PinoutImageHandle.ScaleMethod = "fit";
            obj.PinoutImageHandle.BackgroundColor = obj.BackgroundColor;
            obj.PinoutImageHandle.HorizontalAlignment = "center";
            obj.PinoutImageHandle.Position = [10 10 obj.ParentFigurePosition(3:4)-10];
            obj.DefaultImagePosition = obj.PinoutImageHandle.Position;

            % Context menu
            obj.ContextMenu = uicontextmenu(obj.ParentFigure);
            uimenu(obj.ContextMenu,"Text",getString(message("MATLAB:arduinoio:arduinoapp:fitToWindow")),"MenuSelectedFcn",@obj.handleContextualMenuSelection);
            obj.PinoutImageHandle.ContextMenu = obj.ContextMenu;
        end
    end

    %% Pan and zoom callback functions
    methods(Access = private)
        function startDrag(obj,src,~)
            % Callback function to execute when user presses left mouse button
            % and if UIImage was clicked (CurrentObject)
            if strcmpi(obj.ParentFigure.SelectionType,"normal") &&...
                    src.CurrentObject == obj.PinoutImageHandle
                obj.Dragging = true;
                obj.OrigPos = obj.ParentFigure.CurrentPoint;
            end
        end

        function endDrag(obj,~,~)
            % Callback function to execute when user releases mouse button
            if obj.Dragging
                newPos = obj.ParentFigure.CurrentPoint;
                posDiff = newPos - obj.OrigPos;
                obj.PinoutImageHandle.Position = ...
                    obj.PinoutImageHandle.Position + [posDiff(1:2) 0 0];
                obj.Dragging = false;
            end
        end

        function moveObject(obj,~,~)
            % Callback function to execute when user is moving the mouse around
            if obj.Dragging
                newPos = obj.ParentFigure.CurrentPoint;
                posDiff = newPos - obj.OrigPos;
                obj.OrigPos = newPos;
                obj.PinoutImageHandle.Position = ...
                    obj.PinoutImageHandle.Position + [posDiff(1:2) 0 0];
            end
        end

        function scrollObject(obj,~,event)
            % Callback function to execute when user is scrolling the mouse wheel
            if event.VerticalScrollCount > 0
                % Zoom out
                obj.PinoutImageHandle.Position(3:4) =...
                    obj.PinoutImageHandle.Position(3:4)-obj.ZoomFactor;
                obj.PinoutImageHandle.Position(1:2) =...
                    obj.PinoutImageHandle.Position(1:2)+obj.ZoomFactor/2;
            elseif event.VerticalScrollCount < 0
                % Zoom in
                obj.PinoutImageHandle.Position(3:4) =...
                    obj.PinoutImageHandle.Position(3:4)+obj.ZoomFactor;
                obj.PinoutImageHandle.Position(1:2) =...
                    obj.PinoutImageHandle.Position(1:2)-obj.ZoomFactor/2;
            end
        end

        function handleContextualMenuSelection(obj,src,~)
            % Callback function to handle uiimage context menu selection
            if strcmpi(src.Text,getString(message("MATLAB:arduinoio:arduinoapp:fitToWindow")))
                obj.PinoutImageHandle.Position = obj.DefaultImagePosition;
            end
        end
    end
end

% LocalWords:  pinout
