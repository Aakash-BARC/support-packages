classdef WorkspaceManager < matlabshared.mediator.internal.Publisher...
        & matlabshared.mediator.internal.Subscriber
    % WORKSPACEMANAGER - Module that manages logging data to the workspace
    % for the Arduino Explorer App.

    % Copyright 2021 The MathWorks, Inc.

    properties(Access=private)
        % Details from the toolstrip recording section
        WorkspaceVarName
        Duration

        % Handle to the pin table
        PinTableHandle

        % Timer object for recording pin data
        RecordTimerObj

        % Set of Arduino pins to be recorded
        PinsToRecord
        PinsToRead
        PinsToWrite

        RecordedData

        % Current time stamp for logging data
        TimeStamp = 0
    end

    % Properties to be published
    properties (SetObservable)
        LoggingComplete
        LoggingPercentage
        DataLoggedToWorkspace
        LastRecordedVariableName
    end

    methods
        function obj = WorkspaceManager(mediator,pinTableHandle,initialWorkspaceVarName, initialDuration)

            obj@matlabshared.mediator.internal.Publisher(mediator);
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            % Store the references passed in
            obj.PinTableHandle = pinTableHandle;
            obj.WorkspaceVarName = initialWorkspaceVarName;
            obj.Duration = initialDuration;

            % Initialize the record data variable
            obj.RecordedData = table();

            % Timer object for recording data from Arduino pins
            obj.RecordTimerObj = internal.IntervalTimer(1);
            addlistener(obj.RecordTimerObj,'Executing',@(~,~)obj.recordData());
        end

        function subscribeToMediatorProperties(obj,~,~)
            % Events that the toolstrip should listen to
            obj.subscribe('CurrentDuration', @(src, event)obj.handleDurationEdit(event.AffectedObject.CurrentDuration));
            obj.subscribe('CurrentWorkspaceVarName', @(src, event)obj.handleWorkspaceVarEdit(event.AffectedObject.CurrentWorkspaceVarName));
            obj.subscribe('UserRequestedStartRecording', @(src, event)obj.handleStartRecording());
            obj.subscribe('UserRequestedStopRecording', @(src, event)obj.handleStopRecording());
            obj.subscribe('UserRequestedAppClose', @(src, event)obj.handleStopRecording());
        end
    end

    methods(Access=private)
        function handleWorkspaceVarEdit(obj,value)
            obj.WorkspaceVarName = value;
        end

        function handleDurationEdit(obj,value)
            obj.Duration = value;
        end

        function handleStartRecording(obj)
            % Function to handle start of data recording

            % Start the timer
            obj.RecordedData = table();
            obj.TimeStamp = 0;
            obj.PinsToRecord = getPinsToRecord(obj.PinTableHandle);
            obj.PinsToRead = getPinsToRead(obj.PinTableHandle);
            obj.PinsToWrite = getPinsToWrite(obj.PinTableHandle);
            obj.RecordTimerObj.start();
        end

        function handleStopRecording(obj)
            % Function to handle stop of data recording

            % Stop the timer
            obj.RecordTimerObj.stop();
            saveDataToWorkspace(obj);
            obj.setLastRecordedVariableName(obj.WorkspaceVarName);
            obj.setDataLoggedToWorkspace();
        end

        function recordData(obj)
            % Timer callback function to record data
            try
                % If timestamp has reached the duration specified
                % stop recording and save data to workspace
                if obj.TimeStamp >= obj.Duration
                    obj.TimeStamp = obj.Duration;
                    obj.RecordTimerObj.stop();
                    saveDataToWorkspace(obj);
                    obj.setLastRecordedVariableName(obj.WorkspaceVarName);
                    obj.setDataLoggedToWorkspace();
                    return;
                end

                instantData = cell(1,length(obj.PinsToRecord));
                % Get the read/write data for each pin
                for index = 1:length(obj.PinsToRecord)
                    pin = obj.PinsToRecord{index};
                    if ismember(pin, obj.PinsToRead)
                        data = getReadValue(obj.PinTableHandle,pin);
                    elseif ismember(pin, obj.PinsToWrite)
                        data = getWriteValue(obj.PinTableHandle,pin);
                    end
                    instantData{index} = str2double(data);
                end
                obj.RecordedData = [obj.RecordedData;instantData];
                obj.RecordedData.Properties.VariableNames = cellfun(@(x) sprintf('%s_%s',x,obj.PinTableHandle.getCustomName(x)),obj.PinsToRecord,...
                    'UniformOutput',false);

                % Update logging percentage
                obj.LoggingPercentage = floor((obj.TimeStamp/obj.Duration)*100);

                obj.TimeStamp = obj.TimeStamp + 1;
            catch e
                obj.RecordTimerObj.stop();
                throwAsCaller(e);
            end
        end

        function saveDataToWorkspace(obj)
            % Function to save recorded data to workspace
            timestamps = table(seconds(1:obj.TimeStamp)','VariableNames',{'Timestamp'});
            obj.RecordedData = [timestamps obj.RecordedData];
            obj.RecordedData = table2timetable(obj.RecordedData);
            assignin('base', obj.WorkspaceVarName, obj.RecordedData);
        end

        function setLastRecordedVariableName(obj, varName)
            obj.LastRecordedVariableName = varName;
        end

        function setDataLoggedToWorkspace(obj)
            obj.DataLoggedToWorkspace = true;
        end

    end
end
