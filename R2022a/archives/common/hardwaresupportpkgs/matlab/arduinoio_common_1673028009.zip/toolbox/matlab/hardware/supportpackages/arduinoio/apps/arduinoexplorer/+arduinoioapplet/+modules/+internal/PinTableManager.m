classdef PinTableManager < matlabshared.mediator.internal.Publisher...
        & matlabshared.mediator.internal.Subscriber...
        &arduinoioapplet.modules.internal.ErrorSource
    % PINTABLEMANAGER - class that handles all the data and controls related
    % to the Arduino pin configuration table in the Arduino Explorer app

    % Copyright 2021 The MathWorks, Inc.

    properties(Access=private)
        % Mediator handle
        Mediator

        % Parent Grid for the pin table area
        ParentGrid

        % Handle to the app container for displaying dialogs
        AppDialogParent

        % Handle to the Arduino Manager handle
        ArduinoManager

        % Widgets and panels in the pin configuration area
        PinTablePanel
        PinConfigLabelPanel
        PinConfigGrid
        ParentPinConfigGrid
        PinConfigLabelGrid
        PinFilterGrid
        TableGrid
        TableHandle
        TableTitle
        FilterLabel
        FilterButtonGroup
        PinFilterRadioButton1
        PinFilterRadioButton2
        PinFilterRadioButton3
        PinFilterRadioButton4

        % Handle to the pin config panel
        ConfigPanelHandle

        % Current Pin filter view
        PinViewFilter

        % Pin - <parameter> map of all pins
        PinModeMap
        PinReadValueMap
        PinWriteValueMap
        PinCustomNameMap
        PinRecordMap

        % List of Arduino pins set to one of the read modes
        PinsToRead
        % List of Arduino pins set to one of the write modes
        PinsToWrite
        % List of Arduino pins set to record
        PinsToRecord

        % List of all available Arduino Pins arranged chronologically
        AllArduinoPins

        % List of pins in neutral mode
        NeutralModePins

        % Timer object to read Arduino input pins
        ReadTimerObj

        % Edit-ability of pin table columns
        PinTableColumnEditable = [false,false,false,false,false,false]
    end

    properties(Access=private)
        PinTypeFilterListener
        TableEditListener
        PinsToReadListener
        PinSelectionListener
    end

    % Constant properties
    properties(Constant,Access=private)
        % Time interval to read pins
        ReadTimerPeriod = arduinoioapplet.internal.ArduinoAppConstants.PollingInterval

        % Pin table widget dimensions and layout
        ParentPinConfigGridRowHeight = {40,'1x'}
        ParentPinConfigGridColumnWidth = {'1x','0.25x'}
        PinGridPadding = [10 10 10 10]
        DefaultBackgroundColor = arduinoioapplet.internal.ArduinoAppConstants.DefaultBackgroundColor

        % Grid for Pin config table header label inside the parent grid
        PinConfigLabelGridRowHeight = {24}
        PinConfigLabelGridColumnWidth = {'1x','fit'}

        % Grid for pin filter inside the Pin config label grid
        PinFilterGridRowHeight = {14}
        PinFilterGridColumnWidth = {'fit','fit'}
        PinFilterGridPosition = {1,2}
        PinTableTitlePadding = [7 7 7 7]

        % Grid for Pin config table and pin configure panel
        PinConfigPanelGridRowHeight = {'1x','1x','1x'}
        PinConfigPanelGridColumnWidth = {'1x','1x'}

        % Position in the PinConfigLabel grid
        PinConfigLabelPosition = {1,1}
        PinConfigLabelPanelColor = "#D8D8D8"

        % Grid inside the Pin configLabel grid for the pin filter
        PinFilterLabelPosition = {1,1}
        PinFilterRadioButtonGroupPosition = {1,2}

        % Positions of:
        % Pin configuration table grid
        % Pin config uitable Table inside the table grid
        % Property panel grid inside parent grid
        TableGridPosition = {2,1};
        PinConfigTablePosition = {1,1}
        PinConfigGridPosition = {[1,2],2}

        % Column widths of the pin table
        PinTableColumnWidth = {100,'auto','auto','auto',100,'auto'}

        % Grid dimension to host the pin configuration panel and configure button
        PinConfigGridRowHeight = {'1x',40}
        PinConfigGridColumnWidth = {'1x'}
        PinConfigGridPadding = [0 0 0 0]
        PinConfigGridRowSpacing = 2

        % Write, Read Value, and Record column indices
        ReadValColNum = 3
        WriteValColNum = 4
        RecordValColNum = 5

        % Pin table header font properties
        HeadingFontSize = 16
        HeadingFontColor = "#535353"

        % Types of pin modes
        ReadPinModes = ["AnalogInput","DigitalInput","Servo"]
        WritePinModes = ["PWM","DigitalOutput","Servo","Tone"]
        NeutralPinModes = ["Interrupt","Pullup"]

        % Pin filter drop down options
        FilterDropDownItems = {getString(message("MATLAB:arduinoio:arduinoapp:filterAllPinsLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:pinTypeAnalogLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:pinTypeDigitalLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:filterConfiguredPinsLabel"))}
        PinFilterRadioButtonPositions = [[2 0 40 16];[52 0 100 16];[127 0 100 16];[192 0 100 16]]

        % Pin Table column names
        ColumnNames = {getString(message("MATLAB:arduinoio:arduinoapp:pinLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:modeLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:readValueLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:writeValueLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:recordLabel")),...
            getString(message("MATLAB:arduinoio:arduinoapp:customNameLabel"))}

        % Variable names for the table data
        TableVarNames = ["Pin","Mode","ReadValue","WriteValue","Record","CustomName"]

        % Cell style to grey out non-editable cells
        GreyCellStyle = uistyle("BackgroundColor","#F0F0F0")
        GreyFontStyle = uistyle("FontColor","#666666")
    end

    % Properties to trigger events
    properties(SetObservable,Hidden)
        CurrentPinSelection
        UserConfiguredPins
        IsPinsToRecordEmpty
        IsPinsToReadEmpty
        IsPinsToWriteEmpty
        PinReadStopped
    end

    % Properties introduced to avoid race condition issue in g2583070
    properties(Access=private)
        IsTimerCallbackExecuting = false
        IsCommandExecutionPending = false
        IsWritePending = false
        PinModesConfigPending = []
        PinCustomNameConfigPending = []
        WriteDataPending = []
    end

    methods
        % Constructor
        function obj = PinTableManager(mediator, dialogParent, parentGrid, position, arduinoManager)
            % Call the superclass constructors
            obj@matlabshared.mediator.internal.Publisher(mediator);
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            % Save references
            obj.ParentGrid = parentGrid;
            obj.Mediator = mediator;
            obj.AppDialogParent = dialogParent;
            obj.ArduinoManager = arduinoManager;

            % Create pin table area table and position it in the grid
            createPinTable(obj,position);

            % Initialize widget listeners
            addWidgetListeners(obj);

            % Create the pin configuration property panel
            createPinConfigPanel(obj);

            % Initialize and start timer to read input pins
            obj.ReadTimerObj = internal.IntervalTimer(obj.ReadTimerPeriod);
            addlistener(obj.ReadTimerObj,'Executing',@(~,~)obj.readPins);
        end

        % Destructor
        function delete(obj)

            if(~isempty(obj.ReadTimerObj) && isvalid(obj.ReadTimerObj))
                obj.ReadTimerObj.stop();
                obj.ReadTimerObj = [];
            end
        end

        function subscribeToMediatorProperties(obj,~,~)
            % Function to subscribe to mediator events
            obj.subscribe('UserConfirmedNewSession', @(src, event)obj.handleNewSessionRequest());
            obj.subscribe('UserRequestedStartRecording', @(src, event)obj.handleRecordingStartRequest());
            obj.subscribe('UserRequestedStopRecording', @(src, event)obj.handleRecordingStopRequest());
            obj.subscribe('DataLoggedToWorkspace', @(src, event)obj.handleRecordingStopRequest());
            % Restore saved data from previous session
            obj.subscribe('LoadedData', @(src, event)obj.handleSavedDataRestore(event.AffectedObject));
        end

        function updatePinTable(obj,pinModes,pinCustomNames)
            % Function to update the configuration received from the pin config property panel

            % Stop the timer before updating pin configuration to avoid
            % race condition when an existing timer callback is being processed
            % to read pin data (g2583070).
            % Process pin config request only if timer is not executing callback
            if obj.IsTimerCallbackExecuting == false
                try
                    % Stop timer first and then configure pin
                    obj.ReadTimerObj.stop();

                    updatePinModes(obj,pinModes);
                    updatePinCustomNames(obj,pinCustomNames);

                    % Update the pin table data
                    updatePinTableData(obj,keys(pinModes));

                    % Notify toolstrip manager that user configuration is done
                    setUserConfiguredPinsProp(obj);

                    % Notify listeners if there PinsToRead and PinsToWrite lists are empty
                    % Or a new pin has been added to a previously empty list
                    notifyPinsListener(obj);

                    % Make write and record columns editable
                    obj.PinTableColumnEditable(obj.WriteValColNum) = true;
                    obj.PinTableColumnEditable(obj.RecordValColNum) = true;
                    obj.TableHandle.ColumnEditable = obj.PinTableColumnEditable;

                    % Resume timer after pin config is done (g2583070)
                    obj.IsCommandExecutionPending = false;
                    obj.ReadTimerObj.start();
                catch e
                    obj.IsCommandExecutionPending = false;
                    errObj = MException(e.identifier, e.message);
                    obj.setErrorObjProperty(errObj);
                    throwAsCaller(e);
                end
            else
                % Store the pin config details for configuration later in the
                % timer callback (g2583070)
                obj.PinModesConfigPending = pinModeMap;
                obj.PinCustomNameConfigPending = pinCustomNames;
                obj.IsCommandExecutionPending = true;
            end
        end
    end

    methods(Hidden)
        function readPins = getPinsToRead(obj)
            % Function to return pins configured in one of the read modes
            readPins = obj.PinsToRead;
        end

        function readPins = getPinsToWrite(obj)
            % Function to return pins configured in one of the read modes
            readPins = obj.PinsToWrite;
        end

        function pins = getNeutralPins(obj)
            pins = obj.NeutralModePins;
        end

        function pins = getPinsInUse(obj)
            pins = unique([obj.PinsToRead, obj.PinsToWrite, obj.NeutralModePins]);
        end

        function recordPins = getPinsToRecord(obj)
            % Function to return the current list of pins to record
            recordPins = obj.PinsToRecord;
        end

        function name = getCustomName(obj,pin)
            % Function to return custom name of a particular pin
            name = obj.PinCustomNameMap(pin);
        end

        function [mode,type] = getPinMode(obj,pin)
            % Function to return the current mode of a pin
            [mode,type] = obj.extractMode(obj.PinModeMap(pin));
        end

        function readValue = getReadValue(obj,pin)
            % Get the latest value read from the pin
            readValue = obj.PinReadValueMap(pin);
        end

        function writeValue = getWriteValue(obj,pin)
            % Function to get the value being written to the current pin
            writeValue = obj.PinWriteValueMap(pin);
        end

        function pins = getCurrentPinSelection(obj)
            pins = obj.CurrentPinSelection;
        end

    end

    methods(Access=private)
        function createPinTable(obj,position)
            % Function to create the Arduino pin table and populate it with initial values

            % Create pin table panel
            obj.PinTablePanel = uipanel(obj.ParentGrid);
            obj.PinTablePanel.Layout.Row = position{1};
            obj.PinTablePanel.Layout.Column = position{2};
            obj.PinTablePanel.Tag = "Pin config area panel";

            % Create the parent grid for pin config area
            obj.ParentPinConfigGrid = uigridlayout(obj.PinTablePanel,...
                'RowHeight',obj.ParentPinConfigGridRowHeight,...
                'ColumnWidth', obj.ParentPinConfigGridColumnWidth,...
                'Padding', obj.PinGridPadding,...
                'BackgroundColor',obj.DefaultBackgroundColor);

            % Create the top panel for the pin config area
            obj.PinConfigLabelPanel = uipanel(obj.ParentPinConfigGrid);
            obj.PinConfigLabelPanel.Layout.Row = obj.PinConfigLabelPosition{1};
            obj.PinConfigLabelPanel.Layout.Column = obj.PinConfigLabelPosition{2};
            obj.PinConfigLabelPanel.BackgroundColor = obj.PinConfigLabelPanelColor;

            % Create pin config label grid within the panel.
            % This grid will host the table header and the pin view filter
            obj.PinConfigLabelGrid = uigridlayout(obj.PinConfigLabelPanel,...
                'RowHeight',obj.PinConfigLabelGridRowHeight,...
                'ColumnWidth',obj.PinConfigLabelGridColumnWidth,...
                'Padding',obj.PinTableTitlePadding);
            obj.PinConfigLabelGrid.BackgroundColor = obj.PinConfigLabelPanelColor;

            % Create pin filter grid inside pin config label grid
            obj.PinFilterGrid = uigridlayout(obj.PinConfigLabelGrid,...
                'RowHeight',obj.PinFilterGridRowHeight,...
                'ColumnWidth',obj.PinFilterGridColumnWidth,...
                'Padding',obj.PinTableTitlePadding);
            obj.PinFilterGrid.Layout.Row = obj.PinFilterGridPosition{1};
            obj.PinFilterGrid.Layout.Column = obj.PinFilterGridPosition{2};
            obj.PinFilterGrid.BackgroundColor = obj.PinConfigLabelPanelColor;

            % Create grid to host the pin configuration property panel
            obj.PinConfigGrid = uigridlayout(obj.ParentPinConfigGrid,...
                'BackgroundColor',obj.DefaultBackgroundColor);
            obj.PinConfigGrid.RowHeight = obj.PinConfigGridRowHeight;
            obj.PinConfigGrid.ColumnWidth = obj.PinConfigGridColumnWidth;
            obj.PinConfigGrid.Padding = obj.PinConfigGridPadding;
            obj.PinConfigGrid.RowSpacing = obj.PinConfigGridRowSpacing;
            obj.PinConfigGrid.Layout.Row = obj.PinConfigGridPosition{1};
            obj.PinConfigGrid.Layout.Column = obj.PinConfigGridPosition{2};

            % Create pin table inside the pin grid to workaround issue
            % mentioned in g2509162
            obj.TableGrid = uigridlayout(obj.ParentPinConfigGrid,...
                "RowHeight","1x","ColumnWidth","1x","Padding",[0 0 0 0]);
            obj.TableGrid.Layout.Row = obj.TableGridPosition{1};
            obj.TableGrid.Layout.Column = obj.TableGridPosition{2};

            obj.TableHandle = uitable(obj.TableGrid);
            obj.TableHandle.Layout.Row = obj.PinConfigTablePosition{1};
            obj.TableHandle.Layout.Column = obj.PinConfigTablePosition{2};
            obj.TableHandle.ColumnWidth = obj.PinTableColumnWidth;
            obj.TableHandle.ColumnEditable = obj.PinTableColumnEditable;
            obj.TableHandle.RowStriping = "off";
            obj.TableHandle.RowName = [];
            obj.TableHandle.SelectionType = "row";
            obj.TableHandle.ColumnName = obj.ColumnNames ;
            obj.TableHandle.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:pinTableDescription"));
            obj.TableHandle.Tag = "Pins Table";

            % Create table header
            obj.TableTitle = uilabel(obj.PinConfigLabelGrid);
            obj.TableTitle.Layout.Row = obj.PinConfigLabelPosition{1};
            obj.TableTitle.Layout.Column= obj.PinConfigLabelPosition{2};
            obj.TableTitle.Text = getString(message("MATLAB:arduinoio:arduinoapp:pinTableTitle"));
            obj.TableTitle.Tag = "Pin Table Header";
            obj.TableTitle.HorizontalAlignment = 'left';
            obj.TableTitle.FontColor = obj.HeadingFontColor;
            obj.TableTitle.FontWeight = 'bold';
            obj.TableTitle.FontSize = obj.HeadingFontSize;

            % Create pin filter radio button group and pin filter buttons
            obj.FilterLabel = uilabel(obj.PinFilterGrid);
            obj.FilterLabel.Layout.Row = obj.PinFilterLabelPosition{1};
            obj.FilterLabel.Layout.Column = obj.PinFilterLabelPosition{2};
            obj.FilterLabel.HorizontalAlignment = "right";
            obj.FilterLabel.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:filterPinsDescription"));
            obj.FilterLabel.Text = getString(message("MATLAB:arduinoio:arduinoapp:filterPinsLabel"));

            obj.FilterButtonGroup = uibuttongroup(obj.PinFilterGrid);
            obj.FilterButtonGroup.Layout.Row = obj.PinFilterRadioButtonGroupPosition{1};
            obj.FilterButtonGroup.Layout.Column = obj.PinFilterRadioButtonGroupPosition{2};
            obj.FilterButtonGroup.BackgroundColor = obj.PinConfigLabelPanelColor;
            obj.FilterButtonGroup.BorderType = "none";
            obj.FilterButtonGroup.Tag = "Show Pins Filter";
            obj.PinFilterRadioButton1 = uiradiobutton(obj.FilterButtonGroup,"Text",obj.FilterDropDownItems{1},"WordWrap","on");
            obj.PinFilterRadioButton1.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:filterAllPinsDescription"));
            obj.PinFilterRadioButton1.Position = obj.PinFilterRadioButtonPositions(1,:);

            obj.PinFilterRadioButton2 = uiradiobutton(obj.FilterButtonGroup,"Text",obj.FilterDropDownItems{2},"WordWrap","on");
            obj.PinFilterRadioButton2.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:pinTypeAnalogDescription"));
            obj.PinFilterRadioButton2.Position = obj.PinFilterRadioButtonPositions(2,:);

            obj.PinFilterRadioButton3 = uiradiobutton(obj.FilterButtonGroup,"Text",obj.FilterDropDownItems{3},"WordWrap","on");
            obj.PinFilterRadioButton3.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:pinTypeDigitalDescription"));
            obj.PinFilterRadioButton3.Position = obj.PinFilterRadioButtonPositions(3,:);

            obj.PinFilterRadioButton4 = uiradiobutton(obj.FilterButtonGroup,"Text",obj.FilterDropDownItems{4},"WordWrap","on");
            obj.PinFilterRadioButton4.Tooltip = getString(message("MATLAB:arduinoio:arduinoapp:filterConfiguredPinsDescription"));
            obj.PinFilterRadioButton4.Position = obj.PinFilterRadioButtonPositions(4,:);

            % Initialize the pin table
            initPinTable(obj);

            % Apply cell styles
            updateCellStyle(obj);
        end

        function createPinConfigPanel(obj)
            % Function to create the pin configuration panel
            obj.ConfigPanelHandle = arduinoioapplet.modules.internal.ConfigurePinPanelManager(obj,obj.Mediator,obj.AppDialogParent,obj.ArduinoManager,obj.PinConfigGrid);
        end

        function handleNewSessionRequest(obj)
            % Callback function to handle new session request
            try
                % Clear the pin table selection
                obj.TableHandle.Selection = [];
                allPins = unique([obj.PinsToRead, obj.PinsToWrite, obj.NeutralModePins]);
                resetPins(obj,allPins);
                initPinTable(obj);
                removeStyle(obj.TableHandle);
                updateCellStyle(obj);
            catch e
                errObj = MException(e.identifier, e.message);
                obj.setErrorObjProperty(errObj);
            end
        end

        function handlePinFilterSelectionChanged(obj,eventData)
            % Callback function to handle the change in Pin filter drop-down

            obj.PinViewFilter = string(eventData.NewValue.Text);
            switch (obj.PinViewFilter)
                case message('MATLAB:arduinoio:arduinoapp:filterAllPinsLabel').getString
                    pinList = obj.AllArduinoPins;
                case message('MATLAB:arduinoio:arduinoapp:pinTypeAnalogLabel').getString
                    pinList = obj.ArduinoManager.AnalogPins;
                case message('MATLAB:arduinoio:arduinoapp:pinTypeDigitalLabel').getString
                    pinList = obj.ArduinoManager.DigitalPins;
                case message('MATLAB:arduinoio:arduinoapp:filterConfiguredPinsLabel').getString
                    pinList = unique([obj.PinsToRead obj.PinsToWrite obj.NeutralModePins]);
                otherwise
                    pinList = obj.AllArduinoPins;
            end
            filterPinTableData(obj,pinList);
        end

        function handlePinTableEdited(obj,eventData)
            % Function to handle edits made in the pin table

            try
                % Get the indices of the cell being edited
                indices = eventData.Indices;
                rowIndex = indices(1);
                colIndex = indices(2);
                % Check if write value was edited in the table
                if colIndex == obj.WriteValColNum
                    % If the pin is in read/Unset/neutral mode, overwrite the value being entered
                    if ismember(obj.TableHandle.Data.Mode(rowIndex),[obj.NeutralPinModes,"Unset"]) ||...
                            ismember(obj.TableHandle.Data.Mode(rowIndex),obj.ReadPinModes) &&...
                            ~strcmpi(obj.TableHandle.Data.Mode(rowIndex),"Servo")
                        obj.TableHandle.Data.WriteValue(rowIndex) = "";
                    else
                        updateWriteValue(obj,eventData)
                    end
                    % Check if the recording state was changed
                elseif colIndex == obj.RecordValColNum
                    % Revert values back to false if the pin is in neutral mode, Unset, or
                    % pin hasn't been used to write values yet when in write mode
                    if ismember(obj.TableHandle.Data.Mode(rowIndex),[obj.NeutralPinModes,"Unset"]) ||...
                            (ismember(obj.TableHandle.Data.Pin(rowIndex),obj.WritePinModes) && ...
                            ~strcmpi(obj.TableHandle.Data.Mode(rowIndex),"servo"))
                        obj.TableHandle.Data.Record(rowIndex) = false;
                    else
                        updatePinsToRecord(obj,eventData);
                    end
                end
            catch e
                errObj = MException(e.identifier, e.message);
                obj.setErrorObjProperty(errObj);
            end
        end

        function handlePinTableSelection(obj,eventData)
            % Function to set the current active pin selection
            % to contextually populate the config pin property panel
            selectedPins = obj.TableHandle.Data.Pin(unique(eventData.Indices(:,1)));
            if ~isempty(selectedPins)
                obj.setCurrentPinSelection(selectedPins);
            end
        end

        function handlePinsToReadUpdate(obj,eventObj)
            % Callback function to handle PinsToRead empty or
            % first pin being added to PinsToRead list

            if eventObj.IsPinsToReadEmpty
                obj.ReadTimerObj.stop();
            else
                obj.ReadTimerObj.start();
            end
        end

        function handleRecordingStartRequest(obj)
            % Function to disable widgets when recording has started
            obj.TableHandle.ColumnEditable(obj.RecordValColNum) = false;
            addStyle(obj.TableHandle,obj.GreyCellStyle,'Column',obj.RecordValColNum);
            updateFilterButtonState(obj,'off');
        end

        function handleRecordingStopRequest(obj)
            % Function to enable widgets when recording has stopped
            obj.TableHandle.ColumnEditable(obj.RecordValColNum) = true;
            removeStyle(obj.TableHandle);
            updateFilterButtonState(obj,'on');
            % Bring back the read & write pins cell styles
            updateCellStyle(obj);
        end

        function handleSavedDataRestore(obj,eventObj)
            % Callback function to restore the saved pin mode settings
            modeData = eventObj.LoadedData.SavedPinModeMap;
            customNameData = eventObj.LoadedData.SavedCustomNameMap;
            obj.updatePinTable(modeData,customNameData)
        end

        function initPinTable(obj)
            % Function to initialize the pin table

            % Get pin details for the board from Arduino manager
            obj.AllArduinoPins = string(obj.ArduinoManager.AllPins);
            pinCount = length(obj.AllArduinoPins);
            modes = repmat("Unset",1,pinCount);
            readValues = repmat("",1,pinCount);
            writeValues = repmat("",1,pinCount);
            customNames = repmat("",1,pinCount);
            recordStates = false(1,pinCount);

            % Initialize pin resource maps
            obj.PinModeMap = containers.Map(obj.AllArduinoPins,modes);
            obj.PinReadValueMap = containers.Map(obj.AllArduinoPins,readValues);
            obj.PinWriteValueMap = containers.Map(obj.AllArduinoPins,writeValues);
            obj.PinCustomNameMap = containers.Map(obj.AllArduinoPins,customNames);
            obj.PinRecordMap = containers.Map(obj.AllArduinoPins,recordStates);

            % Initialize pins lists
            obj.PinsToRead = {};
            obj.PinsToWrite = {};
            obj.PinsToRecord = {};
            obj.NeutralModePins = {};

            % Create data to be displayed in the table
            tableData = table(obj.AllArduinoPins',modes',readValues',writeValues',recordStates',customNames');
            tableData.Properties.VariableNames = obj.TableVarNames;

            % Populate the table with initial pin data
            obj.TableHandle.Data = tableData;

            % Initialize Pin view filter
            obj.PinFilterRadioButton1.Value= 1;
        end

        function updatePinModes(obj,pinModeMap)
            % Update the pin modes in the map

            try
                % Pin numbers
                pins = keys(pinModeMap);
                % Mode(ModeType) values
                modeTypePairs = values(pinModeMap);

                % For each of the pins in the configure list:
                % 1. Configure the Arduino pin to the corresponding mode
                % 2. Update the Pin-Mode map
                % 3. Update the PinsToRead, PinsToWrite, PinReadValue and PinWriteValue maps
                for index = 1:length(pins)
                    mode = obj.extractMode(modeTypePairs{index});
                    % Configure actual Arduino board pin modes
                    configurePin(obj.ArduinoManager,pins{index},mode);
                    % Update Pin-Mode Map
                    obj.PinModeMap(pins{index}) = modeTypePairs{index};
                    % Update read/write pin list and maps
                    updateReadWritePinList(obj,pins{index},mode);
                end
            catch e
                throwAsCaller(e);
            end
        end

        function updatePinCustomNames(obj,pinCustomNames)
            % Update pin custom Names in the map and remove custom name
            % if the corresponding mode is set to "Unset"

            try
                customNameKeys = keys(pinCustomNames);
                customNameValues = values(pinCustomNames);
                % Update Pin-custom name map based on the current mode of the pins
                for index = 1:length(customNameKeys)
                    if ~strcmpi(obj.PinModeMap(customNameKeys{index}),"Unset")
                        obj.PinCustomNameMap(customNameKeys{index}) = customNameValues{index};
                    else
                        obj.PinCustomNameMap(customNameKeys{index}) = "";
                    end
                end
            catch e
                throwAsCaller(e);
            end
        end

        function updateReadWritePinList(obj,pin,mode)
            % Function to add/remove pins from read/write list
            % This function also updates both Pin-ReadValue
            % and the Pin-WriteValue maps

            % Add to read list and remove the pin from the
            % write list and neutral list for all modes except for servo
            if ismember(mode,obj.ReadPinModes)
                obj.PinsToRead{end+1} = pin;
                if ~strcmpi(mode,"Servo")
                    obj.PinsToWrite = setdiff(obj.PinsToWrite,pin);
                    obj.NeutralModePins = setdiff(obj.NeutralModePins,pin);
                end
            end
            % Add to write list and remove the pin from the
            % read list and neutral list for all modes except for servo
            if ismember(mode,obj.WritePinModes)
                obj.PinsToWrite{end+1} = pin;
                if ~strcmpi(mode,"Servo")
                    obj.PinsToRead = setdiff(obj.PinsToRead,pin);
                    obj.NeutralModePins = setdiff(obj.NeutralModePins,pin);
                end
            end

            % Remove pin from read,write,neutral, and record lists if pin
            % is set to neither read or write modes. Update Pin maps accordingly.
            if ismember(mode,obj.NeutralPinModes)
                obj.NeutralModePins{end+1} = pin;
                obj.PinsToWrite = setdiff(obj.PinsToWrite,pin);
                obj.PinsToRead = setdiff(obj.PinsToRead,pin);
                obj.PinsToRecord = setdiff(obj.PinsToRecord,pin);
                obj.PinRecordMap(pin) = false;
            end

            % Remove pin from read,write,neutral and record list if pin is
            % Unset mode. Update pin maps accordingly.
            if ismember(mode,"Unset")
                obj.PinsToWrite = setdiff(obj.PinsToWrite,pin);
                obj.PinsToRead = setdiff(obj.PinsToRead,pin);
                obj.NeutralModePins = setdiff(obj.NeutralModePins,pin);
                obj.PinsToRecord = setdiff(obj.PinsToRecord,pin);
                obj.PinRecordMap(pin) = false;
            end

            % Reset the read and write values for the pin
            obj.PinReadValueMap(pin) = "";
            obj.PinWriteValueMap(pin) = "";

            % Eliminate duplicate entries
            obj.PinsToRead = unique(obj.PinsToRead);
            obj.PinsToWrite = unique(obj.PinsToWrite);
        end

        function updatePinTableData(obj,pinList)
            % Update table data corresponding to pins that were configured/updated
            for index = 1:length(pinList)
                pin = pinList{index};
                % Find row-index of the pin
                rowIndex = getPinIndexFromTable(obj,pin);
                obj.TableHandle.Data.Mode(rowIndex) = string(obj.PinModeMap(pin));
                obj.TableHandle.Data.ReadValue(rowIndex) = string(obj.PinReadValueMap(pin));
                obj.TableHandle.Data.WriteValue(rowIndex) = string(obj.PinWriteValueMap(pin));
                obj.TableHandle.Data.Record(rowIndex) = obj.PinRecordMap(pin);
                obj.TableHandle.Data.CustomName(rowIndex) = obj.PinCustomNameMap(pin);
            end
            removeStyle(obj.TableHandle);
            updateCellStyle(obj);
        end

        function filterPinTableData(obj,pinList)
            % Function to update the complete pin table data to change
            % the table's view

            % pinList might be empty when the there are no pins configured
            % and the view is to show all pins in use.
            if isempty(pinList)
                obj.TableHandle.Data = table();
            else
                pinList = string(pinList);
                modes = arrayfun(@(x) string(obj.PinModeMap(x)),pinList);
                readValues = arrayfun(@(x) string(obj.PinReadValueMap(x)),pinList);
                writeValues = arrayfun(@(x) string(obj.PinWriteValueMap(x)),pinList);
                customNames = arrayfun(@(x) string(obj.PinCustomNameMap(x)),pinList);
                recordStates = arrayfun(@(x) obj.PinRecordMap(x),pinList);

                % Update the pin table data
                obj.TableHandle.Data = table(pinList',modes',readValues',writeValues',...
                    recordStates',customNames');
                obj.TableHandle.Data.Properties.VariableNames = obj.TableVarNames;
                removeStyle(obj.TableHandle);
                updateCellStyle(obj);
            end
        end

        function updateWriteValue(obj,eventData)
            % Function to update the write data for the specified Arduino pin
            oldValueString = eventData.PreviousData;
            newValueString = eventData.NewData;

            rowIndex = eventData.Indices(1);

            % Get the pin number being edited
            pin = char(obj.TableHandle.Data.Pin(rowIndex));
            % Get pin mode
            [mode,type] = extractMode(obj,obj.PinModeMap(pin));

            % Use str2num to evaluate text as numeric
            newValue = str2num(newValueString);

            % Validate and update the user specified write data
            if ~isempty(newValue) && isscalar(newValue) && ~isnan(newValue)...
                    && isreal(newValue) && ~isinf(newValue) && newValue >= 0
                % Write new value to Arduino pin

                % Stop the timer before updating pin configuration to avoid
                % race condition when an existing timer callback is being processed
                % to read pin data (g2583070).
                % Process pin config request only if timer is not executing callback
                if obj.IsTimerCallbackExecuting == false
                    try
                        obj.ReadTimerObj.stop();
                        writePin(obj.ArduinoManager,pin,mode,type,newValue);
                        % Resume timer after pin config is done (g2583070).
                        obj.ReadTimerObj.start();
                        obj.IsWritePending = false;
                        updateWriteDataInTable(obj,rowIndex,pin,newValueString);
                    catch e
                        % Restore previous data in the pin table
                        obj.IsWritePending = false;
                        updateWriteDataInTable(obj,rowIndex,pin,oldValueString);
                        throwAsCaller(e);
                    end
                else
                    % Store the pin write details for write later in the
                    % timer callback (g2583070)
                    obj.WriteDataPending = eventData;
                    obj.IsWritePending = true;
                end
            else
                % Update the pin table
                updateWriteDataInTable(obj,rowIndex,pin,oldValueString);
                errorID = 'MATLAB:arduinoio:arduinoapp:dataNotNumeric';

                % Create an exception object for the duration not being a
                % number and set the 'ErrorObj' property
                errObj = MException(errorID, getString(message(errorID)));
                obj.setErrorObjProperty(errObj);
            end
        end

        function updateWriteDataInTable(obj,rowIndex,pin,value)
            % Function to update the write value map and the write value in pin table

            if isempty(value)
                obj.TableHandle.Data.WriteValue(rowIndex) = "";
                return;
            end

            % Form write value string
            mode = obj.PinModeMap(pin);
            [mode,~] = extractMode(obj,mode);

            % Convert digital write values to numeric
            if startsWith(mode,"Digital")
                value = str2num(value);
            end

            obj.PinWriteValueMap(pin) = num2str(value);
            obj.TableHandle.Data.WriteValue(rowIndex) = num2str(value);
        end

        function updatePinsToRecord(obj,eventData)
            % Function to update the record state in PinRecord map and
            % the list of pins to record

            rowIndex = eventData.Indices(1);
            % Get the pin number being edited
            pin = char(obj.TableHandle.Data.Pin(rowIndex));
            obj.PinRecordMap(pin) = eventData.NewData;
            % Add pin to list if selected. Remove if unselected.
            if(eventData.NewData)
                obj.PinsToRecord{end+1} = pin;
            else
                obj.PinsToRecord = setdiff(obj.PinsToRecord,pin);
            end
            % Notify listeners if there are no pins to record or a pin has been added
            % to the previously empty PinsToRecord list
            notifyRecordListener(obj);
        end

        function updateCellStyle(obj)
            % Function to app grey style to cells

            % Find row indices of read and write pins
            readPinRowIndices = find(ismember(obj.TableHandle.Data.Pin,obj.PinsToRead));
            writePinRowIndices = find(ismember(obj.TableHandle.Data.Pin,obj.PinsToWrite));
            neutralPinRowIndices = find(ismember(obj.TableHandle.Data.Pin,obj.NeutralModePins));
            usedPinIndices = unique([readPinRowIndices;writePinRowIndices;neutralPinRowIndices]);
            unsetPinIndices = setdiff(1:length(obj.AllArduinoPins),usedPinIndices);
            commonIndices = intersect(readPinRowIndices,writePinRowIndices);

            % Remove common pin indices from both list
            readPinRowIndices = setdiff(readPinRowIndices,commonIndices);
            writePinRowIndices = setdiff(writePinRowIndices,commonIndices);

            % Apply style for unset pins
            if ~isempty(unsetPinIndices)
                rowIndices = unsetPinIndices;
                addStyle(obj.TableHandle,obj.GreyCellStyle,'row',rowIndices);
                addStyle(obj.TableHandle,obj.GreyFontStyle,'row',rowIndices);
            end

            % Grey write value column for read pins
            if ~isempty(readPinRowIndices)
                rowIndices = readPinRowIndices;
                colIndices = repmat([obj.WriteValColNum],[length(rowIndices),1]);
                addStyle(obj.TableHandle,obj.GreyCellStyle,'cell',[rowIndices,colIndices]);
            end

            % Grey read value column for write pins
            if ~isempty(writePinRowIndices)
                rowIndices = writePinRowIndices;
                colIndices = repmat([obj.ReadValColNum],[length(rowIndices),1]);
                addStyle(obj.TableHandle,obj.GreyCellStyle,'cell',[rowIndices,colIndices]);
            end

            % Grey both read and write cells for pins in neutral mode
            if ~isempty(neutralPinRowIndices)
                rowIndices = neutralPinRowIndices;
                colIndices1 = repmat([obj.ReadValColNum],[length(rowIndices),1]);
                colIndices2 = repmat([obj.WriteValColNum],[length(rowIndices),1]);
                addStyle(obj.TableHandle,obj.GreyCellStyle,'cell',[rowIndices,colIndices1]);
                addStyle(obj.TableHandle,obj.GreyCellStyle,'cell',[rowIndices,colIndices2]);
            end

        end

        function updateFilterButtonState(obj,state)
            % Function to change the enable state of the pin type filter
            % radio buttons
            obj.PinFilterRadioButton1.Enable = state;
            obj.PinFilterRadioButton2.Enable = state;
            obj.PinFilterRadioButton3.Enable = state;
            obj.PinFilterRadioButton4.Enable = state;
        end

        function notifyRecordListener(obj)
            % Function to notify listeners if there are no pins to record
            % or a pin has been added to the previously empty PinsToRecord list

            if isempty(obj.PinsToRecord)
                obj.IsPinsToRecordEmpty = true;
            elseif length(obj.PinsToRecord) == 1
                obj.IsPinsToRecordEmpty = false;
            end
        end

        function notifyPinsListener(obj)
            % Function to notify listeners if there are no pins to record
            % or a pin has been added to the previously empty PinsToRecord list

            if isempty(obj.PinsToRead)
                obj.IsPinsToReadEmpty = true;
            else
                obj.IsPinsToReadEmpty = false;
            end

            if isempty(obj.PinsToWrite)
                obj.IsPinsToWriteEmpty = true;
            else
                obj.IsPinsToWriteEmpty = false;
            end
        end

        function readPins(obj)
            % Timer callback function to read Arduino pins configured for input

            % Exit if there are not pins set to input mode
            if isempty(obj.PinsToRead)
                return;
            end
            % Set timer callback execution flag to true (g2583070)
            obj.IsTimerCallbackExecuting = true;
            try
                for index = 1:length(obj.PinsToRead)
                    pin = obj.PinsToRead{index};
                    mode = extractMode(obj,obj.PinModeMap(pin));
                    readValue = string(readPin(obj.ArduinoManager,pin,mode));
                    % Store the latest value in map
                    obj.PinReadValueMap(pin) = readValue;
                    if strcmpi(mode,"AnalogInput")
                        readValue = sprintf("%s V",readValue);
                    end
                    % Update the pin table data
                    pinIndex = getPinIndexFromTable(obj,pin);
                    if ~isempty(pinIndex)
                        obj.TableHandle.Data.ReadValue(pinIndex) = readValue;
                    end
                end
            catch e
                % Stop timer if error occurs
                obj.ReadTimerObj.stop();
                obj.PinReadStopped = true;
                errObj = MException(e.identifier, e.message);
                obj.setErrorObjProperty(errObj);
                obj.IsTimerCallbackExecuting = false;
                throwAsCaller(e);
            end

            % Set timer callback execution state to false and process any
            % pending pin config/write request (fix for g2583070)
            obj.IsTimerCallbackExecuting = false;
            if obj.IsCommandExecutionPending == true
                updatePinTable(obj,obj.PinModesConfigPending,obj.PinCustomNameConfigPending);
            end
            if obj.IsWritePending == true
                updateWriteValue(obj,obj.WriteDataPending);
            end
        end

        function [mode,type] = extractMode(~,modeType)
            % Extract the pin mode from mode(modeType) input
            type = [];
            mode = strsplit(modeType,"(");
            if length(mode)>1
                type = strrep(strtrim(mode{2}),')','');
            end
            mode = strtrim(mode{1});
        end

        function index = getPinIndexFromTable(obj,pin)
            % Function to the get the row index of the specified
            % pin in the pin table
            data = obj.TableHandle.Data;
            index = find(ismember(data.Pin,pin));
        end

        function setUserConfiguredPinsProp(obj)
            % Set observable property to trigger postSet event
            obj.UserConfiguredPins = true;
        end

        function setCurrentPinSelection(obj,pins)
            obj.CurrentPinSelection = pins;
        end

        function addWidgetListeners(obj)
            % Function to add listeners for pin table and related widgets
            % in the Pin table area
            obj.PinTypeFilterListener = obj.FilterButtonGroup.listener('SelectionChanged',@(src,event)obj.handlePinFilterSelectionChanged(event));
            obj.TableEditListener = obj.TableHandle.listener('CellEdit',@(src,event)obj.handlePinTableEdited(event));
            obj.PinSelectionListener = obj.TableHandle.listener('CellSelection',@(src,event)obj.handlePinTableSelection(event));
            obj.PinsToReadListener = obj.listener('IsPinsToReadEmpty','PostSet',@(src,event)obj.handlePinsToReadUpdate(event.AffectedObject));
        end

        function resetPins(obj,pins)
            % Function to reset all pins to Unset

            % Stop the timer before updating pin configuration to avoid
            % race condition when an existing timer callback is being processed
            % to read pin data (g2583070).
            % Process pin config request only if timer is not executing callback
            if obj.IsTimerCallbackExecuting == false
                try
                    % Stop timer first and then configure pin
                    obj.ReadTimerObj.stop();

                    % Reset all pins to Unset using the existing "updatePinModes"
                    % function
                    modes = repmat("Unset",1,length(pins));
                    resetpinModeMap = containers.Map(pins,modes);
                    updatePinModes(obj,resetpinModeMap);

                    % Resume timer after pin config is done (g2583070)
                    obj.IsCommandExecutionPending = false;
                    obj.ReadTimerObj.start();
                catch e
                    obj.IsCommandExecutionPending = true;
                    throwAsCaller(e);
                end
            else
                % Store the pin config details for configuration later in the
                % timer callback (g2583070)
                obj.PinModesConfigPending = containers.Map(pins,...
                    repmat("Unset",1,length(pins)));
                obj.PinCustomNameConfigPending = repmat("",1,length(pins));
                obj.IsCommandExecutionPending = true;
            end
        end
    end
end

% LocalWords:  arduinoapp
