classdef ArduinoAppConstants < handle
    % ARDUINOAPPCONSTANTS - Internal class that stores constant values
    % used throughout the Arduino Explorer app

    % Copyright 2021 The MathWorks, Inc

    properties(Constant,GetAccess=public)
        % Types of supported boards based on form factors and vendors
        LargeBoards = {'Due','Mega2560','MegaADK','DigitalSandbox'}
        MediumBoards = {'Uno','Leonardo'}
        SmallBoards = {'Micro','MKR1000','MKR1010','MKRZero','Nano3','Nano33BLE','Nano33IoT','ProMini328_3V','ProMini328_5V'}
        ThirdPartyBoards = {'DigitalSandbox'}

        % Device card icon path and icon file names
        % Device icons in the app device cards are present in the HWMgr device data icon repo.
        % and requires a path relative to matlabroot.
        DeviceIconFolder = "toolbox/shared/hwmanager/hwmanagerapp/devicedata/icons"
        PinoutImageFolder = fullfile(arduinoio.SPPKGRoot,"apps","arduinoexplorer","resources")
        LargeFFIcon = "Arduino_LargeBoard.png"
        MediumFFIcon = "Arduino_MediumBoard.png"
        SmallFFIcon = "Arduino_SmallBoard.png"

        IconFolder = fullfile(arduinoio.SPPKGRoot,"apps","arduinoexplorer","icons")
        HardwareSetupIcon = "HardwareSetup_24px.png"
        AddBluetoothIcon = "Connection_Bluetooth_24px.png"
        AddUSBIcon = "Connection_USB_24px.png"
        AddWiFiIcon = "Connection_Wifi_24px.png"

        % MATLAB preference name for saved Arduino device info
        PrefGroupName = "MATLAB_HARDWARE"
        % Preference name for Arduino Bluetooth device addresses
        BluetoothPrefName = "ARDUINOIO_BT_PREFS"
        % Preference name for Arduino BLE device addresses
        BLEPrefName = "ARDUINOIO_BLE_PREFS"
        % Preference name for Arduino WiFi device addresses
        WiFiPrefName = "ARDUINOIO_WIFI_PREFS"

        % Default Arduino WiFi Port
        DefaultWiFiPort = arduinoio.internal.ArduinoConstants.DefaultTCPIPPort
        % Interval to read data from Arduino Pins
        PollingInterval  = 1
        % Default Tone input parameters
        DefaultToneFrequency = 1000 % Hz
        DefaultToneDuration = 1 % seconds

        % Default background colors
        DefaultBackgroundColor = "#FFFFFF"

    end
end

% LocalWords:  ADK Uno MKR Nano Bluetooth WiFi BLE
