function uninstall3PLibraries()
%UNINSTALL3PLIBRARIES uninstall the MWArduino library and motor shield 
%library

% Copyright 2014-2019 The MathWorks, Inc.

IDERootDir = arduinoio.IDERoot;
if ismac
    rmdir(fullfile(IDERootDir, 'libraries', 'Adafruit_MotorShield'), 's');
end

end