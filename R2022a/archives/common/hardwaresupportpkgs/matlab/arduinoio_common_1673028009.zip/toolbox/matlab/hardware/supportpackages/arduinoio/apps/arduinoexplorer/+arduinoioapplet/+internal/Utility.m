classdef Utility < handle
    % UTILITY - Utility class for the Arduino Explorer app

    % Copyright 2021 The MathWorks, Inc.

    methods(Static)
        function friendlyName = getFriendlyName(varargin)
            % Function to get the friendly name of an Arduino board for use
            % in the Arduino Explorer app

            import arduinoioapplet.internal.ArduinoAppConstants

            boardName = "";
            if(nargin>=1)
                boardName = varargin{1};
            end

            % Get the system's user name
            if isunix
                command = "whoami";
            else
                command = "echo %USERNAME%";
            end
            [status,userName] = system(command);
            if ~status
                userName = strtrim(userName);
            end

            % Create the friendly name using the user name and selected board
            if ~isempty(userName) && ~strcmpi(userName,"%USERNAME%")
                friendlyName = sprintf("%s's Arduino %s",userName,boardName);
            else
                friendlyName = sprintf("My Arduino %s",boardName);
            end
            % Trim any trailing whitespaces
            friendlyName = strtrim(friendlyName);

            % Remove Arduino Prefix for 3rd party Arduino boards
            if ismember(boardName,ArduinoAppConstants.ThirdPartyBoards)
                friendlyName = strrep(friendlyName," Arduino","");
            end
        end
        function formFactorType = getBoardFormFactor(name)
            % Utility function to get the size of the board to select the
            % device card icon

            if find(any(contains(arduinoioapplet.internal.ArduinoAppConstants.LargeBoards,name)))
                formFactorType = arduinoioapplet.internal.FormFactorTypesEnum.Large;
            elseif find(any(contains(arduinoioapplet.internal.ArduinoAppConstants.MediumBoards,name)))
                formFactorType = arduinoioapplet.internal.FormFactorTypesEnum.Medium;
            elseif find(any(contains(arduinoioapplet.internal.ArduinoAppConstants.SmallBoards,name)))
                formFactorType = arduinoioapplet.internal.FormFactorTypesEnum.Small;
            else
                formFactorType = arduinoioapplet.internal.FormFactorTypesEnum.Medium;
            end
        end

        function output = removeWhitespace(input)
            % Function to remove all white space from the string
            input = char(input);
            assert(ischar(input), getString(message('MATLAB:arduinoio:arduinoapp:inputNotChar')));
            output = input(~isspace(input));
        end

        function output = removeHyperlinks(input)
            % Utility function to remove hyperlinks from error message
            output = regexprep(input,'</?a(|\s+[^>]+)>','');
        end

        function status = isVariablePresentInBaseWorkspace(varName)
            % Check if the specified variable name already exists in the MATLAB workspace
            status = ismember(varName, evalin('base','who'));
        end

        function ports = getUSBSerialPorts()
            usbdev = matlab.hwmgr.internal.hwconnection.USBDeviceEnumerator;
            ports = getSerialPorts(usbdev);
            % USBDeviceEnumerator does not detect Arduino boards with empty
            % VID_PID (g2168913). Using serialportlist to get generic USB devices which
            % may be one of the clone Arduino boards.
            if ismac
                serialPorts = cellstr(serialportlist);
                serialPorts = serialPorts(startsWith(serialPorts,"/dev/cu.usbserial"));
                ports = [ports serialPorts];
            end
            ports = unique(ports);
            if ispref('MATLAB_HARDWARE','HostIOServerEnabled') && getpref('MATLAB_HARDWARE','HostIOServerEnabled') && ispref('MATLAB_HARDWARE','HostIOServerHostPort')
                ports = [ports getpref('MATLAB_HARDWARE','HostIOServerHostPort')];
            end

        end

    end
end

% LocalWords:  arduinoapp
