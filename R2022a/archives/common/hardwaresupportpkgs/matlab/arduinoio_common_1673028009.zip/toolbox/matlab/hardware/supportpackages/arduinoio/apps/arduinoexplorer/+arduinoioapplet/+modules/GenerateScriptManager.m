classdef GenerateScriptManager < matlabshared.mediator.internal.Subscriber...
        &arduinoioapplet.modules.internal.ErrorSource
    % GENERATESCRIPTMANAGER - Class that manages the script generation
    % workflow Arduino Explorer app.

    % Copyright 2021 The MathWorks, Inc.

    properties(Hidden)
        % Mediator handle
        Mediator

        % Handle to HWMgr device card info
        DeviceInfo

        % Utility class used for script generation.
        GenerateScriptUtil

        % Additional parameters required to generate the script.
        PinTableHandle
        Board
        ConnectionType
        Address
        WiFiPort

        % Workspace variable name to save recorded data and duration to record
        WorkspaceVarName
        Duration

        % Variable names referenced in the script that should be cleared.
        VarsToBeCleared = {}
        RecordCustomNames = {}

        % Servo object suffix counter and Pin-Servo Object map
        ServoObjCtr = 1
        PinServoCtrMap
    end

    properties (Constant, Access=private)
        % Suffix for the MATLAB data array having pin data
        DataArraySuffix = "Array"
    end

    methods
        function obj = GenerateScriptManager(mediator, deviceInfo, pinTableHandle,initialWorkspaceVarName,initialDuration)
            % Call the superclass constructor.
            obj@matlabshared.mediator.internal.Subscriber(mediator);

            obj.Mediator = mediator;
            obj.DeviceInfo = deviceInfo;
            obj.PinTableHandle = pinTableHandle;
            obj.PinServoCtrMap = containers.Map();
            obj.WorkspaceVarName = initialWorkspaceVarName;
            obj.Duration = initialDuration;

            % Construct the script generation utility object.
            obj.GenerateScriptUtil = arduinoioapplet.modules.internal.GenerateScriptUtil();
        end

        function subscribeToMediatorProperties(obj, ~, ~)
            obj.subscribe('UserRequestedCodeGen', @(src, event)obj.generateScript());
            obj.subscribe('CurrentWorkspaceVarName', @(src, event)obj.handleWorkspaceVarEdit(event.AffectedObject.CurrentWorkspaceVarName));
            obj.subscribe('CurrentDuration', @(src, event)obj.handleDurationEdit(event.AffectedObject.CurrentDuration));
        end

        function generateScript(obj)
            % Generate script that replicates the results achieved in the Arduino Explorer app.

            % Generate title for the script.
            obj.generateTitle();

            % Generate introduction section.
            obj.generateIntro();

            % Generate code to create a channel object for the specified device.
            obj.generateCreateArduinoObjCode();

            % Generate code to configure Arduino pins.
            obj.generatePinConfigCode();

            % Generate code to read/write Arduino pins.
            obj.generateReadWriteCode();

            % Generate code to clean up variables.
            obj.generateCleanUpCode();

            % Output the generated script into an MLX-file.
            obj.outputGeneratedScript();
        end
    end

    methods(Access = private)
        function generateTitle(obj)
            % Generate title for the script.

            % Clear any text left behind in the utility object.
            obj.GenerateScriptUtil.clearText();

            scriptTitle = message('MATLAB:arduinoio:arduinoapp:scriptTitle',char(datetime)).getString;
            obj.GenerateScriptUtil.addSectionHeader(scriptTitle);

            obj.GenerateScriptUtil.addNewLine();
        end

        function generateIntro(obj)
            % Generate introduction section.

            sectionHeader = message('MATLAB:arduinoio:arduinoapp:introSectionHeader').getString;
            obj.GenerateScriptUtil.addSectionHeader(sectionHeader);

            sectionComment = message('MATLAB:arduinoio:arduinoapp:introSectionComment').getString;
            obj.GenerateScriptUtil.addComment(sectionComment);

            obj.GenerateScriptUtil.addNewLine();
        end

        function generateCreateArduinoObjCode(obj)
            % Generate code to create a channel object for the specified device.

            sectionHeader = message('MATLAB:arduinoio:arduinoapp:createArduinoObjectSectionHeader').getString;
            obj.GenerateScriptUtil.addSectionHeader(sectionHeader);

            sectionComment = message('MATLAB:arduinoio:arduinoapp:createArduinoObjectSectionComment').getString;
            obj.GenerateScriptUtil.addComment(sectionComment);

            % Get the vendor, device and channel index for the selected device.
            obj.ConnectionType = obj.DeviceInfo.CustomData.ConnectionType;
            obj.Board = obj.DeviceInfo.CustomData.Board;
            obj.Address = obj.DeviceInfo.CustomData.Address;
            obj.WiFiPort = obj.DeviceInfo.CustomData.WiFiPort;

            % Create the channel creation code according to the current protocol and vendor.
            switch char(obj.ConnectionType)
                case 'Serial'
                    codeLine = sprintf('arduinoObj = arduino("%s", "%s")', obj.Address, obj.Board);
                case 'Bluetooth'
                    codeLine = sprintf('arduinoObj = arduino("%s")', obj.Address);
                case 'WiFi'
                    if isempty(obj.WiFiPort)
                        codeLine = sprintf('arduinoObj = arduino("%s", "%s")', obj.Address, obj.Board);
                    else
                        codeLine = sprintf('arduinoObj = arduino("%s", "%s, %d")', obj.Address, obj.Board, obj.WiFiPort);
                    end
                otherwise
                    errObj = MException("MATLAB:arduinoio:arduinoapp:codeGenInvalidProtocol",...
                        message("MATLAB:arduinoio:arduinoapp:codeGenInvalidProtocol").getString);
                    obj.setErrorObjProperty(errObj);
            end
            obj.GenerateScriptUtil.addCodeLine(codeLine);

            obj.GenerateScriptUtil.addNewLine();

            % Add the channel object to the list of variables to be cleared at the end of the script.
            obj.VarsToBeCleared = [obj.VarsToBeCleared {'arduinoObj'}];
        end

        function generatePinConfigCode(obj)
            % Generate code to configure channel properties.

            pinsInUse = obj.PinTableHandle.getPinsInUse();

            % Generate code only if there are pins configured
            if ~isempty(pinsInUse)
                sectionHeader = message('MATLAB:arduinoio:arduinoapp:pinConfigSectionHeader').getString;
                obj.GenerateScriptUtil.addSectionHeader(sectionHeader);

                sectionComment = message('MATLAB:arduinoio:arduinoapp:pinConfigSectionComment').getString;
                obj.GenerateScriptUtil.addComment(sectionComment);

                for index = 1:length(pinsInUse)
                    pin = pinsInUse{index};
                    mode = obj.PinTableHandle.getPinMode(pinsInUse{index});
                    if strcmpi(mode,"Servo")
                        codeLine = sprintf('servoObj%d = servo(arduinoObj, "%s")',obj.ServoObjCtr,pin);
                        servoObjVar = sprintf('servoObj%d',obj.ServoObjCtr);
                        obj.VarsToBeCleared = [obj.VarsToBeCleared {servoObjVar}];
                        obj.PinServoCtrMap(pin) = obj.ServoObjCtr;
                        obj.ServoObjCtr = obj.ServoObjCtr + 1;
                    else
                        codeLine = sprintf('configurePin(arduinoObj, "%s", "%s")',pinsInUse{index},mode);
                    end
                    obj.GenerateScriptUtil.addCodeLineWithSemiColon(codeLine);
                end
                obj.GenerateScriptUtil.addNewLine();
            end
        end

        function generateReadWriteCode(obj)
            % Generate code to read/write Arduino pins.

            pinsToRead = obj.PinTableHandle.getPinsToRead();
            pinsToWrite = obj.PinTableHandle.getPinsToWrite();

            % Generate read/write code only if there are pins configured in these modes
            if ~isempty(pinsToRead) || ~isempty(pinsToWrite)
                sectionHeader = message('MATLAB:arduinoio:arduinoapp:pinReadWriteSectionHeader').getString;
                obj.GenerateScriptUtil.addSectionHeader(sectionHeader);

                sectionComment = message('MATLAB:arduinoio:arduinoapp:pinReadWriteSectionComment').getString;
                obj.GenerateScriptUtil.addComment(sectionComment);

                obj.GenerateScriptUtil.addNewLine();

                % Check if there are any pins to record
                pinsToRecord = getPinsToRecord(obj.PinTableHandle);
                % If there are pins to record, generate initialization code
                % recording pins
                if ~isempty(pinsToRecord)
                    obj.generateInitRecordingCode(pinsToRecord);
                end

                generateReadPinsCode(obj);
                obj.GenerateScriptUtil.addNewLine();
                generateWritePinsCode(obj);

                % If there are pins to record, generate initialization code
                % recording pins
                if ~isempty(pinsToRecord)
                    obj.generateCompleteRecordingCode();
                end
            end
        end

        function generateInitRecordingCode(obj,pinsToRecord)
            % Function to generate the initialization code block
            % for recording the Arduino pin data

            obj.GenerateScriptUtil.addNewLine();
            sectionComment = sprintf("NOTE: %s",message('MATLAB:arduinoio:arduinoapp:recordingSectionComment').getString);
            obj.GenerateScriptUtil.addSectionHeader("");
            obj.GenerateScriptUtil.addComment(sectionComment);
            obj.GenerateScriptUtil.addNewLine();

            codeLine = sprintf("%% %% %s\n",message('MATLAB:arduinoio:arduinoapp:recordDurationComment').getString);
            codeLine = codeLine+sprintf("%% duration = %d;\n",obj.Duration);
            codeLine = codeLine+sprintf("%% %% %s\n",message('MATLAB:arduinoio:arduinoapp:stepTimeComment').getString);
            codeLine = codeLine+sprintf("%% stepTime = %d;\n",arduinoioapplet.internal.ArduinoAppConstants.PollingInterval);
            codeLine = codeLine+sprintf("%% %% %s\n",message('MATLAB:arduinoio:arduinoapp:numSamplesComment').getString);
            codeLine = codeLine+sprintf("%% samples = duration/stepTime;\n");
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            obj.VarsToBeCleared = [obj.VarsToBeCleared {'duration','stepTime','samples'}];

            codeLine = sprintf("%% %% %s\n",message('MATLAB:arduinoio:arduinoapp:initArraysComment').getString);
            for pinIndex = 1:length(pinsToRecord)
                pin = pinsToRecord{pinIndex};

                % Don't generate code to record pins exclusively in write mode
                if any(ismember(obj.PinTableHandle.getPinsToWrite,pin)) && ...
                        ~any(ismember(obj.PinTableHandle.getPinsToRead,pin))
                    continue;
                end

                customName = obj.PinTableHandle.getCustomName(pin);
                % Handle multiple pins having same custom names. Prefix pin number in such cases.
                recordDataVarName = customName;
                if ~strcmpi(customName,pin)
                    recordDataVarName = sprintf("%s_%s",pin,customName);
                end
                obj.RecordCustomNames{end+1} = recordDataVarName;
                codeLine = codeLine + sprintf("%% %s = zeros(1,samples);\n",recordDataVarName+obj.DataArraySuffix);
            end
            obj.VarsToBeCleared = [obj.VarsToBeCleared obj.RecordCustomNames+obj.DataArraySuffix];
            obj.GenerateScriptUtil.addCodeLine(codeLine);

            codeLine = sprintf("%% tObj = tic;\n");
            codeLine = codeLine + sprintf("%% dataIndex = 1;\n");
            codeLine = codeLine + sprintf("%% while(toc(tObj) <= duration)\n");
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            obj.VarsToBeCleared = [obj.VarsToBeCleared {'tObj','dataIndex'}];
        end

        function generateCompleteRecordingCode(obj)
            % Function to generate the code to save the recorded data

            codeLine = sprintf("%% %% %s\n",message('MATLAB:arduinoio:arduinoapp:addDataToArrayComment').getString);
            for pinIndex = 1:length(obj.RecordCustomNames)
                codeLine = codeLine + sprintf("%% %s(dataIndex) = %s;\n",...
                    obj.RecordCustomNames{pinIndex}+obj.DataArraySuffix,obj.RecordCustomNames{pinIndex});
            end
            codeLine = codeLine + sprintf("%% dataIndex = dataIndex + 1;\n");
            obj.GenerateScriptUtil.addCodeLine(codeLine);

            codeLine = sprintf("%% %% %s\n",message('MATLAB:arduinoio:arduinoapp:pauseComment').getString);
            codeLine = codeLine + sprintf("%% pause(stepTime);\n");
            codeLine = codeLine + "% end";
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            obj.GenerateScriptUtil.addNewLine();

            codeLine = sprintf("%% %% %s",message('MATLAB:arduinoio:arduinoapp:convertToTimeTableComment').getString);
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            codeLine  = sprintf("%% %s = timetable(",obj.WorkspaceVarName);
            for index = 1:length(obj.RecordCustomNames)
                codeLine = codeLine + sprintf("%s',",obj.RecordCustomNames{index}+obj.DataArraySuffix);
            end
            codeLine = codeLine + sprintf("'TimeStep',seconds(stepTime));");
            obj.GenerateScriptUtil.addCodeLine(codeLine);

            % Generate plot code
            obj.GenerateScriptUtil.addNewLine();
            codeLine = sprintf("%% %% %s",message('MATLAB:arduinoio:arduinoapp:plotComment').getString);
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            codeLine = sprintf("%% plot(%s.Time, %s.Variables);",obj.WorkspaceVarName,obj.WorkspaceVarName);
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            codeLine = sprintf("%% title(""%s"");",message('MATLAB:arduinoio:arduinoapp:plotTitle').getString);
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            codeLine = sprintf("%% xlabel(""%s"");",message('MATLAB:arduinoio:arduinoapp:plotXLabel').getString);
            obj.GenerateScriptUtil.addCodeLine(codeLine);
            codeLine = sprintf("%% ylabel(""%s"");",message('MATLAB:arduinoio:arduinoapp:plotYLabel').getString);
            obj.GenerateScriptUtil.addCodeLine(codeLine);
        end

        function generateReadPinsCode(obj)
            % Function to generate read pin code

            pinsToRead = obj.PinTableHandle.getPinsToRead();
            for pinIndex = 1:length(pinsToRead)
                pin = pinsToRead{pinIndex};

                customName = obj.PinTableHandle.getCustomName(pin);
                % Prefix pin name if custom name is different name from pin number.
                % This will avoid overwriting the same variable.
                if ~strcmpi(customName,pin)
                    customName = sprintf("%s_%s",pin,customName);
                end
                [mode,~] = obj.PinTableHandle.getPinMode(pin);
                switch char(mode)
                    case 'AnalogInput'
                        codeLine = sprintf('%s = readVoltage(arduinoObj, "%s")',customName,pin);
                    case 'DigitalInput'
                        codeLine = sprintf('%s = readDigitalPin(arduinoObj, "%s")',customName,pin);
                    case 'Servo'
                        codeLine = sprintf('%s = readPosition(servoObj%d)',customName,obj.PinServoCtrMap(pin));
                    otherwise
                end
                obj.GenerateScriptUtil.addCodeLineWithSemiColon(codeLine);
            end
            obj.GenerateScriptUtil.addNewLine();
        end

        function generateWritePinsCode(obj)
            % Function to generate write pin code
            pinsToWrite = obj.PinTableHandle.getPinsToWrite();
            for pinIndex = 1:length(pinsToWrite)
                pin = pinsToWrite{pinIndex};
                writeValue = obj.PinTableHandle.getWriteValue(pin);
                [mode,type] = obj.PinTableHandle.getPinMode(pin);
                if ~isempty(writeValue)
                    switch char(mode)
                        case 'DigitalOutput'
                            codeLine = sprintf('writeDigitalPin(arduinoObj, "%s", %d)',pin,ceil(str2double(writeValue)));
                        case 'PWM'
                            if strcmpi(type,"Voltage")
                                codeLine = sprintf('writePWMVoltage(arduinoObj, "%s", %.2f)',pin,str2double(writeValue));
                            elseif strcmpi(type,"DutyCycle")
                                codeLine = sprintf('writePWMDutyCycle(arduinoObj, "%s", %.2f)',pin,str2double(writeValue));
                            end
                        case 'Servo'
                            codeLine = sprintf('writePosition(servoObj%d, %.2f)',obj.PinServoCtrMap(pin),str2double(writeValue));
                        case 'Tone'
                            if strcmpi(type,"Duration")
                                codeLine = sprintf('playTone(arduinoObj,"%s", %d, %d)',pin,arduinoioapplet.internal.ArduinoAppConstants.DefaultToneFrequency,str2double(writeValue));
                            elseif strcmpi(type,"Frequency")
                                codeLine = sprintf('playTone(arduinoObj,"%s", %d, %d)',pin,str2double(writeValue),arduinoioapplet.internal.ArduinoAppConstants.DefaultToneDuration);
                            end
                        otherwise
                    end
                    obj.GenerateScriptUtil.addCodeLineWithSemiColon(codeLine);
                end

            end
            obj.GenerateScriptUtil.addNewLine();
        end

        function generateCleanUpCode(obj)
            % Generate code to clean up variables.

            sectionHeader = message('MATLAB:arduinoio:arduinoapp:cleanUpSectionHeader').getString;
            obj.GenerateScriptUtil.addSectionHeader(sectionHeader);

            sectionComment = message('MATLAB:arduinoio:arduinoapp:cleanUpSectionComment').getString;
            obj.GenerateScriptUtil.addComment(sectionComment);

            codeLine = sprintf('clear %s', strjoin(obj.VarsToBeCleared));
            obj.GenerateScriptUtil.addCodeLine(codeLine);

            obj.GenerateScriptUtil.addNewLine();
        end

        function outputGeneratedScript(obj)
            % Output the generated script into an MLX-file.

            obj.GenerateScriptUtil.createMLXFile();
            obj.GenerateScriptUtil.clearText();
            obj.VarsToBeCleared = {};
            obj.RecordCustomNames = {};
            obj.ServoObjCtr = 1;
            obj.PinServoCtrMap = containers.Map();
        end

        function handleWorkspaceVarEdit(obj,value)
            obj.WorkspaceVarName = value;
        end

        function handleDurationEdit(obj,value)
            obj.Duration = value;
        end
    end

end

% LocalWords:  arduinoapp Bluetooth WiFi MLX
