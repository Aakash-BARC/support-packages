classdef ArduinoManager < arduinoioapplet.modules.internal.ErrorSource
    % ARDUINOMANAGER - Module that manages the Arduino device connection for
    % the Arduino Explorer app

    % Copyright 2021 The MathWorks, Inc.

    properties(Access = private)
        % Connection type of the Arduino
        ConnectionType

        % Name of the Arduino hardware
        Board

        % COM, BT Address or WiFi IP Address of the Arduino
        Address

        % TCP/IP port for Arduino WiFi connection
        WiFiPort

        % Arduino connection object
        ArduinoObj

        % Map to hold servo connection created using Arduino object
        PinServoMap

        % Hardware Manager device info
        DeviceInfo

        % Handle to the Arduino Board Info object
        ResourceManager
    end

    properties(Hidden)

        % Arduino pin types
        AllPins
        AnalogPins
        DigitalPins
        PWMPins
        ServoPins
        SPIPins
        I2CPins
        InterruptPins
        SerialPins

        % Pin Mode types
        AnalogPinModes
        DigitalPinModes
        AllPinModes
    end

    properties(Constant,Access=private)
        DefaultDuration = arduinoioapplet.internal.ArduinoAppConstants.DefaultToneDuration;
        DefaultFrequency = arduinoioapplet.internal.ArduinoAppConstants.DefaultToneFrequency;
    end

    methods
        % Constructor
        function obj = ArduinoManager(deviceInfo)
            obj.DeviceInfo = deviceInfo;
            obj.ResourceManager = arduinoio.internal.ResourceManager(deviceInfo.CustomData.Board);

            initizalizeArduinoParams(obj);
            initArduinoPinInfo(obj);
        end

        function createArduinoConnection(obj)
            % Function to create a connection to the selected Arduino board
            % based on the connection type
            try
                if(isempty(obj.ArduinoObj) || ~isvalid(obj.ArduinoObj))
                    if isequal(obj.ConnectionType,matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi)
                        obj.ArduinoObj = arduino(obj.Address,obj.Board,str2double(obj.WiFiPort));
                    elseif isequal(obj.ConnectionType,matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth)
                        obj.ArduinoObj = arduino(obj.Address);
                    elseif ispref('MATLAB_HARDWARE','HostIOServerEnabled') && getpref('MATLAB_HARDWARE','HostIOServerEnabled')
                        obj.ArduinoObj = arduino(obj.Address,obj.Board);
                    else
                        % Work with existing server and turn off verbose
                        obj.ArduinoObj = arduino(obj.Address,obj.Board,"TraceOn",false);
                    end
                end
            catch e
                throwAsCaller(e);
            end
        end

        function configurePin(obj,pin,mode)
            % Function to configure pin mode

            try
                % Get current pin mode and return if the mode being set is the same
                currentPinMode = getPinMode(obj,pin);
                if strcmpi(currentPinMode,mode)
                    return;
                end

                % Release servo object if pin is already configured to Servo
                if strcmpi(currentPinMode,"Servo")
                    obj.PinServoMap(pin) = [];
                end

                % Configure pin to Unset first for any mode other than Unset
                if ~strcmpi(mode, "Unset")
                    configurePin(obj.ArduinoObj,pin,"Unset");
                end

                % Configure pin
                if strcmpi(mode,"Servo")
                    servoObj = servo(obj.ArduinoObj,pin);
                    obj.PinServoMap(pin) = servoObj;
                else
                    configurePin(obj.ArduinoObj,pin,mode);
                end
            catch e
                throwAsCaller(e);
            end
        end

        function readData =  readPin(obj,pin,mode)
            % Function to read an Arduino pin based on the mode to which it is set to

            if strcmpi(mode,"AnalogInput")
                readData = readVoltage(obj.ArduinoObj,pin);
            elseif strcmpi(mode,"DigitalInput")
                readData = readDigitalPin(obj.ArduinoObj,pin);
            elseif strcmpi(mode,"Servo") && ~isempty(obj.PinServoMap(pin)) &&...
                    isvalid(obj.PinServoMap(pin))
                readData = readPosition(obj.PinServoMap(pin));
            else
                readData = "";
            end
        end

        function writePin(obj,pin,mode,modeType,value)
            % Function to write specified value to an Arduino pin
            % based on the mode to which it is set to

            try
                if strcmpi(mode,"DigitalOutput")
                    writeDigitalPin(obj.ArduinoObj,pin,value);
                elseif strcmpi(mode,"Servo")
                    writePosition(obj.PinServoMap(pin),value);
                elseif ismember(mode,["PWM","Tone"])
                    switch char(modeType)
                        case 'Voltage'
                            writePWMVoltage(obj.ArduinoObj,pin,value);
                        case 'Duty cycle'
                            writePWMDutyCycle(obj.ArduinoObj,pin,value);
                        case 'Duration'
                            playTone(obj.ArduinoObj,pin,obj.DefaultFrequency,value);
                        case 'Frequency'
                            playTone(obj.ArduinoObj,pin,value,obj.DefaultDuration)
                        otherwise
                    end
                end
            catch e
                throwAsCaller(e);
            end
        end

        function mode = getPinMode(obj,pin)
            % Function to get current pin modes for a particular pin
            mode = configurePin(obj.ArduinoObj,pin);
        end

        function modes = getSupportedModesFromPin(obj,pin)
            % Function to get all supported pin modes for a particular pin
            modes = obj.ResourceManager.getSupportedModes(obj.ResourceManager.getTerminalsFromPins(pin));
        end

        function result = isLibraryUploaded(obj, library)
            % Function to check if a particular library is present in Arduino

            result = ismember(char(library),obj.ArduinoObj.Libraries);
        end

        function [resourceOwner,mode] = getPinInfo(obj,pin)
            % Function to get the current resource owner and mode of an
            % Arduino pin
            [~,~,mode,resourceOwner] = obj.ResourceManager.getPinInfo(obj.ArduinoObj,pin);
            if isempty(resourceOwner)
                resourceOwner = obj.Board;
            end
        end
    end

    methods(Access=private)
        function initizalizeArduinoParams(obj)
            % Function to initialize basic Arduino board parameters

            obj.ConnectionType = obj.DeviceInfo.CustomData.ConnectionType;
            obj.Board = obj.DeviceInfo.CustomData.Board;
            obj.Address = obj.DeviceInfo.CustomData.Address;
            obj.WiFiPort = obj.DeviceInfo.CustomData.WiFiPort;
            obj.PinServoMap = containers.Map();
        end

        function initArduinoPinInfo(obj)
            % Get pin numbers for each pin type for the selected Arduino

            obj.AnalogPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsAnalog);
            obj.DigitalPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsDigital);
            obj.AllPins = [obj.AnalogPins obj.DigitalPins];
            obj.PWMPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsPWM);
            obj.I2CPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsI2C);
            obj.InterruptPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsInterrupt);
            obj.ServoPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsServo);
            if ~isempty(obj.ResourceManager.TerminalsSPI)
                obj.SPIPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsSPI);
            end
            if ~isempty(obj.ResourceManager.TerminalsSerial)
                obj.SerialPins = obj.ResourceManager.getPinsFromTerminals(obj.ResourceManager.TerminalsSerial);
            end
            obj.AnalogPinModes = sort(obj.ResourceManager.AnalogPinModes);
            obj.DigitalPinModes = sort(obj.ResourceManager.DigitalPinModes);
            obj.AllPinModes = union(obj.AnalogPinModes,obj.DigitalPinModes);
        end
    end

    % Internal private getter functions
    methods
        function name =  getBoardName(obj)
            name = obj.Board;
        end
    end

end

% LocalWords:  WiFi TCP BT
