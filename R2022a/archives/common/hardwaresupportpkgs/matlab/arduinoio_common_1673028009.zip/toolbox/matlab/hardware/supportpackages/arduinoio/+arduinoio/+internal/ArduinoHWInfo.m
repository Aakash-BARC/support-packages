function [info, status] = ArduinoHWInfo()
    %   ARDUINOHWINFO retrieves information of Arduino Hardware connected
    %   to the system by checking from a list VID_PIDs present in boards.xml file
    %   Syntax:
    %       arduinoio.internal.ArduinoHWInfo
    %
    % Copyright 2020-2021 The MathWorks, Inc.

    %   info stores the details of Arduino Hardware
    info = [];
    status = 0;
    USBDevEnumObj = matlab.hwmgr.internal.hwconnection.USBDeviceEnumerator;
    [ports,devices] = getSerialPorts(USBDevEnumObj);

    try
        % Extract all VID_PID from boards.xml and lists in boardsXML
        boardsXML = fullfile(arduinoio.SharedArduinoRoot,'+arduinoio','+internal','boards.xml');
        xml = readstruct(boardsXML);
        content = [];
        listOfVidPid = {};

        % Extract all the supported Arduino board names
        boardNames = fieldnames(xml);
        for boardIDX=1:length(boardNames)
            % Extract the VID_PID of each Arduino board
            content = char(xml.(boardNames{boardIDX}).VID_PID);
            tempCell = strsplit(content,{',','_'});
            listOfVidPid = [listOfVidPid, tempCell];
        end

        listOfVidPid = regexprep(listOfVidPid, ["'","0x"], '');
        % To remove empty cells
        listOfVidPid = listOfVidPid(~cellfun('isempty',listOfVidPid));
        % To keep a check on available Arduino Hardware
        hardwareFlag = 0;

        for idx = 1:length(devices)
            for vidPidIdx = 1:length(listOfVidPid)
                if strcmpi(devices(idx).VendorID,listOfVidPid(vidPidIdx)) || strcmpi(devices(idx).ProductID,listOfVidPid(vidPidIdx))
                    hardwareFlag = 1;
                    info(end+1).VendorID = devices(idx).VendorID;
                    info(end).ProductID = devices(idx).ProductID;
                    info(end).Manufacturer = devices(idx).Manufacturer;
                    info(end).ProductName = devices(idx).ProductName;
                    info(end).SerialNumber = devices(idx).SerialNumber;
                    info(end).PortNumber = ports{idx};
                    break;
                end
            end
        end
        if ~hardwareFlag
            info = [];
        end
    catch e
        status = 1;
        info = sprintf("Unable to detect boards.xml.\nError message: %s\n",e.message);
    end
end
