classdef USBDeviceDescriptor < arduinoioapplet.descriptors.DeviceDescriptor &...
        matlab.hwmgr.internal.DeviceParamsDescriptor
    % This is the Arduino Hardware Device Descriptor subclass to manually add
    % non-enumerable USB Arduino device

    % Copyright 2021 The MathWorks, Inc.
    properties
        % The active connection type
        ConnectionType

        % Primary fields for any Arduino connection
        % USB Serial port address
        Address

        % Name of the Arduino board as shown in the drop-down list
        Board

        % List of all supported Arduino boards for a specific connection type
        SupportedBoards

        % Flag indicating if the friendly name field was edited
        IsDefaultFriendlyName
    end

    %% Hardware Manager Device Descriptor functions
    methods
        function obj = USBDeviceDescriptor(name)
            % Constructor - As a general guideline, the parameters should
            % be added in the constructor

            import arduinoioapplet.internal.ArduinoAppConstants

            % Create HardwareManager Device parameter descriptor instance
            obj@matlab.hwmgr.internal.DeviceParamsDescriptor(name,...
                arduinoio.internal.getDocMap,...
                'arduinoexplorer_addusbdevice',...
                getString(message("MATLAB:arduinoio:arduinoapp:addUSBDeviceDescription")),true);

            % Syntax: addParameter(<paramID>, <paramName>, <Type>, <allowedValuesFunction>, <enableFunction>);
            % Syntax: addButton(<paramID>, <label>, <icon>, <style>, <buttonPushedFunction>, <enableFunction>, <sectionLabel>);
            obj.addButton('HardwareSetup', obj.HardwareSetupLabel,...
                matlab.ui.internal.toolstrip.Icon(fullfile(ArduinoAppConstants.IconFolder,ArduinoAppConstants.HardwareSetupIcon)),...
                'Vertical', @obj.launchHardwareSetup, function_handle.empty,obj.SetupSectionName);
            obj.addParameter('Board', getString(message("MATLAB:arduinoio:arduinoapp:boardLabel")),...
                'DropDown', @obj.updateBoards, function_handle.empty,obj.SetupSectionName);
            obj.addParameter('Address',getString(message("MATLAB:arduinoio:arduinoapp:portLabel")),...
                'DropDown', @obj.updateUSBPorts, function_handle.empty,obj.SetupSectionName);
            obj.addParameter('FriendlyName',obj.FriendlyNameLabel,...
                'EditField', @obj.updateName, function_handle.empty,obj.SetupSectionName);

            obj.ConnectionType = matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial;
            obj.IsDefaultFriendlyName = true;
        end
    end

    %% Toolstrip fields allowedValueFcn and enableFcn callback function
    methods(Access = private)
        function status = launchHardwareSetup(obj,~)
            % Callback function to launch the Arduino Hardware Setup
            % from the second screen(after selecting the corresponding connection type)

            status = 0;
            appDialogParent = obj.getDialogParent();
            workflow = matlab.hwmgr.internal.hwsetup.register.ArduinoWorkflow('tripwire', 'arduinoExplorer',...
                'ConnectionType', obj.ConnectionType);
            appDialogParent.Busy = 1;
            workflow.launch;
            appDialogParent.Busy = 0;
        end

        function boards = updateBoards(obj,~)
            % Callback function for the board drop-down field
            % Update list of supported boards based on the connection type chosen.

            obj.SupportedBoards = [{'Select board'}, sort(arduinoio.internal.TabCompletionHelper.getSupportedBoards)];
            boards = obj.SupportedBoards;

            % remove when ESP32 is supported from app
            boards = setdiff(boards,{'ESP32-WROOM-DevKitV1', 'ESP32-WROOM-DevKitC'},'stable');
        end

        function data = updateUSBPorts(obj,~)
            % Function to update the USB port

            % Return all available USB ports.
            ports = getAvailableArduinoPorts(obj);
            data = [{'Select port'}, ports{:}];
        end
    end

    %% Internal utility functions used for adding device
    methods(Access=protected)
        function validateInputParams(obj, paramValMap)
            % Function to validate the input parameters provided by users
            % in the modal toolstrip

            % Validate board name
            validateBoard(obj,paramValMap('Board').NewValue);
            obj.Board = paramValMap('Board').NewValue;

            % Validate connection address
            validateAddress(obj, paramValMap('Address').NewValue);
            obj.Address = paramValMap('Address').NewValue;
        end

        function status = deviceExists(obj, varargin)
            % Check if the Arduino device already exists in the device panel

            status = 0;
            boardName = obj.Board;
            address = obj.Address;

            % First check the list of enumerated devices to see if there
            % already exists an Arduino device with the user specified
            % board and port/address combination.
            for bIndex = 1:length(obj.Provider.DevicesProvided)
                if strcmpi(address,obj.Provider.DevicesProvided(bIndex).CustomData.Address)
                    status = 1;
                    return;
                end
            end
        end

        function [status,errorMsg] = testArduinoConnection(obj, varargin)
            % Function to create Arduino connection to ensure the board is
            % up
            status = 0;
            errorMsg = [];
            boardName = obj.Board;
            address = obj.Address;
            try
                aObj = arduino(address,boardName);
                aObj = [];
            catch e
                status = 1;
                errorMsg = e.message;
            end
        end
    end

    methods(Access = private)
        function ports = getAvailableArduinoPorts(~)
            % Function to get all available Arduino Serial ports

            ports = arduinoioapplet.internal.Utility.getUSBSerialPorts();
        end
    end
end

% LocalWords:  VID
