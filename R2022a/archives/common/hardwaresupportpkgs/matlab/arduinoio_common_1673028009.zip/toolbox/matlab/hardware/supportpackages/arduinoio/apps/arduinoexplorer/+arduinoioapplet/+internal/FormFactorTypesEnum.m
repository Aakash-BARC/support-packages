classdef FormFactorTypesEnum
    % FORMFACTORTYPESENUM - Enumeration class listing the different types
    % of form factors for the Supported Arduino boards.
    % This is primarily used to select the device card icon.

    % Copyright 2021 The MathWorks, Inc

    enumeration
        Large
        Medium
        Small
    end
end

