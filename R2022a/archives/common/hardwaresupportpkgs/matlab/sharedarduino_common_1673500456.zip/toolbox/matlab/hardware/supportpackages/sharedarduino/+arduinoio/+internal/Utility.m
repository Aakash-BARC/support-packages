classdef Utility < arduinoio.internal.accessor
    %   Copyright 2017-2022 The MathWorks, Inc.
    
    properties(Access = protected)
        BoardInfo
    end
    
    properties(Access = private)
        CurrentSystemPath
        CurrentCPath
        CurrentDYLDLibPath
        DeleteTempDir
    end
    
    
    methods (Abstract)
        buildInfo = setProgrammer(obj, buildInfo);
    end
    
    %% Constructor
    methods
        function obj = Utility
            obj.BoardInfo = arduinoio.internal.BoardInfo.getInstance();
        end
    end
    
    %% Public methods
    methods(Static)
        function pressBootButtonDialog
            uiwait(msgbox(message('MATLAB:arduinoio:general:pressBootButton').getString,'modal'));
        end

          function releaseBootButtonDialog
            uiwait(msgbox(message('MATLAB:arduinoio:general:releaseBootButton').getString,'modal'));
        end
    end
    %% Public methods
    methods (Access = public)
        function validateIDEPath(obj, IDEPath)
            % Check if the given IDEPath points to a 1.6.x version of
            % Arduino IDE and if one or few files needed exists
            files = {fullfile('hardware','arduino','avr','cores','arduino', 'hooks.c')};%, fullfile('libraries','IoServer','IO_server.c')};
            for i = 1:length(files)
                if ~exist(fullfile(IDEPath, files{i}), 'file')
                    matlabshared.hwsdk.internal.localizedError('MATLAB:arduinoio:general:invalidIDEPath', IDEPath)
                end
            end
        end

        function [status,result] = complete3pInstall(obj,buildInfo)            
            buildInfo = getProgrammer(obj, buildInfo);
            installCmd = strcat(buildInfo.Programmer," --pref boardsmanager.additional.urls=","https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json --save-prefs --install-boards ""esp32:esp32:1.0.6"" ");
            [status,result] = system(installCmd);
        end

        function varargout = updateServer(obj, buildInfo)
            % This function compiles all necessary source files and downloads
            % the executable to the hardware
            % global flag for device plugin detection
            global ArduinoDevicePluginDetectionClient;
            clrGlobal = onCleanup(@()evalc('clearvars -global ArduinoDevicePluginDetectionClient'));
            origPort = buildInfo.Port;
            buildInfo = preBuildProcess(obj, buildInfo); % populate the complete set of fields in buildInfo structure
            if exist(buildInfo.TempDirPath, 'dir')
                rmdir(buildInfo.TempDirPath, 's');
            end
            obj.DeleteTempDir = (buildInfo.ConnectionType==matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi);
            generatePeripheralIncludeHeader(obj,buildInfo);
            generateAddonLibrariesHeader(obj, buildInfo);
            generateMacrosIncludeHeader(obj, buildInfo);
            generateMainSketch(obj, buildInfo);
            
            % Add tempdir to compiler's header file search dir
            obj.CurrentCPath = getenv('CPATH');
            setenv('CPATH', buildInfo.TempDirPath);
            if ispc
                obj.CurrentSystemPath = getenv('PATH');
                % Add 3P path ahead to avoid interference with other drivers like WinAVR
                setenv('PATH', [buildInfo.IDEPath, ';', obj.CurrentSystemPath]);
            elseif ismac
                % Reset environment variable to avoid Java interference
                % with Arduino IDE(default JAVA 8 runtime)
                obj.CurrentDYLDLibPath = getenv('DYLD_LIBRARY_PATH');
                setenv('DYLD_LIBRARY_PATH','');
            end
            c = onCleanup(@() cleanup(obj));
            
            errorMsg = '';
            [status, result] = uploadServer(obj, buildInfo);
            if status
                errorMsg = result;
            else
                % Wrong boards specified or board(Due and MKR1000) not programmable
                if contains(result, 'attempt 10 of 10: not in sync:')||...
                        contains(result, 'Unsupported processor')||...
                        contains(result, 'stk500v2_getsync(): timeout communicating with programmer')||...
                        contains(result, ['No device found on ', buildInfo.Port])
                    status = 1;
                    errorMsg = result;
                end
            end
            varargout{1} = errorMsg;
            % Check compiled hex size fits in the flash memory
            validateServerSize(obj, buildInfo);
            
            if status
                if ~buildInfo.ShowUploadResult
                    if isdeployed()
                        matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:failedUpload', buildInfo.Board, origPort);
                    else
                        matlabshared.hwsdk.internal.localizedError('MATLAB:arduinoio:general:failedUpload', buildInfo.Board, origPort);
                    end
                end
            else
                if ismember(buildInfo.Board, {'Micro', 'Leonardo'})
                    pause(5);
                elseif buildInfo.ConnectionType==matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi && ismember(buildInfo.Board,{'MKR1000','MKR1010','Nano33IoT'})
                    pause(15);
                end
            end
            
            
            function cleanup(obj)
                if ~isdeployed()
                    % Turn-on Arduino plugin detection
                    internal.deviceplugindetection.EnableArduinoHotPlug.getInstance.setEnableArduinoDPDM(true);
                end
                try
                    if obj.DeleteTempDir && exist(buildInfo.TempDirPath, 'dir')
                        rmdir(buildInfo.TempDirPath, 's');
                    end
                catch % only attempt to delete the temp folder and not throw any error
                end
                setenv('CPATH', obj.CurrentCPath);
                if ispc
                    setenv('PATH', obj.CurrentSystemPath);
                elseif ismac
                    setenv('DYLD_LIBRARY_PATH', obj.CurrentDYLDLibPath);
                end
            end
        end
        
     function alternateHeaderSearch = areAlternateLibraryHeadersAvailableImpl(~, buildInfo)
            % Generates a logical array called alternateHeaderSearch
            % A true entry means the corresponding library in the
            % includedLibs has an alternate header associated with it
            % Checks if any alternate 3P header file is associated with the
            % specifed library list and boards
            includedLibs = buildInfo.Libraries;
            includedLibs(ismember(includedLibs,{'I2C','SPI'})) = [];      
            alternateHeaderSearch =  false(length(includedLibs),1);
            alternateLibHeaderSupportList = arduinoio.internal.ArduinoConstants.AlternateLibraryHeaderSupport;
            % check if specified library has an alternate library header     
            for libCount = 1:length(includedLibs)
                %alternateHeaderSearch{libCount} = false;
                alternateLibHeaderAvailable = cellfun(@(x)ismember(x{1}, includedLibs(libCount)), alternateLibHeaderSupportList, 'UniformOutput', true);
                if any(alternateLibHeaderAvailable)
                    alternateLibHeaderAvailable = double(find(alternateLibHeaderAvailable > 0));
                     % check if the specified board is associated with the specified library
                    if ismember(buildInfo.Board, alternateLibHeaderSupportList{alternateLibHeaderAvailable(1)}{2})
                       alternateHeaderSearch(libCount) = true;
                    end
                end
            end
         
     end
        
    end
    
    
    %% Private methods
    methods(Access = private)
        function [missingHeaders, libs] = areLibrariesAvailable(~, buildInfo)
            % Check if to be downloaded libraries' 3P source, e.g the
            % corresponding library folder has been installed in either the
            % IDE libraries folder or the sketch preference location's
            % libraries folder.
            searchDirectories{1} = fullfile(buildInfo.IDEPath, 'libraries');
            if ispc || (isunix && ~ismac)
                % On Linux and Win64, the sketchbook path is under
                % <IDEPath>/portable
                prefDir = fullfile(buildInfo.IDEPath, 'portable', 'sketchbook');
            else
                % On Mac, the libraries path can be extracted from the
                % result of the command below.
                cmd = [buildInfo.Programmer, ' --get-pref sketchbook.path'];
                [~, result] = system(cmd);
                fields = textscan(result, '%s', 'delimiter', newline);
                % On Mac, fields{1}{end} gives the correct path whereas it
                % gives garbage string for Linux and Win in Arduino IDE 1.8.10
                prefDir = fields{1}{end};
            end          
            searchDirectories{2} = fullfile(prefDir, 'libraries');
            
            allInstalledLibraries = '';
            for index = 1:2
                result = dir(searchDirectories{index});
                isSubDir = [result(:).isdir];
                libDirs = {result(isSubDir).name}';
                libDirs(ismember(libDirs,{'.','..'})) = [];
                if ~isempty(libDirs)
                    if isempty(allInstalledLibraries)
                        allInstalledLibraries = strcat(allInstalledLibraries, strjoin(libDirs, ', '));
                    else
                        allInstalledLibraries = [allInstalledLibraries, ', ', strjoin(libDirs, ', ')];  %#ok<AGROW>
                    end
                end
            end
            
            libs = {};
            mheaders = {};
            includedLibs = buildInfo.Libraries;
            includedLibs(ismember(includedLibs,{'I2C','SPI'})) = [];
            
            % Check if an alternate library is available for user
            % specified libraries. See arduinoio.internal.ArduinoConstants.AlternateLibrariesSupport
            % for list of such libraries and boards associated with them.
            % E.g. MotorCarrier library specified on MKR boards (listed in AlternateLibrariesSupport) must select
            % the 3P header file i.e MMKRMotorCarrier.h, associated with the alternate library (MKRMotorCarrier) instead of
            % ArduinoMotorCarrier.h listed under the MotorCarrier class         
            if isfield(buildInfo, 'AlternateLibraryHeadersAvailable')
                alternateHeaderStatus = buildInfo.AlternateLibraryHeadersAvailable;
            else
                alternateHeaderStatus = false(length(includedLibs),1);
            end
            
            for libCount = 1:length(includedLibs)
                % Check if an alternate library header file is available for the
                % specified library. Get the headerFile associated with the specified library in other case.
                headerFile = arduinoio.internal.getDefaultLibraryPropertyValue(includedLibs{libCount}, 'LibraryHeaderFiles', alternateHeaderStatus(libCount));
                if ~isempty(headerFile)
                    if ischar(headerFile)
                        headerFile = {headerFile};
                    end
                    % Split the headerFile(s) name w.r.t the '/' file
                    % separator
                    headerFileSplit = cellfun(@(x)strsplit(x, '/'), headerFile, 'UniformOutput',false);
                    % Retain the folder name of the arduino source file
                    theLib = cellfun(@(x) x(1), headerFileSplit, 'UniformOutput',false);
                    % Check if the arduino source files exists for the
                    % specified library
                    mheadersCheck = cellfun(@(x) ~contains(allInstalledLibraries, x), theLib);
                    if any(mheadersCheck)
                        libs = [libs, includedLibs{libCount}]; %#ok<AGROW>
                        % Find the index of the missing header file
                        mheaderIndex = find(double(mheadersCheck) == 1);
                        % Append the mising header file to the mheaders
                        % cell array
                        mheaders = [mheaders, headerFile{mheaderIndex}]; %#ok<AGROW>
                    end
                end
            end
            
            if isempty(libs)
                missingHeaders = '';
            else
                missingHeaders =  matlabshared.hwsdk.internal.renderCellArrayOfCharVectorsToCharVector(mheaders, ', ');
            end
        end

        function buildInfo = getProgrammer(obj, buildInfo)
            if ~isdeployed()
                buildInfo.IDEPath = arduinoio.IDERoot;
                validateIDEPath(obj, buildInfo.IDEPath);
            end
            buildInfo = setProgrammer(obj, buildInfo);
        end

        function buildInfo = preBuildProcess(obj,buildInfo)
            % Populate all needed fields in buildInfo other than those got from
            % boards.xml
            switch buildInfo.MCU
                case 'cortex-m3'
                    buildInfo.Arch = 'sam';
                case 'cortex-m0plus'
                    buildInfo.Arch = 'samd';
                case 'cortex-m4'
                    buildInfo.Arch = 'mbed';
                case 'esp32'
                    buildInfo.Arch = 'esp32';
                otherwise
                    buildInfo.Arch = 'avr';
            end
            try
                if ismember(buildInfo.Board,{'ESP32-WROOM-DevKitV1','ESP32-WROOM-DevKitC'})
                    if ismac && ~exist(fullfile(arduinoio.IDERoot,"..","..","..","idepkgs","packages","esp32"),'dir')
                        matlabshared.hwsdk.internal.localizedError('MATLAB:arduinoio:general:thirdpartyLibNotInstalled');
                    elseif ~ismac && ~exist(fullfile(arduinoio.IDERoot,"portable","packages","esp32"),'dir') % win and linux
                        matlabshared.hwsdk.internal.localizedError('MATLAB:arduinoio:general:thirdpartyLibNotInstalled');
                    end
                end
            catch e
               throwAsCaller(e);
            end
            buildInfo = getProgrammer(obj, buildInfo); % set the Programmer field of buildInfo structure
            %Moved to arduino class to remove the sharedcomponent
            %dependency on Arduino IO support package
            % buildInfo.SPPKGPath = arduinoio.SPPKGRoot;
            buildInfo.SketchTemplate = fullfile(arduinoio.SharedArduinoRoot, 'target', 'ArduinoServer.ino');
            buildInfo.SketchFile = fullfile(buildInfo.TempDirPath, 'ArduinoServer.ino');
            [mheaders, libs] = areLibrariesAvailable(obj, buildInfo);
            if ~isempty(mheaders)
                matlabshared.hwsdk.internal.localizedError('MATLAB:arduinoio:general:addonLibraryNotInstalled', mheaders, strjoin(libs, ', '));
            end
        end
        
        
        
        function generateMacrosIncludeHeader(obj, buildInfo)
            % Generate Dynamic.h file to be compiled with other source code to
            % register the libraries
            filename = fullfile(buildInfo.TempDirPath, 'MacroIncludeIO.h');
            h = fopen(filename, 'w');
            c = onCleanup(@() fclose(h));
            
            contents = [];
            contents = ['#ifndef Macro_Include_h\n',...
                '#define Macro_Include_h\n'];
            
            if ismember(buildInfo.ConnectionType, [matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial, matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth])
                contents = [contents, '\n#define CUSTOM_SERIAL_COMPORTBAUD ', buildInfo.BaudRate, '\n',...
                    '#define CUSTOM_EXPECTED_FIRSTBYTE_SERIAL ', '0xAA', '\n'];
                % For Arduino Leonardo and Micro boards with BT the
                % Serial1 is available on Board to connect BT module and
                % Serial 0 is a CDC COM Port
                if (buildInfo.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth) && ismember(buildInfo.Board,{'Leonardo','Micro'})
                    contents = [contents, '#define BT_SERIAL1\n'];
                end
            elseif (buildInfo.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi)% 'wifi'
                contents = [contents, '\n#define _RTT_BAUDRATE_SERIAL0_ 9600\n'];
                switch buildInfo.Encryption
                    case matlabshared.hwsdk.internal.WiFiEncryptionTypeEnum.None
                        contents = [contents, '\n#define _RTT_WIFI_NONE 1\n'];
                    case matlabshared.hwsdk.internal.WiFiEncryptionTypeEnum.WPA
                        contents = [contents, '\n#define _RTT_WIFI_WPA 1\n'];
                    case matlabshared.hwsdk.internal.WiFiEncryptionTypeEnum.WEP
                        contents = [contents, '\n#define _RTT_WIFI_WEP 1\n'];
                end
                contents = [contents, '\n#define MW_PORT '    , num2str(buildInfo.TCPIPPort), '\n'];
                switch buildInfo.Encryption
                    case matlabshared.hwsdk.internal.WiFiEncryptionTypeEnum.None
                        contents = [contents, '\n#define _RTT_WIFI_SSID '    , buildInfo.SSID, '\n'];
                    case matlabshared.hwsdk.internal.WiFiEncryptionTypeEnum.WPA
                        contents = [contents, '\n#define _RTT_WIFI_SSID '    , buildInfo.SSID, '\n'];
                        contents = [contents, '\n#define _RTT_WIFI_WPA_PASSWORD ', buildInfo.Password, '\n'];
                    case matlabshared.hwsdk.internal.WiFiEncryptionTypeEnum.WEP
                        contents = [contents, '\n#define _RTT_WIFI_SSID ', buildInfo.SSID, '\n'];
                        contents = [contents, '\n#define _RTT_WIFI_KEY ', buildInfo.Key, '\n'];
                        contents = [contents, '\n#define _RTT_WIFI_KEY_INDEX ', buildInfo.KeyIndex, '\n'];
                end
                if ~isempty(buildInfo.StaticIP)
                    contents = [contents, '\n#define _RTT_DISABLE_Wifi_DHCP_ 1\n'];
                    output = strsplit(buildInfo.StaticIP, '.');
                    for index = 1:4
                        contents = [contents, '\n#define _RTT_WIFI_Local_IP', num2str(index), ' ', output{index}, '\n']; %#ok<AGROW>
                    end
                else
                    contents = [contents, '\n#define _RTT_DISABLE_Wifi_DHCP_ 0\n'];
                end
            elseif (buildInfo.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE)
                libs = char(strjoin(buildInfo.Libraries,','));
                contents = [contents, '\n#define BLEADVERTISINGNAME "',buildInfo.DeviceName, '"\n'];
				contents = [contents, '\n#define SERVICEUUID "',arduinoio.internal.ArduinoConstants.ServiceUUID,'"\n'];
				contents = [contents, '\n#define WRITECHARACTERISTICUUID "',arduinoio.internal.ArduinoConstants.WriteCharacteristicUUID,'"\n'];
				contents = [contents, '\n#define READCHARACTERISTICUUID "',arduinoio.internal.ArduinoConstants.ReadCharacteristicUUID,'"\n'];
                contents = [contents, '\n#define LIBNAMES ',' ','"',libs,'"','\n'];
            end
            contents = [contents,'#endif'];
            try
                fwrite(h, sprintf(contents));
            catch
                f2 = strrep(filename, '\', '\\');
                matlabshared.hwsdk.internal.localizedError('MATLAB:hwshared:general:noWritePermission');
            end
        end
        
        function generateMainSketch(obj, buildInfo)
            % Copy ArduinoServer.ino to tempdir
            [h, ~] = fopen(buildInfo.SketchTemplate);
            if h < 0
                matlabshared.hwsdk.internal.localizedError('MATLAB:hwshared:general:missingFile', buildInfo.SketchTemplate, 'ML_ARDUINO');
            else
                contents = transpose(fread(h, '*char'));
            end
            fclose(h);
            
            %             extraCode = '';
            %             libs = buildInfo.Libraries;
            %             for libCount = 1:length(libs)
            %                 headerFile = parent.getDefaultLibraryPropertyValue(libs{libCount}, 'ArduinoLibraryHeaderFiles');
            %                 if ~isempty(headerFile)
            %                     if ischar(headerFile)
            %                         headerFile = {headerFile};
            %                     end
            %                     for index = 1:length(headerFile)
            %                         theFile = headerFile{index};
            %                         theFile = strrep(theFile, '\', '/');
            %                         theFile = strsplit(theFile, '/');
            %                         extraCode = strcat(extraCode, ['#include "', theFile{2}, '"\n']);
            %                     end
            %                 end
            %             end
            %             contents = strrep(contents, '[additional_include]', extraCode);
            %
            %             switch buildInfo.ConnectionType
            %               case {matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial, matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth}
            %                 type = 0;
            %               case matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi
            %                 type = 1;
            %             end
            %             contents = strrep(contents, '[connection_type]', num2str(type));
            
            h = fopen(buildInfo.SketchFile, 'w');
            try
                fwrite(h, sprintf(contents));
            catch
                f2 = strrep(filename, '\', '\\');
                matlabshared.hwsdk.internal.localizedError('MATLAB:hwshared:general:noWritePermission');
            end
            fclose(h);
            % function to copy IoServer files from source
            arduinoio.internal.CopyServerToTemp(buildInfo.ConnectionType,buildInfo.TempDirPath);
        end
        
        function output = getAllLibraryBuildInfo(~, libs, propName)
            % Return combined values for given property name of all given
            % libraries for the given architecture
            output = cell(1, numel(libs));
            for libCount = 1:length(libs)
                theLib = libs{libCount};
                value = obj.getDefaultLibraryPropertyValue(theLib, propName);
                output{libCount} = value;
            end
            output = unique(output);
        end
        
        function [status, result] = uploadServer(~, buildInfo)
            if exist(fullfile(buildInfo.TempDirPath, 'MW'), 'dir')
                rmdir(fullfile(buildInfo.TempDirPath, 'MW'), 's');
            end
            if ismember(buildInfo.Board,{'ESP32-WROOM-DevKitV1','ESP32-WROOM-DevKitC'})
                % special case for ESP devices for Linux and Mac, build
                % first and then prompt user to press boot button, then upload,after
                % succcessful upload ask user to release boot button
                buildCmd = [buildInfo.Programmer, ' -v --board ', buildInfo.Package, ':', buildInfo.Arch, ':', buildInfo.BoardName];
                if ~isempty(buildInfo.CPU)
                    buildCmd = [buildCmd, ':cpu=', buildInfo.CPU];
                end
                buildCmd = [buildCmd, ' --verify ','"', fullfile(buildInfo.SketchFile),'"'];%Added quotes around sketchfile path to overcome error caused by tempdir not resolving space in filepath
                buildCmd = [buildCmd, ' --pref build.path=', '"',fullfile(buildInfo.TempDirPath, 'MW'),'"'];%Added quotes around sketchfile path to overcome error caused by tempdir not resolving space in filepath
                [status, result] = system(buildCmd);
                if ~status
                    %press boot button
%                     if ~ispc
                    arduinoio.internal.Utility.pressBootButtonDialog;
%                     end
                    % upload binary
                    % uploadCmd on win added as reference in comments - system('C:\ProgramData\MATLAB\SupportPackages\R2022a\aIDE\portable\packages\esp32\tools\esptool_py\3.0.0/esptool.exe --chip esp32 --port COM8 --baud 115200 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0xe000 C:\ProgramData\MATLAB\SupportPackages\R2022a\aIDE\portable\packages\esp32\hardware\esp32\1.0.6/tools/partitions/boot_app0.bin 0x1000 C:\ProgramData\MATLAB\SupportPackages\R2022a\aIDE\portable\packages\esp32\hardware\esp32\1.0.6/tools/sdk/bin/bootloader_qio_80m.bin 0x10000 C:\Users\aagrawal\AppData\Local\Temp\ArduinoServerESP32_DEVKITC\MW/ArduinoServer.ino.bin 0x8000 C:\Users\aagrawal\AppData\Local\Temp\ArduinoServerESP32_DEVKITC\MW/ArduinoServer.ino.partitions.bin');
                    if ismac
                        uploadCmd = strcat(fullfile(arduinoio.IDERoot,"..","..","..","idepkgs","packages","esp32","tools","esptool_py","3.0.0","esptool --chip esp32 --port")...
                            ," ",buildInfo.Port," --baud 115200 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0xe000"," ",...
                            fullfile(arduinoio.IDERoot,"..","..","..","idepkgs","packages","esp32","hardware","esp32","1.0.6","tools","partitions","boot_app0.bin 0x1000"),...
                            " ",fullfile(arduinoio.IDERoot,"..","..","..","idepkgs","packages","esp32","hardware","esp32","1.0.6","tools","sdk","bin","bootloader_qio_80m.bin 0x10000"),...
                            " ",fullfile(buildInfo.TempDirPath,"MW","ArduinoServer.ino.bin 0x8000")," ", fullfile(buildInfo.TempDirPath, "MW","ArduinoServer.ino.partitions.bin"));
                     elseif ispc % windows
                        uploadCmd = strcat("""",fullfile(arduinoio.IDERoot,"portable","packages","esp32","tools","esptool_py","3.0.0","esptool.exe"), """"," --chip esp32 --port"...
                            ," ",buildInfo.Port," --baud 115200 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0xe000"," ",...
                            """",fullfile(arduinoio.IDERoot,"portable","packages","esp32","hardware","esp32","1.0.6","tools","partitions","boot_app0.bin"),"""", " ", "0x1000",...
                            " ","""",fullfile(arduinoio.IDERoot, "portable","packages","esp32","hardware","esp32","1.0.6","tools","sdk","bin","bootloader_qio_80m.bin"),"""", " ", "0x10000",...
                            " ","""",fullfile(buildInfo.TempDirPath,"MW","ArduinoServer.ino.bin"), """"," ","0x8000"," ", """",fullfile(buildInfo.TempDirPath, "MW","ArduinoServer.ino.partitions.bin"),"""");
                    else % Linux
                        uploadCmd = strcat(fullfile(arduinoio.IDERoot,"portable","packages","esp32","tools","esptool_py","3.0.0","esptool.exe --chip esp32 --port")...
                            ," ",buildInfo.Port," --baud 115200 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size detect 0xe000"," ",...
                            fullfile(arduinoio.IDERoot,"portable","packages","esp32","hardware","esp32","1.0.6","tools","partitions","boot_app0.bin 0x1000"),...
                            " ",fullfile(arduinoio.IDERoot, "portable","packages","esp32","hardware","esp32","1.0.6","tools","sdk","bin","bootloader_qio_80m.bin 0x10000"),...
                            " ",fullfile(buildInfo.TempDirPath,"MW","ArduinoServer.ino.bin 0x8000")," ", fullfile(buildInfo.TempDirPath, "MW","ArduinoServer.ino.partitions.bin"));
                    end

                    %upload
                    [status,result] = system(uploadCmd);

                    if ~status %&& ~ispc
                    % release button
                        arduinoio.internal.Utility.releaseBootButtonDialog;
                    end

                end
            else
                uploadCmd = ['"', buildInfo.Programmer,'"', ' -v --board ', buildInfo.Package, ':', buildInfo.Arch, ':', buildInfo.BoardName];
                if ~isempty(buildInfo.CPU)
                    uploadCmd = [uploadCmd, ':cpu=', buildInfo.CPU];
                end
                uploadCmd = [uploadCmd, ' --upload ', '"',fullfile(buildInfo.SketchFile),'"']; %Added quotes around sketchfile path to overcome error caused by tempdir not resolving space in filepath
                uploadCmd = [uploadCmd, ' --port ', buildInfo.Port];
                uploadCmd = [uploadCmd, ' --pref build.path=', '"',fullfile(buildInfo.TempDirPath, 'MW'),'"'];  %Added quotes around sketchfile path to overcome error caused by tempdir not resolving space in filepath
                [status, result] = system(uploadCmd);
            end
        end


        
        function validateServerSize(~, buildInfo)
            % Check whether the compiled server fits in the flash memory
            % available
            if strcmp(buildInfo.Arch, 'avr')
                executableFile = fullfile(buildInfo.TempDirPath, 'MW', 'ArduinoServer.ino.hex');
                sizer = fullfile(buildInfo.IDEPath, 'hardware', 'tools', 'avr', 'bin', 'avr-size');
                [~, result] = system([sizer, ' ', executableFile]);
                fields = textscan(result, '%s', 'delimiter', newline); fields = fields{1}{end};
                fields = textscan(fields, '%s');
                currentSize = fields{1}(2);
            elseif ismember(buildInfo.Arch,{'sam','samd','mbed','esp32'})
                % SAM/SAMD/MBED/Xtensa boards - Due, MKRXXXX (MKR1010, MKRZero, MKR1000), Nano33IoT, Nano33BLE, ESP32 etc.
                if ispc
                    % On Windows: use the 'dir' command to list out details of the
                    % ArduinoServer.ino.bin file
                    sizer = 'dir';
                else
                    % On Linux/Mac: use the 'ls -al' command to list out
                    % details of the ArduinoServer.ino.bin file
                    sizer = 'ls -al';
                end
                executableFile = fullfile(buildInfo.TempDirPath, 'MW', 'ArduinoServer.ino.bin');
                [~, result] = system([sizer, ' ', executableFile]);
                % Retrieve all individual strings from 'result' separated by blank
                % spaces and populate them in the 'fields' cell array
                fields = textscan(result,'%s');
                if ispc
                    % On windows, the 'fields' contains the size of the bin
                    % file which is listed just before the name of the file
                    matchingField = cellfun(@(x)strcmpi(x, 'ArduinoServer.ino.bin'), fields, 'UniformOutput', false);
                    % index of the cell containing the filesize as a string
                    matchingFieldIndex = find(double(matchingField{1}) == 1) - 1;
                    % retrieve the filesize from the index number
                    % matchingFieldIndex of the fields cell array
                    currentSize = fields{1}(matchingFieldIndex);
                else
                    % On Linux/Mac, the fifth entry in the 'fields' cell
                    % array contains the filesize
                    currentSize = fields{1}(5);
                end
            end
            if str2double(currentSize) > buildInfo.MemorySize
                matlabshared.hwsdk.internal.localizedError('MATLAB:arduinoio:general:outOfFlashMemory', buildInfo.Board, matlabshared.hwsdk.internal.renderCellArrayOfCharVectorsToCharVector(buildInfo.Libraries, ', '));
            end
        end
        
        function [ArefMacroValue,ArefVoltage] = getAnalogReferenceMacro(~,buildInfo)
            %Return arduino specified macro values to set analog reference, as
            %per the analog reference voltage and mode specified by the
            %user. The macro values are defined in Arduino's library file
            %wiring_analog.h
            
            if strcmpi(buildInfo.AnalogReferenceMode,'external')
                %analog reference macro values for external mode
                if ismember(buildInfo.Board,{'MKR1000','MKR1010','MKRZero','Nano33IoT'})
                    ArefMacroValue = '2';
                else
                    ArefMacroValue = '0';
                end
            elseif strcmpi(buildInfo.AnalogReferenceMode,'internal')
                %analog reference macro values for internal mode
                
                if (buildInfo.AnalogReference == 3.3 || buildInfo.AnalogReference == 5.0)
                    switch buildInfo.Board
                        case {'Uno','Nano3','ProMini328_3V','ProMini328_5V','DigitalSandbox','Mega2560','MegaADK','Leonardo','Micro'}
                            ArefMacroValue = '1';
                        case {'MKR1000','MKR1010','MKRZero','Due','Nano33IoT','Nano33BLE','ESP32-WROOM-DevKitV1','ESP32-WROOM-DevKitC'}
                            % Due, MKRs, Nano33IoT Nano33BLE and ESP32 support internal default reference voltage
                            % of 3.3 volt
                            ArefMacroValue = '0';
                    end
                else
                    switch buildInfo.Board
                        case {'Uno','Nano3','ProMini328_3V','ProMini328_5V','DigitalSandbox','Leonardo','Micro'}
                            ArefMacroValue = '3';
                        case {'Mega2560','MegaADK'}
                            if buildInfo.AnalogReference == arduinoio.internal.ArduinoConstants.InternalAnalogReferenceAVR{1}
                                ArefMacroValue = '2';
                            elseif buildInfo.AnalogReference == arduinoio.internal.ArduinoConstants.InternalAnalogReferenceAVR{2}
                                ArefMacroValue = '3';
                            end
                        case {'MKR1000','MKR1010','MKRZero','Nano33IoT'}
                            if buildInfo.AnalogReference == arduinoio.internal.ArduinoConstants.InternalAnalogReferenceSAMD{1}
                                ArefMacroValue = '3';
                            elseif buildInfo.AnalogReference == arduinoio.internal.ArduinoConstants.InternalAnalogReferenceSAMD{2}
                                ArefMacroValue = '4';
                            elseif buildInfo.AnalogReference == arduinoio.internal.ArduinoConstants.InternalAnalogReferenceSAMD{3}
                                ArefMacroValue = '5';
                            end
                    end
                end
            elseif (isempty(buildInfo.AnalogReferenceMode) && isempty(buildInfo.AnalogReference))
                % If a server doesn't already exist on the arduino board,
                % and user hasn't provided the analog reference values
                % initialize server with default analog reference values.
                switch buildInfo.Board
                    case {'DigitalSandbox', 'ProMini328_3V'}
                        buildInfo.AnalogReference = 3.3;
                        ArefMacroValue = '1';
                    case {'Due','MKR1000','MKR1010','MKRZero','Nano33IoT','Nano33BLE','ESP32-WROOM-DevKitV1','ESP32-WROOM-DevKitC'}
                        % Due,MKRs, Nano33IoT, Nano33BLE, and ESP32 support internal default reference voltage
                        % of 3.3 volts
                        buildInfo.AnalogReference = 3.3;
                        ArefMacroValue = '0';
                    case {'Uno','Nano3','ProMini328_5V','Mega2560','MegaADK','Leonardo','Micro'}
                        buildInfo.AnalogReference = 5.0;
                        ArefMacroValue = '1';
                end
            end            
            ArefVoltage = buildInfo.AnalogReference;
        end
    end
    
    methods(Access = {?ioservertest.hostIOServer.hostIOServerUtility})
        % Granting access to the hostIOServerUtility class for enabling
        % hostIOServer mock for establishing communication with an arduino
        % object on a pseudo terminal
        function generateAddonLibrariesHeader(obj, buildInfo)
            % Generate Dynamic.h file to be compiled with other source code to add the Addon libraries
            filename = fullfile(buildInfo.TempDirPath, 'addOnLibraries.h');
            h = fopen(filename, 'w');
            c = onCleanup(@() fclose(h));
            contents = [];
            contents = '#include "Arduino.h"\n';
            contents = [contents '#include "LibraryBase.h"\n'];
            contents = [contents,'#include "MWArduinoClass.h"\n'];
            if strcmpi(buildInfo.Board,'Uno')
                % Use this macro to determine how much memory to allocate
                % for Adafruit motor shields with stacking.
                contents = [contents,'#define MW_UNO_SHIELDS 1','\n'];
            end
            for libCount = 1:length(buildInfo.Libraries)
                % Check if specified library is using the IOServer's addon infrastructure, include the
                % headerFile for the same
                if ~ismember(buildInfo.Libraries(libCount),arduinoio.internal.ArduinoConstants.ShippingLibraries)
                    headerFile = arduinoio.internal.getDefaultLibraryPropertyValue(buildInfo.Libraries{libCount}, 'CppHeaderFile');
                    headerFile = strrep(headerFile, '\', '\\');
                    contents = strcat(contents, ['#include "', headerFile, '"\n']);
                end
            end
            
            contents = [contents,'MWArduinoClass hwObject;\n'];
            
            for libCount = 1:length(buildInfo.Libraries)
                if ~ismember(buildInfo.Libraries(libCount),arduinoio.internal.ArduinoConstants.ShippingLibraries)
                    className = arduinoio.internal.getDefaultLibraryPropertyValue(buildInfo.Libraries{libCount}, 'CppClassName');
                    contents = strcat(contents, [className, ' a', className, '(hwObject); // ID = ', num2str(libCount-1), '\n']);
                end
            end
            try
                fwrite(h, sprintf(contents));
            catch
                f2 = strrep(filename, '\', '\\');
                matlabshared.hwsdk.internal.localizedError('MATLAB:hwshared:general:noWritePermission');
            end
        end
        
        function generatePeripheralIncludeHeader(obj, buildInfo)
            % Generate Dynamic.h file to be compiled with other source code to
            % register the libraries
            if ~exist(fullfile(buildInfo.TempDirPath), 'dir')
                try
                    mkdir(fullfile(buildInfo.TempDirPath));
                catch
                    matlabshared.hwsdk.internal.localizedError('MATLAB:hwshared:general:noWritePermission');
                end
            end
            
            filename = fullfile(buildInfo.TempDirPath, 'peripheralIncludes.h');
            h = fopen(filename, 'w');
            c = onCleanup(@() fclose(h));
            
            for numBoard = 1:length(obj.BoardInfo.Boards)
                if strcmpi(obj.BoardInfo.Boards(numBoard).BoardName,buildInfo.BoardName)
                    break;
                end
            end
            if ismember(buildInfo.Board,{'Due','Nano33BLE'})
                AvailableI2CBusIDs = 2;
            else
                AvailableI2CBusIDs = 1;
            end
            
            if (ismember(buildInfo.Board,{'Mega2560','MegaADK','Due'}))
                % IO_SCI_MODULES_MAX is used to identify the
                % boards as well as maximum number of modules which we can
                % use.
                numModulesSCI = num2str(3);
            elseif (ismember(buildInfo.Board,{'MKR1000','MKR1010','MKRZero','Leonardo','Micro','Nano33IoT','Nano33BLE'}))
                numModulesSCI = num2str(1);
            elseif ismember(buildInfo.Board,{'ESP32-WROOM-DevKitV1','ESP32-WROOM-DevKitC'})
                numModulesSCI = num2str(2);
            else
                numModulesSCI = num2str(0);
            end
            
            if strcmpi(buildInfo.Board,'MKRZero')
                %highest digital pin index on MKRZero is D32 which is a
                %digital pin therefore, using that for initializing
                %peripheral handle map
                numPinsDigital = num2str(obj.BoardInfo.Boards(numBoard).PinsDigital(length(obj.BoardInfo.Boards(numBoard).PinsDigital))+1);
            end
            % since, peripheraltohandle map maintains a map with assumption
            % that pins are indexed according to the number so first
            % digital pin is assumed to be indexed 0 and so on. Therefore,
            % making IO_DIGITAlIO_MODULES_MAX = index of highest digital pin
            numPinsAnalog = num2str(obj.BoardInfo.Boards(numBoard).PinsAnalog(length(obj.BoardInfo.Boards(numBoard).PinsAnalog))+1);
            numPinsPWM = num2str(obj.BoardInfo.Boards(numBoard).PinsPWM(length(obj.BoardInfo.Boards(numBoard).PinsPWM))+1);
            contents = ['#ifndef PERIPHERALINCLUDES_H_\n',...
                '#define PERIPHERALINCLUDES_H_\n\n',...
                '#define INCLUDE_FUNCTION_MACROS\n',...
                '#define MAX_PACKET_SIZE ',num2str(buildInfo.MAXPacketSize+16),'\n',... % 15 bytes is the IOServer payload overhead
                '#define IO_CUSTOM_ENABLE 1\n',...
                '#define IO_STANDARD_ENABLE 1\n',...
                '#if IO_STANDARD_ENABLE\n \n',...
                '#define IO_STANDARD_DIGITALIO 1\n',...
                '#define IO_SPI_MODULES_MAX ','1','\n'... % Arduino hasn't come up with multiple SPI buses yet.
                '#define IO_CS_BY_SPI_DRIVER ','1','\n'... % Manage CS Pin in SVD for Arduino
                '#define IO_I2C_MODULES_MAX ',num2str(AvailableI2CBusIDs),'\n'...
                '#define IO_STANDARD_ANALOGINPUT 1\n',...
                '#define IO_ANALOGINPUT_MODULES_MAX ',numPinsAnalog,'\n',...
                '#define IO_STANDARD_PWM 1\n',...
                '#define IO_PWM_MODULES_MAX ',numPinsPWM,'\n'...
                '#define SOFT_REALTIME_SCHEDULING \n']; % Arduino has soft real time implementation for streaming.
            if strcmpi(buildInfo.Board,'MKRZero')
                contents = [contents,'#define IO_DIGITALIO_MODULES_MAX ',numPinsDigital,'\n'];
            else
                contents = [contents,'#define IO_DIGITALIO_MODULES_MAX ',numPinsAnalog,'\n']; % All Analog Pins can also be used as digital pin and need to assign peripheral handle map of size of index of highest DigitalPin,
            end

            % check for Add-on Libraries to enable ADD_ON flag
            if any(~ismember(buildInfo.Libraries,arduinoio.internal.ArduinoConstants.ShippingLibraries))
                contents = strcat(contents,'#define ADD_ON 1\n');
            end
            libs = char(strjoin(buildInfo.Libraries,','));
            for libCount = 1:length(buildInfo.Libraries)
                if any(ismember(arduinoio.internal.ArduinoConstants.ShippingLibraries,buildInfo.Libraries(libCount)))
                    switch char(buildInfo.Libraries(libCount))
                        case 'I2C'
                            contents = strcat(contents,'#define IO_STANDARD_I2C 1\n');
                        case 'SPI'
                            contents = strcat(contents,'#define IO_STANDARD_SPI 1\n');
                        case 'Servo'
                            contents = strcat(contents,'#define IO_CUSTOM_SERVO 1\n');
                        case 'RotaryEncoder'
                            if ismember(buildInfo.Board,arduinoio.internal.ArduinoConstants.RotaryEncoderSupportedBoards)
                                contents = strcat(contents,'#define IO_CUSTOM_ROTARYENCODER 1\n');
                            end
                        case 'Ultrasonic'
                            contents = strcat(contents,'#define IO_CUSTOM_ULTRASONIC 1\n');
                        case 'ShiftRegister'
                            contents = strcat(contents,'#define IO_CUSTOM_SHIFTREGISTER 1\n');
                        case 'Serial'
                            % IO_STANDARD_SCI should only be included where
                            % extra onboard UART is available.This will also
                            % ensure Serial related files are not flashed on
                            % low memory boards like UNO.
                            if ismember(buildInfo.Board,arduinoio.internal.ArduinoConstants.SerialLibrarySupportBoards)
                                contents = strcat(contents,'#define IO_STANDARD_SCI 1\n');
                                contents = [contents,'#define IO_SCI_MODULES_MAX ',numModulesSCI,'\n'];%#ok<AGROW>
                            end
                    end
                end
            end

            contents = [contents,'#endif\n'];%endif for #if IO_STANDARD_ENABLE',...
            
            % LTC_BAREMETAL_HARDWARE macro removes function calls from IO_wrapper which are not used by Arduino IO
            if ~(isfield(buildInfo,'AdvancedServer'))
                contents =  strcat(contents,'#define LTC_BAREMETAL_HARDWARE\n');
            end
            
             if(buildInfo.ConnectionType == matlabshared.hwsdk.internal.ConnectionTypeEnum.BLE)
	         contents = [contents, '#define MW_IOSERVER_FIXED_FRAME_COMMUNICATION','\n'];
		 contents = [contents, '#define MAX_PACKET_SIZE ',num2str(512),'\n'];
             end

            trace = num2str(0);
            if buildInfo.TraceOn
                if (isfield(buildInfo,'AdvancedServer'))
                    contents = [contents,'\n#define DEBUG_FLAG 1\n'];
                else
                    contents = [contents,'\n#define DEBUG_FLAG 2\n'];
                end
                trace = num2str(1);
            end
            % add ServerInfo to the IOServer
            contents = [char(contents), '\n#define BOARDNAME ','"',buildInfo.Board,'"','\n',...
                '#define CUSTOMDATA "BAUDRATE ',' ',buildInfo.BaudRate,',','Trace ',' ',trace];
            
            if isfield(buildInfo,'AnalogReference')
                [ArefMacroValue,ArefVoltage]=getAnalogReferenceMacro(obj,buildInfo);
                
                %append analog reference macro value and analog reference voltage with CUSTOMDATA
                contents = [char(contents), ',','AREFMACRO ',' ',ArefMacroValue,',','AREFVOLT ',' ',num2str(ArefVoltage),'"','\n'];
                
                %Value assigned to MW_AREF is passed to analogReference()
                %function at server side
                contents=  [char(contents),'#define MW_AREF ',ArefMacroValue,'\n'];
            else
                contents = [char(contents),'"','\n'];
            end
            contents = [char(contents),'#define BOARD_IO_VERSION ',' ','"',buildInfo.HWSPPKGVersion,'"','\n',...
                '#define LIBNAMES ',' ','"',libs,'"','\n'];
            % Sample ServerInfo in PeripheralIncludes.h
            % #define BOARDNAME "Uno"
            % #define CUSTOMDATA "BAUDRATE  115200,Trace  0"
            % #define BOARD_IO_VERSION  "19.1.0"
            % #define LIBNAMES  "I2C,SPI,Servo"
            
            contents = [contents,'\n#define USE_BIT_FOR_HANDLE 1\n'];   % Saving memory on Arduino (use Bit instead of Byte for Handle)
            contents = [contents, '\n#define CHECKSUM_ENABLE 1\n\n#endif\n']; %endif for '#ifndef PERIPHERALINCLUDES_H_\n',...
            try
                fwrite(h, sprintf(contents));
            catch
                f2 = strrep(filename, '\', '\\');
                matlabshared.hwsdk.internal.localizedError('MATLAB:hwshared:general:noWritePermission');
            end
        end
    end
end

% LocalWords:  ARDUINOIO avr arduinoio Arduino's FTDI vid tty symlink readlink
% LocalWords:  dev serialportlist btspp ICT Bluetooth bluetooth BT nslookup ip pid
% LocalWords:  CPATH DYLD MKR stk getsync SPI sam samd ino addon hwshared WIFI
% LocalWords:  TRACEON BAUDRATE wifi WPA WEP KEYINDEX Uno Adafruit UNO LD
