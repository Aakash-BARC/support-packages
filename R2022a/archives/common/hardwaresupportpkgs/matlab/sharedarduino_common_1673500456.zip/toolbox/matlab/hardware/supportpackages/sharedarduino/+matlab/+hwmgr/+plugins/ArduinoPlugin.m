classdef ArduinoPlugin < matlab.hwmgr.internal.plugins.PluginBase
    % Arduino Explorer app device plugin

    % Copyright 2021 Mathworks Inc.

    methods
        % These are the interface methods that need to be implemented for
        % the Hardware Manager device plugin.

        function deviceProviders = getDeviceProvider(~)
            deviceProviders = matlab.hwmgr.providers.ArduinoDeviceProvider();
        end

        function appletProviders = getAppletProvider(~)
            % Return all the applet providers defined for Arduino Explorer
            % app.
            appletProviders = matlab.hwmgr.providers.ArduinoAppletProvider();
        end

    end

end