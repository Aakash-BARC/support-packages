classdef(Abstract) accessor < handle

    %   Copyright 2018 The MathWorks, Inc.

    % This is an empty class. Created to provide access to some methods
    % inside HWSDK to utility. All utility files for target hardware should
    % inherit from this
end