classdef ArduinoAppletProvider < matlab.hwmgr.internal.AppletProviderBase

    % ARDUINOAPPLETPROVIDER implements the Hardware Manager interface for
    % providing the applet to framework.

    % Copyright 2021 The MathWorks, Inc.

    methods

        function appletList = getApplets(~)
            % This is required by Hardware Manager for future work.
            appletList = {'arduinoioapplet.ArduinoExplorerApplet'};
        end

        function appletList = getAppletsByDevice(~, ~)
            % Returns the list of support apps for the Hardware Manager Device
            appletList = {'arduinoioapplet.ArduinoExplorerApplet'};
        end
    end

end

% LocalWords:  arduinoioapplet
