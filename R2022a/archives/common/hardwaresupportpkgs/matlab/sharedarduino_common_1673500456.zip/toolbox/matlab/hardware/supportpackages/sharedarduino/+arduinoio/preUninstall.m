function preUninstall()
%PREUNINSTALL Uninstall the Arduino IDE files from the IDERoot
%  after MATLAB Support Package for Arduino Hardware or
%  Simulink Support Package for Arduino Hardware uninstaller
%  is initiated.
%
%  Copyright 2021 The MathWorks, Inc.

try
    % NOTE: Do not remove the exclude pragma.
    % This is responsible for suppressing the
    % compiler warnings associated with
    % matlabshared.supportpkg.getInstalled
    installedSupportPackages = matlabshared.supportpkg.getInstalled; %#exclude matlabshared.supportpkg.getInstalled
    installedSupportPackages = {installedSupportPackages.Name};
    % Remove Arduino IDE files from the IDERoot if any one of
    % the SPPKGs is installed on windows only
    if ispc && ~all(ismember({'Simulink Support Package for Arduino Hardware','MATLAB Support Package for Arduino Hardware'}, installedSupportPackages))
        pathName = fullfile(matlabshared.supportpkg.getSupportPackageRoot, 'aIDE');
        if ~isempty(pathName)
            [~, ~] = rmdir(pathName, 's');
        end
    end

    % Uninstall UI for 3P software
    if ismember('Simulink Support Package for Arduino Hardware', installedSupportPackages)

        spkgRootDir = codertarget.arduinobase.internal.getSpPkgRootDir;
        osterMillerFolder = 'ostermillercircularbuffer.instrset';
        osterMillerVersion = '1.08.02';
        
        % Find the location of installed 3P tools with hardware setup screens
        if ispref('Mathworks_Arduino_Simulink','overridePathFor3PInstall') && ...
                ~isempty(getpref('Mathworks_Arduino_Simulink','overridePathFor3PInstall'))
            tpInstallPath = fullfile(getpref('Mathworks_Arduino_Simulink','overridePathFor3PInstall'), '3P.instrset');
        else
            spkgFolder = fileparts(fileparts(fileparts(fileparts(spkgRootDir))));
            tpInstallPath = fullfile(spkgFolder, '3P.instrset');
        end
        
        tpFolder = '';
        if ispref('Mathworks_Arduino_Simulink','Ostermiller_Circular_Buffer') && ...
                ~isempty(getpref('Mathworks_Arduino_Simulink','Ostermiller_Circular_Buffer'))
            prefFolder = getpref('Mathworks_Arduino_Simulink','Ostermiller_Circular_Buffer');
            if startsWith(prefFolder, tpInstallPath)
                tpFolder = prefFolder;
            else
                % user may have registered 3P tools from different path check if
                % they have 3P tool installed at the same path
                otherpathFolder = fullfile(tpInstallPath, osterMillerFolder, ...
                    ['ostermillerutils-', osterMillerVersion]);
                if isfolder(otherpathFolder)
                    tpFolder = otherpathFolder;
                end
            end
        else
            % 3P tools installed and registered from different user and 
            % uninstalling the 3P tools with different user in same system
            otheruserFolder = fullfile(tpInstallPath, osterMillerFolder, ...
                ['ostermillerutils-', osterMillerVersion]);
            if isfolder(otheruserFolder)
                tpFolder = otheruserFolder;
            end            
        end

        tpInstalledToolCount = 0;
        tpFolders = {};
        tpName = {};
        tpPref = {};
        if ~isempty(tpFolder)
            tpInstalledToolCount = tpInstalledToolCount + 1;
            tpFolders{tpInstalledToolCount} = tpFolder;
            tpName{tpInstalledToolCount} = ['Ostermiller Circular Buffer ' osterMillerVersion];
            tpPref{tpInstalledToolCount} = 'Ostermiller_Circular_Buffer';
        end
        
        % If any of the third-party tools were installed ask user if he wants to
        % uninstall the third-party tools with a question dialog of 60 second
        % timeout and default option as 'No'
        if tpInstalledToolCount > 0
            uninstallMessage = {...
                char(strcat("\fontsize{9}",message('arduino:hwsetup:UninstallMessage1',strrep(tpInstallPath,'\','\\')).string))};
            for count = 1 : length(tpName)
                uninstallMessage{end+1} = ['   ' num2str(count) '. ' tpName{count}]; %#ok<AGROW>
            end
            uninstallMessage{end+1} = '';
            uninstallMessage{end+1} = char(message('arduino:hwsetup:UninstallMessage2').string);
            uninstallMessage{end+1} = char(message('arduino:hwsetup:UninstallMessage3').string);
            uninstallTitle = message('arduino:hwsetup:UninstallTitle').string;
            yesOption = message('arduino:hwsetup:Yes').string;
            noOption = message('arduino:hwsetup:No').string;
            opts.Interpreter = 'tex';
            opts.Default = noOption;
            t = timer('StartDelay',60,'TimerFcn',@(~,~)delete(findall(groot,'WindowStyle','modal')));
            start(t);
            answer = questdlg(uninstallMessage, uninstallTitle, yesOption, noOption, opts);
            stop(t);
            delete(t);
            % If user press yes button, delete all the third-party tools and
            % download folder
            if ~isempty(answer) && isequal(answer, yesOption)
                if (exist(tpInstallPath, 'dir') == 7)
                    if (exist(fullfile(tpInstallPath, 'Downloads'), 'dir') == 7)
                        rmdir(fullfile(tpInstallPath, 'Downloads'), 's');
                    end
                    for count = 1 : length(tpFolders)
                        if (exist(tpFolders{count}, 'dir') == 7)
                            rmdir(tpFolders{count}, 's');
                            if ispref('Mathworks_Arduino_Simulink', tpPref{count})
                                rmpref('Mathworks_Arduino_Simulink', tpPref{count});
                            end
                        end
                    end
                end
            end
        end
        % NOTE: Do not remove the exclude pragma.
        % This is responsible for suppressing the
        % compiler warnings associated with
        % codertarget.target.getThirdPartyToolsRegistryFolder
        thirdPartyFolder = codertarget.target.getThirdPartyToolsRegistryFolder(spkgRootDir); %#exclude codertarget.target.getThirdPartyToolsRegistryFolder
        % Delete the third party registration file created by hardware setup
        % screens
        if (exist(thirdPartyFolder, 'dir') == 7)
            rmdir(thirdPartyFolder, 's');
        end
    end

catch
    % Do not error
end
end