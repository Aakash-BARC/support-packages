classdef ArduinoDeviceProvider < matlab.hwmgr.internal.DeviceProviderBase
    % ARDUINODEVICEPROVIDER implements the Hardware manager interface for
    % providing the device params descriptor

    % Copyright 2021 The MathWorks, Inc

    properties(Access=private)
        % List of already enumerated device cards
        EnumeratedDeviceCards
    end

    properties(Constant)
        % Support Package base code for the app
        AppletPluginClass = "arduinoioapplet.ArduinoExplorerApplet"
        ArduinoIOBaseCode = "ML_ARDUINO"
    end

    %% Functions used by Hardware Manager to populate enumerated devices list and non-enumerated device gallery
    methods
        function devices = getDevices(obj)
            % Function that returns the list of all enumerated Arduino
            % devices

            devices = obj.EnumeratedDeviceCards;
        end

        function allDescriptors = getDeviceParamDescriptors(obj)
            % Function that returns the descriptors for non-enumerated
            % Arduino devices in the "Add-device" gallery

            % First get the list of all enumerated devices. This will help
            % check for duplicate cards in the Add-device workflow.
            wifiDeviceCards = createWiFiDeviceCards(obj);
            obj.EnumeratedDeviceCards = [wifiDeviceCards]; %#ok<NBRAK>
            % Bluetooth is supported only in Windows and mac
            if ispc || ismac
                bluetoothDeviceCards = createBluetoothDeviceCards(obj);
                obj.EnumeratedDeviceCards = [obj.EnumeratedDeviceCards bluetoothDeviceCards];
            end
            usbDeviceCards = createUSBDeviceCards(obj);
            obj.EnumeratedDeviceCards = [obj.EnumeratedDeviceCards usbDeviceCards];

            % Initialize device descriptors for non-enumerable devices
            deviceDescriptorUSB  = arduinoioapplet.descriptors.USBDeviceDescriptor(getString(message("MATLAB:arduinoio:arduinoapp:addUSBDevice")));
            allDescriptors = [deviceDescriptorUSB]; %#ok<NBRAK>

            % Bluetooth is supported only in Windows and mac
            if ispc || ismac
                deviceDescriptorBluetooth  = arduinoioapplet.descriptors.BluetoothDeviceDescriptor(getString(message("MATLAB:arduinoio:arduinoapp:addBTDevice")));
                allDescriptors = [allDescriptors deviceDescriptorBluetooth];
            end

            deviceDescriptorWiFi  = arduinoioapplet.descriptors.WiFiDeviceDescriptor(getString(message("MATLAB:arduinoio:arduinoapp:addWiFiDevice")));
            allDescriptors = [allDescriptors deviceDescriptorWiFi];
        end
    end

    %% Internal functions for creating enumerated device cards
    methods(Access = private)

        function usbDeviceCards = createUSBDeviceCards(obj)
            % Function to create device cards for USB enumerated Arduino

            usbDeviceCards = [];
            [arduinoList, status] = arduinoio.internal.ArduinoHWInfo();

            if ~status && ~isempty(arduinoList)
                boardInfoInstance = arduinoio.internal.BoardInfo.getInstance();

                % Parse through each saved Arduino connection info to get more board info
                for index = 1:length(arduinoList)
                    % Get Additional board info
                    [name, ~] = getAdditionalBoardInfo(obj,arduinoList(index),boardInfoInstance);
                    friendlyName = arduinoioapplet.internal.Utility.getFriendlyName(name);
                    deviceAddress = arduinoList(index).PortNumber;

                    % Add information about the device to the CustomData field
                    customDeviceData.Board = name;
                    customDeviceData.Address = deviceAddress;
                    customDeviceData.WiFiPort = [];
                    customDeviceData.ConnectionType = matlabshared.hwsdk.internal.ConnectionTypeEnum.Serial;
                    customDeviceData.SerialNumber = arduinoList(index).SerialNumber;
                    customDeviceData.Manufacturer = arduinoList(index).Manufacturer;
                    customDeviceData.VID = arduinoList(index).VendorID;
                    customDeviceData.PID = arduinoList(index).ProductID;
                    deviceCardDisplayInfo = {getString(message("MATLAB:arduinoio:arduinoapp:boardLabel")),name;...
                        getString(message("MATLAB:arduinoio:arduinoapp:connectionLabel")),getString(message("MATLAB:arduinoio:arduinoapp:usbLabel"));...
                        getString(message("MATLAB:arduinoio:arduinoapp:portLabel")), deviceAddress};

                    % Create the HWMgr device object
                    device = matlab.hwmgr.internal.Device(friendlyName);
                    device.DeviceCardDisplayInfo = deviceCardDisplayInfo;
                    device.IconPath = obj.getDeviceIconPath(name);
                    device.VendorName = "Arduino";
                    device.DeviceAppletData = matlab.hwmgr.internal.data.DataFactory.createDeviceAppletData(...
                        obj.AppletPluginClass,obj.ArduinoIOBaseCode);
                    device.CustomData = customDeviceData;

                    % Append device to list
                    usbDeviceCards = [usbDeviceCards device];
                end
            end
        end

        function bluetoothDeviceCards = createBluetoothDeviceCards(obj)
            % Function to create device cards for Bluetooth/BLE enumerated Arduino

            bluetoothDeviceCards = [];
            % Return if there are no saved Arduino Bluetooth & BLE connection info
            if ~ispref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.BluetoothPrefName) && ...
                    ~ispref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.BLEPrefName)
                return;
            end

            % Get device cards from saved BT and BLE prefs
            bluetoothDeviceCards = [bluetoothDeviceCards getBluetoothDeviceCards(obj)];
            bluetoothDeviceCards = [bluetoothDeviceCards getBLEDeviceCards(obj)];
        end

        function wifiDeviceCards = createWiFiDeviceCards(obj)
            % Function to create device cards for WiFi enumerated Arduino

            wifiDeviceCards = [];
            % Return if there are no saved Arduino Wifi connection info
            if(~ispref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.WiFiPrefName))
                return;
            end

            % Get WiFi addresses from saved MATLAB preference
            wifiPref = getpref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.WiFiPrefName);
            addressList = keys(wifiPref);
            boardList = values(wifiPref);

            % Create ping command to test saved IP Addresses
            if ispc
                pingCommand = "ping -n 3 -w 5";
            else
                pingCommand = "ping -c 3 -t 5";
            end

            if ~isempty(addressList)
                % Parse through each saved Arduino connection info to get more board info
                for index = 1:length(addressList)
                    % Get IPAddress and TCP/IP Port
                    addressPortPair = addressList{index};
                    deviceAddress = strsplit(addressPortPair,":");
                    port = deviceAddress{2};
                    deviceAddress = deviceAddress{1};

                    % Skip if device card already exists. Since these are
                    % populated from MATLAB prefs, there is a possibility
                    % that the user might have already added the device
                    % manually using Add-device workflow.
                    if obj.deviceExists(deviceAddress,port)
                        continue;
                    end

                    cmd = sprintf("%s %s",pingCommand,deviceAddress);

                    % Ping the IP address 3 times with a timeout of 5ms
                    [status,~] = system(cmd);

                    % Proceed to next IP Address if the current one is inactive
                    if status
                        continue;
                    end

                    % Add information about the device to the CustomData field
                    name = boardList{index};
                    friendlyName = arduinoioapplet.internal.Utility.getFriendlyName(name);
                    customDeviceData.Board = name;
                    customDeviceData.Address = deviceAddress;
                    customDeviceData.WiFiPort = port;
                    customDeviceData.ConnectionType = matlabshared.hwsdk.internal.ConnectionTypeEnum.WiFi;
                    deviceCardDisplayInfo = {getString(message("MATLAB:arduinoio:arduinoapp:boardLabel")),name;...
                        getString(message("MATLAB:arduinoio:arduinoapp:connectionLabel")),getString(message("MATLAB:arduinoio:arduinoapp:wifiLabel"));...
                        getString(message("MATLAB:arduinoio:arduinoapp:addressLabel")),addressPortPair};

                    % Create the HWMgr device object
                    device = matlab.hwmgr.internal.Device(friendlyName);
                    device.DeviceCardDisplayInfo = deviceCardDisplayInfo;
                    device.IconPath = obj.getDeviceIconPath(name);
                    device.VendorName = "Arduino";
                    device.DeviceAppletData = matlab.hwmgr.internal.data.DataFactory.createDeviceAppletData(...
                        obj.AppletPluginClass,obj.ArduinoIOBaseCode);
                    device.CustomData = customDeviceData;

                    % Append device to list
                    wifiDeviceCards = [wifiDeviceCards device];
                end
            end
        end

        function deviceCards = getBluetoothDeviceCards(obj)
            % Function to create device cards from saved Arduino Bluetooth preference

            deviceCards = [];
            % Get Bluetooth addresses from saved MATLAB preference

            % Return if there are no saved Arduino Bluetooth connection info
            if(~ispref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.BluetoothPrefName))
                return;
            end

            BTPref = getpref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.BluetoothPrefName);
            % Remove Bluetooth address prefix
            addressList = replace(keys(BTPref),"btspp://","");
            boardList = values(BTPref);

            if ~isempty(addressList)
                % Get the list of active Bluetooth devices
                % Disable and later restore warning state to avoid warning
                % when there are no active Bluetooth devices around.
                originalState = warning('off','MATLAB:bluetooth:bluetoothlist:noDeviceFound');
                try
                    btlist = bluetoothlist("Timeout",20);
                catch
                    % Return silently if Bluetooth radio is not available
                    warning(originalState.state,'MATLAB:bluetooth:bluetoothlist:noDeviceFound');
                    return;
                end
                warning(originalState.state,'MATLAB:bluetooth:bluetoothlist:noDeviceFound');

                % Populate device card details for Arduino devices that appear
                % in bluetoothlist
                if ~isempty(btlist) && any(contains(btlist.Address,addressList))
                    % Find indices of active Arduino Bluetooth devices in addressList
                    deviceIndices = find(any(contains(btlist.Address,addressList)));

                    % Parse through each active Bluetooth Arduino to get more board info
                    for counter = 1:length(deviceIndices)
                        % Get Additional board info
                        index = deviceIndices(counter);
                        % Prefix Bluetooth Addresses with btspp
                        deviceAddress = sprintf("btspp://%s",addressList{index});

                        % Skip if device card already exists. Since these are
                        % populated from MATLAB prefs, there is a possibility
                        % that the user might have already added the device
                        % manually using Add-device workflow.
                        if obj.deviceExists(deviceAddress)
                            continue;
                        end

                        name = boardList{index};
                        friendlyName = arduinoioapplet.internal.Utility.getFriendlyName(name);

                        % Add information about the device to the CustomData field
                        customDeviceData.Board = name;
                        customDeviceData.Address = deviceAddress;
                        customDeviceData.WiFiPort = [];
                        customDeviceData.ConnectionType = matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth;
                        deviceCardDisplayInfo = {getString(message("MATLAB:arduinoio:arduinoapp:boardLabel")),name;...
                            getString(message("MATLAB:arduinoio:arduinoapp:connectionLabel")),getString(message("MATLAB:arduinoio:arduinoapp:btLabel"));...
                            getString(message("MATLAB:arduinoio:arduinoapp:addressLabel")),deviceAddress};

                        % Create the HWMgr device object
                        device = matlab.hwmgr.internal.Device(friendlyName);
                        device.DeviceCardDisplayInfo = deviceCardDisplayInfo;
                        device.IconPath = obj.getDeviceIconPath(name);
                        device.VendorName = "Arduino";
                        device.DeviceAppletData = matlab.hwmgr.internal.data.DataFactory.createDeviceAppletData(...
                            obj.AppletPluginClass,obj.ArduinoIOBaseCode);
                        device.CustomData = customDeviceData;

                        % Append device to list
                        deviceCards = [deviceCards device];
                    end
                end
            end
        end

        function deviceCards = getBLEDeviceCards(obj)
            % Function to create device cards from saved Arduino BLE prefs

            deviceCards = [];
            % Get BLE addresses from saved MATLAB preference
            % Return if there are no saved Arduino BLE connection info
            if(~ispref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.BLEPrefName))
                return;
            end
            BLEPref = getpref(arduinoioapplet.internal.ArduinoAppConstants.PrefGroupName,arduinoioapplet.internal.ArduinoAppConstants.BLEPrefName);
            % Convert BLE Address in format XX:XX:XX to XXXXXX format
            addressList = upper(strrep(keys(BLEPref),':',''));
            boardList = values(BLEPref);

            if ~isempty(addressList)
                % Get the list of active BLE  devices
                % Disable and later restore warning state to avoid warning
                % when there are no active BLE devices around.
                originalState = warning('off','MATLAB:ble:ble:noDeviceFound');
                try
                    list = blelist;
                catch
                    % Return silently if BLE radio is not available
                    warning(originalState.state,'MATLAB:ble:ble:noDeviceFound');
                    return;
                end
                warning(originalState.state,'MATLAB:ble:ble:noDeviceFound');

                % Populate device card details for Arduino devices that appear
                % in blelist
                if ~isempty(list) && any(contains(list.Address,addressList))
                    % Find indices of active Arduino BLE devices in addressList

                    deviceIndices = find(any(contains(list.Address,addressList)));
                    % Parse through each active BLE Arduino to get more board info
                    for counter = 1:length(deviceIndices)
                        % Get Additional board info
                        index = deviceIndices(counter);
                        deviceAddress = addressList{index};

                        % Skip if device card already exists. Since these are
                        % populated from MATLAB prefs, there is a possibility
                        % that the user might have already added the device
                        % manually using Add-device workflow.
                        if obj.deviceExists(deviceAddress)
                            continue;
                        end

                        % Extract board name and device name from BoardName(DeviceName) format
                        deviceNames = strsplit(boardList{index},"(");
                        name = deviceNames{1};
                        % Use BLE name as friendly name
                        friendlyName = strrep(deviceNames{2},")","");
                        if isempty(friendlyName)
                            friendlyName = arduinoioapplet.internal.Utility.getFriendlyName(name);
                        end

                        % Add information about the device to the CustomData field
                        customDeviceData.Board = name;
                        customDeviceData.Address = deviceAddress;
                        customDeviceData.WiFiPort = [];
                        customDeviceData.ConnectionType = matlabshared.hwsdk.internal.ConnectionTypeEnum.Bluetooth;
                        deviceCardDisplayInfo = {getString(message("MATLAB:arduinoio:arduinoapp:boardLabel")),name;...
                            getString(message("MATLAB:arduinoio:arduinoapp:connectionLabel")),getString(message("MATLAB:arduinoio:arduinoapp:btLabel"));...
                            getString(message("MATLAB:arduinoio:arduinoapp:addressLabel")),deviceAddress};

                        % Create the HWMgr device object
                        device = matlab.hwmgr.internal.Device(friendlyName);
                        device.DeviceCardDisplayInfo = deviceCardDisplayInfo;
                        device.IconPath = obj.getDeviceIconPath(name);
                        device.VendorName = "Arduino";
                        device.DeviceAppletData = matlab.hwmgr.internal.data.DataFactory.createDeviceAppletData(...
                            obj.AppletPluginClass,obj.ArduinoIOBaseCode);
                        device.CustomData = customDeviceData;

                        % Append device to list
                        deviceCards = [deviceCards device]; %#ok<*AGROW>
                    end
                end
            end
        end

        function iconPath = getDeviceIconPath(~,boardName)
            % Function to pick the right display icon for Arduino in the
            % hardware device cards

            % Get form factor type
            formFactor = arduinoioapplet.internal.Utility.getBoardFormFactor(boardName);
            if isequal(formFactor,arduinoioapplet.internal.FormFactorTypesEnum.Large)
                icon = arduinoioapplet.internal.ArduinoAppConstants.LargeFFIcon;
            elseif isequal(formFactor,arduinoioapplet.internal.FormFactorTypesEnum.Medium)
                icon = arduinoioapplet.internal.ArduinoAppConstants.MediumFFIcon;
            else
                icon = arduinoioapplet.internal.ArduinoAppConstants.SmallFFIcon;
            end
            % Form the complete icon path
            iconPath = fullfile(arduinoioapplet.internal.ArduinoAppConstants.DeviceIconFolder,icon);
        end

        function [name,data] = getAdditionalBoardInfo(~,deviceInfo,boardInfoInstance)
            % Function to get additional board info for the detected
            % Arduino hardware

            found = false;
            name = [];
            data = [];
            vid = deviceInfo.VendorID;
            pid = deviceInfo.ProductID;

            % Loop through all boards in boardInfo to find matching vid/pid pair
            for index = 1:length(boardInfoInstance.Boards)
                if found
                    break;
                end
                VIDPID = boardInfoInstance.Boards(index).VIDPID;
                if ~isempty(VIDPID)
                    for vidpidIndex = 1:numel(VIDPID)
                        testVIDPID = "0x" + vid + "_" + "0x" + pid;
                        if strcmpi(testVIDPID, string(VIDPID{vidpidIndex}))
                            name = boardInfoInstance.Boards(index).Name;
                            found = true;
                            break;
                        end
                    end
                end
            end
            if ~isempty(name)
                data = arduinoio.internal.ResourceManager(name);
            end
        end

        function status = deviceExists(obj,varargin)
            % Function to check if a device card with same device address
            % already exists in the Hardware Manager device list

            status = 0;
            address = varargin{1};
            port = [];
            if(nargin>2)
                port = varargin{2};
            end

            for bIndex = 1:length(obj.DevicesProvided)
                if (isempty(port) && strcmpi(address,obj.DevicesProvided(bIndex).CustomData.Address)) ||...
                        (~isempty(port) && strcmpi(address,obj.DevicesProvided(bIndex).CustomData.Address) && strcmpi(port,obj.DevicesProvided(bIndex).CustomData.Port))
                    status = 1;
                    break;
                end
            end
        end
    end
end

% LocalWords:  Bluetooth WiFi wifi vid bluetoothlist TCP BLE blelist BT bluetooth
