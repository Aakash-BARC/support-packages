classdef arduinoioserver < handle
%Build and Upload the Arduino IO Server.
%
%Input Arguments:
%   board - Arduino Board type (character vector or string, e.g. 'Uno', 'Mega2560', ...)

%   Copyright 2017-2021 The MathWorks, Inc.

    %% Properties
    properties(Access = private)
        Utility
        BoardInfo
        BoardIndex
    end
    
    properties
        AvailableI2CBusIDs
    end
    properties(Access = private, Constant = true)
        % major release/minor release - 22aMarch
        LibVersion = '22.1.0';
    end
    
    methods(Access = public, Hidden)
        function obj = arduinoioserver(varargin)
            try
                obj.Utility = arduinoio.internal.UtilityCreator.getInstance();
                obj.BoardInfo = arduinoio.internal.BoardInfo.getInstance();
                b = obj.BoardInfo;
                boardType = validatestring(varargin{1}, {b.Boards.Name});
                obj.BoardIndex = find(arrayfun(@(x) strcmp(x.Name, boardType), b.Boards), 1);
                
                if isequal(boardType,'Due')
                    obj.AvailableI2CBusIDs = [1 2];
                else
                    obj.AvailableI2CBusIDs = 1;
                end
                
            catch e
                throwAsCaller(e);
            end
        end

    end


    %% hwsdk.controller
    methods(Access = public)
        function updateServerImpl(obj, varargin)
            buildInfo = obj.buildInfoServer();  
            buildInfo.ConnectionType = varargin{1};
            buildInfo.Port = varargin{2};
            buildInfo.HWSPPKGVersion = obj.LibVersion;
            buildInfo.TraceOn = 0;
            buildInfo.MAXPacketSize = 49;
            if buildInfo.TraceOn
                buildInfo.ShowUploadResult = true;
            else
                buildInfo.ShowUploadResult = false;
            end            
            updateServer(obj.Utility, buildInfo);
        end
        
        function info = buildInfoServer(obj)
            buildInfo.Board         = obj.BoardInfo.Boards(obj.BoardIndex).Name;
            buildInfo.BoardName     = obj.BoardInfo.Boards(obj.BoardIndex).BoardName;
            buildInfo.Package       = obj.BoardInfo.Boards(obj.BoardIndex).Package;
            buildInfo.CPU           = obj.BoardInfo.Boards(obj.BoardIndex).CPU;
            buildInfo.MemorySize    = obj.BoardInfo.Boards(obj.BoardIndex).MemorySize;
            
            % Pick the Baud Rate from ExtMode.BaudRate field in Model config set.
            % For Arduino Clone boards which uses CH340 or FTDI chip,
            % customer can use codertarget.arduinobase.registry.setBaudRate
            % which modifies the ExtMode.BaudRate field.
            % 
            % Note: Baudrate is not picked from BoardsInfo xml 
            % num2str(obj.BoardInfo.Boards(obj.BoardIndex).BaudRate);
            buildInfo.BaudRate      = simulinkio.getBaudRate; 
            
            buildInfo.MCU           = obj.BoardInfo.Boards(obj.BoardIndex).MCU;
            buildInfo.VIDPID        = obj.BoardInfo.Boards(obj.BoardIndex).VIDPID;
            if contains(obj.BoardInfo.Boards(obj.BoardIndex).Name,'ESP32')
                buildInfo.Libraries = string(arduinoio.internal.ArduinoConstants.DefaultLibrariesESP);
            else
                buildInfo.Libraries = string(arduinoio.internal.ArduinoConstants.DefaultLibraries);
            end
            % Serial lib is not available for all the arduino boards. Add
            % the lib only if the board supports Serial.
            if ismember(buildInfo.Board,arduinoio.internal.ArduinoConstants.SerialLibrarySupportBoards)
               buildInfo.Libraries = [buildInfo.Libraries,{'Serial'}];
            end
			% If any user-defined Addon/Custom-Peripherals are present add
            % them to buildinfo
            simAddonObj = codertarget.arduinobase.ioclient.SimulinkAddonLib;
            libList = simAddonObj.getAddonList();
            if ~isempty(libList)
               for index = 1:length(libList)
                   buildInfo.Libraries{end+1} = libList{index}; 
               end
            end
            
            info = buildInfo;    
        end
    end
end

% LocalWords:  hwsdk arduinoio vid
