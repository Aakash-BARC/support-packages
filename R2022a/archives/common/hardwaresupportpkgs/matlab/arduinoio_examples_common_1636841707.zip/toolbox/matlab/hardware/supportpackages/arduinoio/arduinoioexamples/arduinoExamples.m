function arduinoExamples()
%ARDUINO_EXAMPLES Open examples for MATLAB Support Package for Arduino
% Hardware.
%

%   Copyright 2014-2016 The MathWorks, Inc.

demo('matlab', 'MATLAB Support Package for Arduino Hardware')

