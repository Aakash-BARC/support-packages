function setLinaroAArch32ToolchainPath(toolchainPath)
% This function is called internally from DeepLearningConfig.Prebuild.ValidateCrossCompile function.
% This function is primarily to validate the path specified by the user and set env Var for 32 bit .
    envVar = matlab.lang.makeValidName('LINARO_TOOLCHAIN_6.3.1_AARCH32');
    validationSuccess = matlabshared.toolchain.gcc_linaro.internal.validateLinaroAArch32ToolchainPath(toolchainPath);
    if validationSuccess
       setenv(envVar, toolchainPath) 
       disp(['###  Linaro AArch32 Toolchain Path was set to "' toolchainPath '" successfully.']);
    else
       error(message('gpucoder:cnnconfig:InvaidToolchainPathSpecified', toolchainPath, 'AArch32'))
    end
end
