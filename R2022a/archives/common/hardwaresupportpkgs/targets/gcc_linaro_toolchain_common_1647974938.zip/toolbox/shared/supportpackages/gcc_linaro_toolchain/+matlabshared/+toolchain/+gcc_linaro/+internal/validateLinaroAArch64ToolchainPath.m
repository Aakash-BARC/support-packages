function validationSuccess = validateLinaroAArch64ToolchainPath(toolchainPath)
   if isfolder(toolchainPath) 
       % Here we are validating existence of binaries in user specified
       % path 
       isMissingBinaries = validateBinaries(toolchainPath);
       % isMissingBinaries returns true when binaries were not found in the path specified. 
       if (isMissingBinaries)
           validationSuccess = false;
       else
           validationSuccess = true;           
       end
   else
       validationSuccess = false;
   end
end

function isMissingBinaries = validateBinaries(compilerPath)
       listnames = struct2cell(dir(compilerPath));
       listnames = listnames(1,:);
       if ~any(contains(listnames,'aarch64-linux-gnu-')) 
           isMissingBinaries = true;
       else
           isMissingBinaries = false;
       end
end