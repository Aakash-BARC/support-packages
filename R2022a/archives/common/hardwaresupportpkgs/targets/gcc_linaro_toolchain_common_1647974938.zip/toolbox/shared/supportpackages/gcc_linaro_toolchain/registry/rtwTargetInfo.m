function rtwTargetInfo(tr)
%RTWTARGETINFO Register toolchain and target
 
% Copyright 2013-2018 The MathWorks, Inc.
tr.registerTargetInfo(@loc_createToolchain);


end

%--------------------------------------------------------------------------
function config = loc_createToolchain
rootDir = fileparts(mfilename('fullpath'));
config = coder.make.ToolchainInfoRegistry; % initialize
archName = computer('arch');


% % LINARO GNUARM 6.3.1
config(end+1).Name              = 'Linaro AArch64 Linux v6.3.1';
config(end).Alias               = ['LINARO_GNU_ARM_LINUX_6_3_1_', upper(archName)];
config(end).TargetHWDeviceType	= {'*'};
config(end).FileName            = fullfile(rootDir, ['gcc_linaro_aarch64_linux_gnu_gmake_', archName, '_v6.3.1.mat']);
config(end).Platform            = {archName};

% Linaro AArch32 Toolchain
config(end+1).Name              = 'Linaro AArch32 Linux v6.3.1';
config(end).Alias               = {'Xilinx Software Development Kit (SDK)','Xilinx ISE Design Suite 14.4','Xilinx Software Development Kit (SDK) 2013.4',['XILINXISE14X','_', upper(archName)]};
config(end).TargetHWDeviceType	= {'*'};
config(end).FileName            = fullfile(rootDir, ['gcc_linaro_aarch32_linux_gnueabihf_gmake_', archName, '_v6.3.1.mat']);
config(end).Platform            = {archName};
end

 


