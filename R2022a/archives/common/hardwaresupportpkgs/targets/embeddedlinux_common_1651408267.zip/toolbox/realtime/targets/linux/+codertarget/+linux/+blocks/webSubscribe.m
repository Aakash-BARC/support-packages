classdef webSubscribe < matlab.System & coder.ExternalDependency
    
    % Subscribe to websocket data received by the websocket server.
    %
    
    %   Copyright 2019-2020 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        % IP Address
        IPAddress = '127.0.0.1';
        
        % Port
        Port = 9000;
        
        % Specify Output Info via
        OutputCfg = 'Mask Dialog';
        
        % JSON File Path
        JSONFilePath = 'sample.txt';
        
        %Number of Outputs
        NumberOfSignals = '1';
        
        %Block Index
        webSocketId = '';
        
        %Output 1 Data Size
        Dsize1 = 1;
        %Output 1 Data Type
        Dtype1 = 'double';
        
        %Output 2 Data Size
        Dsize2 = 1;
        %Output 2 Data Type
        Dtype2 = 'double';
        
        %Output 3 Data Size
        Dsize3 = 1;
        %Output 3 Data Type
        Dtype3 = 'double';
        
        %Output 4 Data Size
        Dsize4 = 1;
        %Output 4 Data Type
        Dtype4 = 'double';
        
        %Output 5 Data Size
        Dsize5 = 1;
        %Output 5 Data Type
        Dtype5 = 'double';
        
        %Output 6 Data Size
        Dsize6 = 1;
        %Output 6 Data Type
        Dtype6 = 'double';
        
        %Output 7 Data Size
        Dsize7 = 1;
        %Output 7 Data Type
        Dtype7 = 'double';
        
        %Output 8 Data Size
        Dsize8 = 1;
        %Output 8 Data Type
        Dtype8 = 'double';
        
        %Output 9 Data Size
        Dsize9 = 1;
        %Output 9 Data Type
        Dtype9 = 'double';
        
        %Output 10 Data Size
        Dsize10 = 1;
        %Output 10 Data Type
        Dtype10 = 'double';
        
        %Sample time
        Sampletime = 0.1;
        
        %Block Platform
        BlockPlatform = 'LINUX';
    end
    
    properties (Constant, Hidden)
        NumberOfSignalsSet = matlab.system.StringSet({'1', '2', '3', '4', '5', '6', '7', '8', '9', '10'});
        Dtype1Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype2Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype3Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype4Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype5Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype6Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype7Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype8Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype9Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        Dtype10Set =  matlab.system.StringSet({'double', 'single', 'uint32', 'int32', 'uint16', 'int16', 'uint8', 'int8', 'boolean'});
        OutputCfgSet = matlab.system.StringSet({'Mask Dialog', 'JSON file'});
    end
    
    properties(Nontunable, Constant, Hidden)
        %Protocol
        Protocol = 'WebSocket'
    end
    
    properties(Hidden)
        nanomsgSock
        NumberOfSignalsEnum
    end
    
    methods
        % Constructor
        function obj = webSubscribe(varargin)
            %This would allow the code generation to proceed with the
            %p-files in the installed location of the support package.
            coder.allowpcode('plain');
            
            % Support name-value pair arguments when constructing the object.
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.Port(obj, val)
            % Validate portNumber.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  65535, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Port');
            obj.Port = val;
        end
        
        function set.Dsize1(obj, val)
            % Validate portNumber.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 1 Data Size');
            obj.Dsize1 = val;
        end
        
        function set.Dsize2(obj, val)
            % Validate portNumber.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 2 Data Size');
            obj.Dsize2 = val;
        end
        
        function set.Dsize3(obj, val)
            % Validate portNumber.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 3 Data Size');
            obj.Dsize3 = val;
        end
        function set.Dsize4(obj, val)
            % Validate portNumber.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 4 Data Size');
            obj.Dsize4 = val;
        end
        function set.Dsize5(obj, val)
            % Validate Dsize1Number.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 5 Data Size');
            obj.Dsize5 = val;
        end
        function set.Dsize6(obj, val)
            % Validate Dsize1Number.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 6 Data Size');
            obj.Dsize6 = val;
        end
        function set.Dsize7(obj, val)
            % Validate Dsize1Number.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 7 Data Size');
            obj.Dsize7 = val;
        end
        function set.Dsize8(obj, val)
            % Validate Dsize1Number.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 8 Data Size');
            obj.Dsize8 = val;
        end
        function set.Dsize9(obj, val)
            % Validate Dsize1Number.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 9 Data Size');
            obj.Dsize9 = val;
        end
        function set.Dsize10(obj, val)
            % Validate Dsize1Number.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  255, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Output 10 Data Size');
            obj.Dsize10 = val;
        end
        
         function set.IPAddress(obj,val)
            attributes = {'nonempty'};
            paramName = 'IP Address';
            ipVal = convertStringsToChars(val);
            validateattributes(ipVal,{'char'},attributes,'',paramName);            
            if isempty(coder.target)
                ip_expr = '25[0-5]\.|2[0-4][0-9]\.|1[0-9][0-9]\.|[1-9][0-9]\.|[1-9]\.|0\.';
                [match] = regexp([ipVal '.'], ip_expr, 'match');
                if ( length(match) ~= 4 )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                ipStr = [match{1} match{2} match{3} match{4}(1:end-1)];
                if ( ~strcmp(ipStr, ipVal) )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                
                if strcmp(ipVal,'0.0.0.0')
                    error(message('linux:utils:InvalidIPAddress'));
                end
            end
            obj.IPAddress = ipVal;
         end
        
      
        function set.Sampletime(obj,sampleTime)
            coder.extrinsic('error');
            coder.extrinsic('message');
            
            validateattributes(sampleTime,{'numeric'},...
                {'nonnan', 'finite'},...
                '','''Sample time''');
            
            % Sample time must be a real scalar value or 2 element array.
            if ~isreal(sampleTime(1)) || numel(sampleTime) > 2
                error(message('linux:utils:InvalidSampleTimeNeedScalar'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) > 0.0 && sampleTime(2) >= sampleTime(1)
                error(message('linux:utils:InvalidSampleTimeNeedSmallerOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == -1.0 && sampleTime(2) ~= 0.0
                error(message('linux:utils:InvalidSampleTimeNeedZeroOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == 0.0 && sampleTime(2) ~= 1.0
                error(message('linux:utils:InvalidSampleTimeNeedOffsetOne'));
            end
            if numel(sampleTime) ==1 && sampleTime(1) < 0.001 && sampleTime(1) ~= -1.0
                error(message('linux:utils:InvalidSampleTimeNeedPositive'));
            end
            obj.Sampletime = sampleTime;
        end
        
        function val = get.NumberOfSignalsEnum(obj)
            val = str2double(obj.NumberOfSignals);
        end
        
    end
    
    methods (Access = protected)
        %% Common functions
        function setupImpl(obj, varargin)
            % Implement tasks that need to be performed only once,
            % such as pre-computed constants.
            coder.extrinsic('realtime.internal.getWebSocketID');
            if coder.target('Rtw')
                websocketIntID = coder.const(realtime.internal.getWebSocketID(obj.webSocketId,'realtime.internal'));
                coder.cinclude('MW_nanomsgClient.h');
                coder.cinclude('MW_JSONParser.h');
                sock = uint8(0);
                sock = coder.ceval('MW_nanomsgClientSubInit',uint8(websocketIntID));
                obj.nanomsgSock = sock;
            end
        end
        
        function  [status,varargout]=stepImpl(obj)
            % Implement algorithm. Calculate y as a function of
            % input u and discrete states.
            status_file = int8(-1);
            status_values = [1 1 1 1 1 1 1 1 1 1];
            for i = 1:obj.NumberOfSignalsEnum
                if (i ==1)
                    dataout1 = double(zeros(obj.Dsize1,1));
                    varargout{i} = obj.typecastData(dataout1, obj.Dtype1);
                end
                if (i ==2)
                    dataout2 = double(zeros(obj.Dsize2,1));
                    varargout{i} = obj.typecastData(dataout2, obj.Dtype2);
                end
                if (i ==3)
                    dataout3 = double(zeros(obj.Dsize3,1));
                    varargout{i} = obj.typecastData(dataout3, obj.Dtype3);
                end
                if (i ==4)
                    dataout4 = double(zeros(obj.Dsize4,1));
                    varargout{i} = obj.typecastData(dataout4, obj.Dtype4);
                end
                if (i ==5)
                    dataout5 = double(zeros(obj.Dsize5,1));
                    varargout{i} = obj.typecastData(dataout5, obj.Dtype5);
                end
                if (i ==6)
                    dataout6 = double(zeros(obj.Dsize6,1));
                    varargout{i} = obj.typecastData(dataout6, obj.Dtype6);
                end
                if (i ==7)
                    dataout7 = double(zeros(obj.Dsize7,1));
                    varargout{i} = obj.typecastData(dataout7, obj.Dtype7);
                end
                if (i ==8)
                    dataout8 = double(zeros(obj.Dsize8,1));
                    varargout{i} = obj.typecastData(dataout8, obj.Dtype8);
                end
                if (i ==9)
                    dataout9 = double(zeros(obj.Dsize9,1));
                    varargout{i} = obj.typecastData(dataout9, obj.Dtype9);
                end
                if (i ==10)
                    dataout10 = double(zeros(obj.Dsize10,1));
                    varargout{i} = obj.typecastData(dataout10, obj.Dtype10);
                end
            end
            %             varargout{1+obj.NumberOfSignalsEnum} = int8(1);
            status = int8(1);
            if coder.target('Rtw')
                jsonString = coder.opaque('char *', 'NULL');
                status_file = coder.ceval('MW_nanomsgClientRecv',uint8(obj.nanomsgSock), coder.wref(jsonString));
                if (status_file == int8(1))
                    for i = 1:obj.NumberOfSignalsEnum
                        if (i ==1)
                            %                             dataout1 = double(zeros(obj.Dsize1,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout1), uint8(obj.Dsize1));
                            varargout{i} = obj.typecastData(dataout1, obj.Dtype1);
                        end
                        if (i ==2)
                            %                             dataout2 = double(zeros(obj.Dsize2,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout2), uint8(obj.Dsize2));
                            varargout{i} = obj.typecastData(dataout2, obj.Dtype2);
                        end
                        if (i ==3)
                            %                             dataout3 = double(zeros(obj.Dsize3,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout3), uint8(obj.Dsize3));
                            varargout{i} = obj.typecastData(dataout3, obj.Dtype3);
                        end
                        if (i ==4)
                            %                             dataout4 = double(zeros(obj.Dsize4,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout4), uint8(obj.Dsize4));
                            varargout{i} = obj.typecastData(dataout4, obj.Dtype4);
                        end
                        if (i ==5)
                            %                             dataout5 = double(zeros(obj.Dsize5,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout5), uint8(obj.Dsize5));
                            varargout{i} = obj.typecastData(dataout5, obj.Dtype5);
                        end
                        if (i ==6)
                            %                             dataout6 = double(zeros(obj.Dsize6,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout6), uint8(obj.Dsize6));
                            varargout{i} = obj.typecastData(dataout6, obj.Dtype6);
                        end
                        if (i ==7)
                            %                             dataout7 = double(zeros(obj.Dsize7,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout7), uint8(obj.Dsize7));
                            varargout{i} = obj.typecastData(dataout7, obj.Dtype7);
                        end
                        if (i ==8)
                            %                             dataout8 = double(zeros(obj.Dsize8,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout8), uint8(obj.Dsize8));
                            varargout{i} = obj.typecastData(dataout8, obj.Dtype8);
                        end
                        if (i ==9)
                            %                             dataout9 = double(zeros(obj.Dsize9,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout9), uint8(obj.Dsize9));
                            varargout{i} = obj.typecastData(dataout9, obj.Dtype9);
                        end
                        if (i ==10)
                            %                             dataout10 = double(zeros(obj.Dsize10,1));
                            status_values(i) = coder.ceval('MW_getPortData', jsonString, uint8(i),  coder.wref(dataout10), uint8(obj.Dsize10));
                            varargout{i} = obj.typecastData(dataout10, obj.Dtype10);
                        end
                    end
                end
            end
            
            if(status_file ~= 1)
                status = int8(0);
                return;
            end
            if (any(status_values(:) == 0))
                status  = int8(-1);
                return;
            end
        end
        
        
        function val = typecastData(~, data, datatype)
            switch(datatype)
                case 'double'
                    val = double(data);
                case 'single'
                    val = single(data);
                case 'uint32'
                    val = uint32(data);
                case 'int32'
                    val = int32(data);
                case 'uint16'
                    val = uint16(data);
                case 'int16'
                    val = int16(data);
                case 'uint8'
                    val = uint8(data);
                case 'int8'
                    val = int8(data);
                case 'boolean'
                    val = logical(data);
            end
        end
        
        function releaseImpl(obj)
            % Release resources, such as file handles
            if coder.target('Rtw')
                coder.ceval('MW_nanomsgClientShutdown', uint8(obj.nanomsgSock));
            end
        end
        
        
        function [status, varargout]= isOutputComplexImpl(obj)
            % Return true for each output port with complex data
            for i =  1:obj.NumberOfSignalsEnum
                varargout{i} = false;
            end
            
            status = false;
            % Example: inherit complexity from first input port
            % out = propagatedInputComplexity(obj,1);
        end
        
        function [status, varargout] = isOutputFixedSizeImpl(obj)
            % Return true for each output port with fixed size
            for i =  1:obj.NumberOfSignalsEnum
                varargout{i} = true;
            end
            
            status = true;
            % Example: inherit fixed-size status from first input port
            % out = propagatedInputFixedSize(obj,1);
        end
        
      function st = getSampleTimeImpl(obj)
            if obj.Sampletime == -1
                st = createSampleTime(obj, 'Type', 'Inherited');
            else
                st = createSampleTime(obj, 'Type', 'Discrete', 'SampleTime', obj.Sampletime);
            end
        end
        
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 0;
        end
        
        function N = getNumOutputsImpl(obj)
            % Specify number of System outputs
            N = obj.NumberOfSignalsEnum+1;
        end
        
        function [status, varargout] = getOutputNamesImpl(obj)
            % Return output port names for System block
            for i =  1:obj.NumberOfSignalsEnum
                varargout{i} = ['sig' num2str(i)];
            end
            status = 'status';
        end
        
        function [status, varargout]  = getOutputSizeImpl(obj)
            % Return size for each output port
            for i =  1:obj.NumberOfSignalsEnum
                varargout{i} = [obj.(['Dsize' num2str(i)]) 1];
            end
            status = [1 1];
            
            % Example: inherit size from first input port
            % out = propagatedInputSize(obj,1);
        end
        
        function [status, varargout]  = getOutputDataTypeImpl(obj)
            % Return data type for each output port
            for i =  1:obj.NumberOfSignalsEnum
                varargout{i} = obj.(['Dtype' num2str(i)]);
            end
            status = 'int8';
        end
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
             portLabel = [];
             portLabel = [portLabel, 'port_label(''output'',1,''Status'')', newline];
             for i = 1:str2double(obj.NumberOfSignals)
                  portLabel = [portLabel, 'port_label(''output'',' (num2str(i+1)) ',''Out',num2str(i),''');', newline]; %#ok<*AGROW>
             end
             
            maskDisplayCmds = { ...
                ['color(''white'');', newline],...    % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);', newline],... % Drawing mask layout of the block
                ['plot([0,0,0,0],[0,0,0,0]);', newline],...
                ['color(''black'');', newline] ...  
                portLabel,...                
                };
            
            labelSample = obj.BlockPlatform;
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(96, 90, ''' labelSample ''', ''horizontalAlignment'', ''right'');', newline],...
                ['color(''black'');', newline],...
                ['image(''webSocSubscribe.jpg'',''center'');', newline],...
                };
            maskDisplayCmds = [maskDisplayCmds maskDisplayCmdsTarget];
        end
        
    end
    
    methods(Static, Access = protected)
        
        
        %% Simulink customization functions
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header('ShowSourceLink', false);
        end
        
        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function flag = showSimulateUsingImpl
            % Return false if simulation mode hidden in System block dialog
            flag = false;
        end
        
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'WebSocket Publish';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot;
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludeFiles(buildInfo, 'MW_nanomsgClient.h');
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    addSourcePaths(buildInfo, fullfile(rootDir, 'src'));
                    addSourceFiles(buildInfo, 'MW_nanomsgClient.c', fullfile(rootDir, 'src'), 'BlockModules');
                    addSourceFiles(buildInfo, 'MW_JSONParser.c', fullfile(rootDir, 'src'), 'BlockModules');
                    addLinkFlags(buildInfo,'-lnanomsg');
                    addLinkFlags(buildInfo,'-ljson-c');
                end
            end
        end
    end
end


% LocalWords:  online codertarget linux nanomsg Socket online codertarget
% LocalWords:  nanomsg Socket websocket Serverport lnanomsg Soccket
