function obj = linuxDDGCreate(h, className)
%linuxDDGCreate

% Copyright 2012 The MathWorks, Inc.

obj = LinuxBlockDialogs.(className{1})(h);
end

