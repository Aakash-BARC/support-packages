classdef SCIRead < matlabshared.svd.SCIRead ...
        & coder.ExternalDependency
    %SCIRead Read data from the Serial port
    %
    
    % Copyright 2020 The MathWorks, Inc.
    
    %#codegen
    
    properties (Nontunable)
        %SCIModule SCI module
        SCIModule = '/dev/serial0';
    end
    
    methods
        function obj = SCIRead(varargin)
            obj.Logo = 'LINUX';
        end
    end
    
    methods(Access = protected)
        function flag = isInactivePropertyImpl(obj,prop)
            % Return false if property is visible based on object
            % configuration, for the command line and System block dialog
            flag = isInactivePropertyImpl@matlabshared.svd.SCIRead(obj, prop);
        end
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'SCI Read';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context) %#ok<INUSD>
        end
    end
end