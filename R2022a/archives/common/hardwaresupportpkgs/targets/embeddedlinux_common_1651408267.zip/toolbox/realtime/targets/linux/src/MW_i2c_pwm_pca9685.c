/* Copyright 2021 The MathWorks, Inc. */
#include "MW_i2c_pwm_pca9685.h"

#if !(defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))

static char fileBuffer[128], openErrorBuffer[128], writeErrorBuffer[128];

/* Function declarations */
int i2c_pwm_pca9685_writeToFile(uint32_T data)
{
    int fd, len;
    char dataBuffer[128];
    ssize_t bytesWritten;
    
    printf("File buffer content: %s\n", fileBuffer);
    
    fd = open(fileBuffer, O_WRONLY);
    if (fd < 0)
    {
        perror(openErrorBuffer);
        return -1;
    }
    len = snprintf(dataBuffer, sizeof(dataBuffer), "%d", data);
    
    printf("Databuffer content: %s\n", dataBuffer);
    
    bytesWritten = write(fd, dataBuffer, len);
    close(fd);
    if (bytesWritten < 0)
    {
        perror(writeErrorBuffer);
        return -2;
    }
    
    return 0;
}

int i2c_pwm_pca9685_setup(uint8_T panChannel, uint8_T tiltChannel, uint8_T panEnabled, uint8_T tiltEnabled, uint32_T period, uint32_T panPulse, uint32_T tiltPulse)
{
    int panStatus, tiltStatus;
    
    if (panEnabled) {
        // Export channel
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/export");
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_panexport/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_panexport/write");
        panStatus = i2c_pwm_pca9685_writeToFile(panChannel);
        if (panStatus != 0) {
            return panStatus;
        }
        
        // Set period
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/period", panChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_panperiod/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_panperiod/write");
        panStatus = i2c_pwm_pca9685_writeToFile(period);
        if (panStatus != 0) {
            return panStatus;
        }
        
        // Set pulse (angle)
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/duty_cycle", panChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_pandutycycle/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_pandutycycle/write");
        panStatus = i2c_pwm_pca9685_writeToFile(panPulse);
        if (panStatus != 0) {
            return panStatus;
        }
    }
    
    if (tiltEnabled) {
        // Export channel
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/export");
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_tiltexport/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_tiltexport/write");
        tiltStatus = i2c_pwm_pca9685_writeToFile(tiltChannel);
        if (tiltStatus != 0) {
            return tiltStatus;
        }
        
        // Set period
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/period", tiltChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_tiltperiod/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_tiltperiod/write");
        tiltStatus = i2c_pwm_pca9685_writeToFile(period);
        if (tiltStatus != 0) {
            return tiltStatus;
        }

        // Set pulse (angle)
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/duty_cycle", tiltChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_tiltdutycycle/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_tiltdutycycle/write");
        tiltStatus = i2c_pwm_pca9685_writeToFile(tiltPulse);
        if (tiltStatus != 0) {
            return tiltStatus;
        }
    }

    return 0;
}

int i2c_pwm_pca9685_step(uint8_T panChannel, uint8_T tiltChannel, uint8_T panEnabled, uint8_T tiltEnabled, uint32_T panPulse, uint32_T tiltPulse)
{
    int panStatus, tiltStatus;
    
    if (panEnabled) {
        // Set pulse (panPulse)
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/duty_cycle", panChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_pandutycycle/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_pandutycycle/write");
        panStatus = i2c_pwm_pca9685_writeToFile(panPulse);
        if (panStatus != 0) {
            return panStatus;
        }
    }
    
    if (tiltEnabled) {
        // Set pulse (tiltPulse)
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/duty_cycle", tiltChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_tiltdutycycle/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_tiltdutycycle/write");
        tiltStatus = i2c_pwm_pca9685_writeToFile(tiltPulse);
        if (tiltStatus != 0) {
            return tiltStatus;
        }
    }

    return 0;
}

int i2c_pwm_pca9685_terminate(uint8_T panChannel, uint8_T tiltChannel, uint8_T panEnabled, uint8_T tiltEnabled)
{
    int panStatus, tiltStatus;
    uint32_T temp = 0;

    if (panEnabled) {
        // Reset pulse
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/duty_cycle", panChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_resetpandutycycle/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_resetpandutycycle/write");
        panStatus = i2c_pwm_pca9685_writeToFile(temp);
        if (panStatus != 0) {
            return panStatus;
        }
        // Unexport channel
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/unexport");
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_panunexport/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_panunexport/write");
        panStatus = i2c_pwm_pca9685_writeToFile(panChannel);
        if (panStatus != 0) {
            return panStatus;
        }
    }
    
    if (tiltEnabled) {
        // Reset pulse
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/pwm%d/duty_cycle", tiltChannel);
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_resettiltdutycycle/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_resettiltdutycycle/write");
        tiltStatus = i2c_pwm_pca9685_writeToFile(temp);
        if (tiltStatus != 0) {
            return tiltStatus;
        }
        // Unexport channel
        snprintf(fileBuffer, sizeof(fileBuffer), SYSFS_I2C_PWM_PCA9685_DIR "/unexport");
        snprintf(openErrorBuffer, sizeof(openErrorBuffer), "PWM-PCA9685_tiltunexport/open");
        snprintf(writeErrorBuffer, sizeof(writeErrorBuffer), "PWM-PCA9685_tiltunexport/write");
        tiltStatus = i2c_pwm_pca9685_writeToFile(tiltChannel);
        if (tiltStatus != 0) {
            return tiltStatus;
        }
    }

    return 0;
}

#endif

