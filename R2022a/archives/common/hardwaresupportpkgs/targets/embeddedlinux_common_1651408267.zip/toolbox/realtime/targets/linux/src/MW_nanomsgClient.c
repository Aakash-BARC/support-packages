/* Copyright 2019 The MathWorks, Inc. */
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <nanomsg/nn.h>
#include <nanomsg/pubsub.h>
#include "MW_nanomsgClient.h"
#include "MW_JSONParser.h"

#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)
#define AT __FILE__ ":" TOSTRING(__LINE__)

#ifdef _MATLABIO_
int MW_nanomsgClientPubInit(uint8_t blockIndex, char* mdlName) {
    char url[255];
    int bindChk = -1;
    sprintf(url, "ipc:///tmp/%s_websocPub%d.ipc", mdlName, blockIndex);
    // printf("Pub URL = %s\n", url);
    int sock = nn_socket(AF_SP, NN_PUB);
    //  printf("Pub Sock = %u\n\n", sock);
    bindChk = nn_bind(sock, url);
    if (bindChk < 0) {
        return -1;
    } else {
        return (sock);
    }
}

#else
int MW_nanomsgClientPubInit(uint8_t blockIndex) {
    char url[255];
    sprintf(url, "ipc:///tmp/%s_websocPub%d.ipc", TOSTRING(MODEL), blockIndex);
    // printf("Pub URL = %s\n", url);
    int sock = nn_socket(AF_SP, NN_PUB);
    //  printf("Pub Sock = %u\n\n", sock);
    assert(sock >= 0);
    assert(nn_bind(sock, url) >= 0);

    return (sock);
}
#endif

#ifdef _MATLABIO_
int MW_nanomsgClientSubInit(uint8_t blockIndex, char* mdlName) {
    char url[255];
    int connectChk = -1;
    sprintf(url, "ipc:///tmp/%s_websocSub%d.ipc", mdlName, blockIndex);
    //  printf("Sub URL = %s\n", url);
    int sock = nn_socket(AF_SP, NN_SUB);
    //  printf("Sub Sock = %u\n\n", sock);
    nn_setsockopt(sock, NN_SUB, NN_SUB_SUBSCRIBE, "", 0);
    connectChk = nn_connect(sock, url);
    if (connectChk <0){
        return -1;
    } else {
        return(sock);
    }
}
#else
int MW_nanomsgClientSubInit(uint8_t blockIndex) {
    char url[255];
    sprintf(url, "ipc:///tmp/%s_websocSub%d.ipc", TOSTRING(MODEL), blockIndex);
    //  printf("Sub URL = %s\n", url);
    int sock = nn_socket(AF_SP, NN_SUB);
    //  printf("Sub Sock = %u\n\n", sock);
    assert(sock >= 0);
    assert(nn_setsockopt(sock, NN_SUB, NN_SUB_SUBSCRIBE, "", 0) >= 0);
    assert(nn_connect(sock, url) >= 0);
    return (sock);
}
#endif

#ifdef _MATLABIO_
int MW_nanomsgClientRecv(int sock, char** SigStr, int *bytes) {
    char* buf = NULL;
    int status;
    uint8_t isJSONValid;

    *bytes = nn_recv(sock, &buf, NN_MSG, NN_DONTWAIT);
    if (*bytes < 0) {
        status = 0;
    } else {
        //         printf("CLIENT (%s): RECEIVED %s\n", "webPub", buf);
        isJSONValid = MW_getSignalStr(buf, SigStr);
        if (isJSONValid == 1) {
            *bytes = strlen(*SigStr);
            status = 1;
        } else {
            //    printf("isJSONValid = %d\n", isJSONValid);
            status = 0;
        }
        // printf("isJSONValid = %d\n", isJSONValid);
        nn_freemsg(buf);
    }

    return (status);
}
#else
int MW_nanomsgClientRecv(int sock, char** SigStr) {
    char* buf = NULL;
    int status;
    uint8_t isJSONValid;

    int bytes = nn_recv(sock, &buf, NN_MSG, NN_DONTWAIT);
    if (bytes < 0) {
        status = 0;
    } else {
        //         printf("CLIENT (%s): RECEIVED %s\n", "webPub", buf);
        isJSONValid = MW_getSignalStr(buf, SigStr);
        if (isJSONValid == 1) {
            status = 1;
        } else {
            //    printf("isJSONValid = %d\n", isJSONValid);
            status = 0;
        }
        // printf("isJSONValid = %d\n", isJSONValid);
        nn_freemsg(buf);
    }

    return (status);
}
#endif

void MW_nanomsgClientSend(int sock, char* msg) {
    int sz_msg = strlen(msg); // '\0' too
                              // printf ("SERVER Sock = %u: PUBLISHING Data  %s\n",sock,  msg);
    int bytes = nn_send(sock, msg, sz_msg, 0);
    assert(bytes == sz_msg);
}

void MW_nanomsgClientShutdown(int sock) {
    nn_close(sock);
}
