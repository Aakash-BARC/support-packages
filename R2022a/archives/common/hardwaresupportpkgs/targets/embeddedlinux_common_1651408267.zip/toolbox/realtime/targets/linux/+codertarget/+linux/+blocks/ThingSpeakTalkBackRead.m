classdef ThingSpeakTalkBackRead < matlab.System & ...
        coder.ExternalDependency
    % Read from ThingSpeak TalkBack using API EndPoints
    %
    % Copyright 2021 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>
    

    % Public, non-tunable properties
    properties(Nontunable)
        %TalkBack API
        TalkBackMode (1,:) char {matlab.system.mustBeMember(TalkBackMode,{'Execute next command', 'Last executed command'})} = 'Execute next command';
        %TalkBack ID      
        TalkBackID = int32(123456);
        %API key    
        APIKey = 'ABCDEFGHIJKLMNOP';
        % Command type
        CommandType (1,:) char {matlab.system.mustBeMember(CommandType,{'String', 'ASCII vector'})} = 'String';
        % Command length
        CommandLength = 1;
        %Sample time
        SampleTime = 5;
        % Block platform
        blockPlatform = 'LINUX';
        % TalkBack url
        TalkBackUrl =  'https://api.thingspeak.com/talkbacks/';

        % Print diagnostic messages
        PrintDiagnosticMessages (1, 1) logical = false;
    end
   
    % Pre-computed constants
    properties(Hidden, Access = private)
        TBHandle;
    end

    methods
        % Constructor
        function obj = ThingSpeakTalkBackRead(varargin)
            % Support name-value pair arguments when constructing object
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:})
        end
        
        function set.APIKey(obj, val)
            validateattributes(val, ...
                {'char'}, {'nonempty'}, '', 'APIKey');
            obj.APIKey = strtrim(val);
        end
        
        function set.TalkBackID(obj, val)
            validateattributes(val, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', 'nonempty'}, '', 'TalkbackID');
            obj.TalkBackID = val;
        end  
        
        function set.CommandLength(obj, val)
            validateattributes(val, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', 'nonempty'}, '', 'TalkbackID');
            obj.CommandLength = int32(val);
        end
        
        function set.SampleTime(obj,sampleTime)
            coder.extrinsic('error');
            coder.extrinsic('message');
            
            validateattributes(sampleTime,{'numeric'},...
                {'nonnan', 'finite'},...
                '','''Sample time''');
            
            % Sample time must be a real scalar value or 2 element array.
            if ~isreal(sampleTime(1)) || numel(sampleTime) > 2
                error(message('linux:utils:InvalidSampleTimeNeedScalar'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) > 0.0 && sampleTime(2) >= sampleTime(1)
                error(message('linux:utils:InvalidSampleTimeNeedSmallerOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == -1.0 && sampleTime(2) ~= 0.0
                error(message('linux:utils:InvalidSampleTimeNeedZeroOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == 0.0 && sampleTime(2) ~= 1.0
                error(message('linux:utils:InvalidSampleTimeNeedOffsetOne'));
            end
            if numel(sampleTime) ==1 && sampleTime(1) < 1 && sampleTime(1) ~= -1.0
                error(message('linux:utils:InvalidSampleTimeNeedPositive'));
            end
            obj.SampleTime = sampleTime;
        end
    end

    methods(Access = protected)
        %% Common functions
        function setupImpl(obj)
            % Perform one-time calculations, such as computing constants
            if coder.target('Rtw')
                coder.cinclude('MW_thingspeak_talkback.h');
                coder.ceval('MW_talkback_init', cstr(obj.TalkBackUrl), cstr(int2str(obj.TalkBackID)), cstr(obj.APIKey), obj.PrintDiagnosticMessages);
                
                len = max(ceil(log10(abs(obj.TalkBackID))),1);
                talkBackID = int32(obj.TalkBackID);
				
				% Initialize whole array with '0' which ASCII 48. 
				% Guard against any failures from successive int2string 
				% operation. Later string from 1 to len is taken, after
				% codegen, during runtime this might crash if there are 
				% null characters
                talkBackIdstr = char(48*ones(1,len));  
                readURL = '';
                coder.ceval('MW_talkBack_int2string',talkBackID,coder.wref(talkBackIdstr));
                if isequal(obj.TalkBackMode, 'Execute next command')
                    readURL = strtrim([obj.TalkBackUrl, talkBackIdstr(1:len), '/commands/execute.json?api_key=', obj.APIKey]);
                elseif isequal(obj.TalkBackMode, 'Last executed command')
                    readURL = strtrim([obj.TalkBackUrl, talkBackIdstr(1:len), '/commands/last.json?api_key=', obj.APIKey]);
                end
                obj.TBHandle = coder.opaque('TBReadData_t *','NULL','HeaderFile','MW_thingspeak_talkback.h');
                obj.TBHandle = coder.ceval('MW_talkBack_readInit', cstr(readURL), obj.PrintDiagnosticMessages);
            end 
        end

        function [command, status] = stepImpl(obj)
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
            command = uint8(zeros(1,(obj.CommandLength)));
            status = int8(0);
            if coder.target('MATLAB')
                if isequal(obj.TalkBackMode, 'Execute next command')
                    try
                        charCommand = webwrite([obj.TalkBackUrl, num2str(obj.TalkBackID), '/commands/execute'], 'api_key', char(obj.APIKey));
                    catch
                        charCommand = '';
                    end
                elseif isequal(obj.TalkBackMode, 'Last executed command')
                    try
                        charCommand = webread([obj.TalkBackUrl, num2str(obj.TalkBackID), '/commands/last'], 'api_key', char(obj.APIKey));
                    catch 
                        charCommand = '';
                    end
                end
                if ~isempty(charCommand)
                    fullCommand = uint8(charCommand);
                    command = uint8(zeros(1,obj.CommandLength));
                    if length(fullCommand) > obj.CommandLength
                        command = fullCommand(1:obj.CommandLength);
                        status = int8(2);
                    elseif length(fullCommand) < obj.CommandLength
                        command(1:length(fullCommand)) = fullCommand;
                        if isequal(obj.CommandType, 'String')
                            status = int8(1);
                        else
                            status = int8(3);
                        end
                    else
                        command = fullCommand;
                        status = int8(1);
                    end
                else
                    status = int8(0);
                end
            elseif coder.target('Rtw')
                status = coder.ceval('MW_talkBack_readCommand', obj.TBHandle, coder.ref(command), obj.CommandLength);
                if isequal(obj.CommandType, 'String')
                    if status == 3
                        status = int8(1);
                    end
                end
            end
        end

        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval('MW_talkBack_terminate',obj.TBHandle);
            end
        end
        
        %% Backup/restore functions
        function s = saveObjectImpl(obj)
            % Set properties in structure s to values in object obj

            % Set public properties and states
            s = saveObjectImpl@matlab.System(obj);

            % Set private and protected properties
            %s.myproperty = obj.myproperty;
        end

        function loadObjectImpl(obj,s,wasLocked)
            % Set properties in object obj to values in structure s

            % Set private and protected properties
            % obj.myproperty = s.myproperty; 

            % Set public properties and states
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end

        %% Simulink functions
        function ds = getDiscreteStateImpl(obj)
            % Return structure of properties with DiscreteState attribute
            ds = struct([]);
        end

        function flag = isInputSizeMutableImpl(obj,index)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end
        
        function st = getSampleTimeImpl(obj)
            if obj.SampleTime == -1
                st = createSampleTime(obj, 'Type', 'Inherited');
            else
                st = createSampleTime(obj, 'Type', 'Discrete', 'SampleTime', obj.SampleTime);
            end
        end
        
        function varargout = getOutputSizeImpl(obj)
            % Return size for each output port
            varargout{1} = [1 obj.CommandLength]; % Command String
            varargout{2} = 1; % Status
        end
        
        function varargout = isOutputFixedSizeImpl(obj,~)
            varargout{1} = true; % Command String
            varargout{2} = true; % Status
        end
         
        function varargout = isOutputComplexImpl(obj)
            varargout{1} = false; % Command String
            varargout{2} = false; % Status
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = 'uint8'; % Command String
            varargout{2} = 'int8'; % Status
        end
        
        function out = getNumInputsImpl(obj)
            % Specify number of System inputs
            out = 0;
        end
        
        function out = getNumOutputsImpl(obj)
            % Specify number of System inputs
            out = 2;
        end
        
        function varargout = getOutputNamesImpl(obj)
            if isequal(obj.CommandType, 'String')
                varargout{1} = 'Command string';
            else
                varargout{1} = 'ASCII Command';
            end
            varargout{2} = 'Status';
            
        end
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            outport_label = '';
            num = getNumOutputsImpl(obj);
            if num > 0
                outputs = cell(1,num);
                [outputs{1:num}] = getOutputNamesImpl(obj);
                for i = 1:num
                    outport_label = [outport_label 'port_label(''output'',' num2str(i) ',''' outputs{i} ''');' ]; %#ok<AGROW>
                end
            end
            talkBackID = int2str(obj.TalkBackID);
            talkBackDisp = '';
            talkBackDisp = ['text(50, 15, ''TalkBack ID:  ' talkBackID ''', ''horizontalAlignment'', ''center'',''verticalAlignment'',''middle'');'];
            maskDisplayCmds = { ...
                'color(''white'');',...
                'plot([100,100,100,100]*1,[100,100,100,100]*1);',...
                'plot([100,100,100,100]*0,[100,100,100,100]*0);',...
                'color(''black'');', ...
                'text(50,60,''\fontsize{12}\bfTalkBack'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');', ...
                'text(50,40,''\fontsize{10}\bfRead'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',...
                talkBackDisp,...
                outport_label
                };
            
            labelSample = obj.blockPlatform;
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(99, 92, ''' labelSample ''', ''horizontalAlignment'', ''right'');', newline],...
                };
            maskDisplayCmds = [maskDisplayCmds maskDisplayCmdsTarget];
        end
    end

    methods(Static, Access = protected)
        %% Simulink customization functions
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', 'TalkBack Read', 'Text', ...
                'Read from ThingSpeak TalkBack');
        end

        function group = getPropertyGroupsImpl
            % Define property section(s) for System block dialog
            blockPlatformProp = matlab.system.display.internal.Property('blockPlatform', 'Description', 'Block Platform','IsGraphical',false);
            talkBackUrlProp = matlab.system.display.internal.Property('TalkBackUrl', 'Description', 'TalkBack Url','IsGraphical',false);
            requiredGroup = matlab.system.display.Section(...
                'Title', 'Parameters',...
                'PropertyList', {'TalkBackMode', 'TalkBackID', 'APIKey', 'CommandType', 'CommandLength', ...
                'PrintDiagnosticMessages', 'SampleTime', blockPlatformProp, talkBackUrlProp});
            group = requiredGroup;
        end
        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
    end
    
     methods (Static)
        function name = getDescriptiveName(~)
            name = 'ThingSpeak Read';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            % Update the build-time buildInfo
            if context.isCodeGenTarget('rtw')
                % Header paths
                rootDir = realtime.internal.getLinuxRoot();
                buildInfo.addIncludePaths(fullfile(rootDir,'include'));
                buildInfo.addIncludeFiles('MW_thingspeak_talkback.h');
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    % Add the following when not in rapid-accel simulation
                    buildInfo.addSourceFiles('MW_thingspeak_talkback.c',fullfile(rootDir,'src'));
                    addLinkFlags(buildInfo,'-lcurl');
                    addLinkFlags(buildInfo,'-ljson-c');
                end
            end
        end
    end
end

%% Internal functions
function str = cstr(str)
str = [str(:).', char(0)];
end