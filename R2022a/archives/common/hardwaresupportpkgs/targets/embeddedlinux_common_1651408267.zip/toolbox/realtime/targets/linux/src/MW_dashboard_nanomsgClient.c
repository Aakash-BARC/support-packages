/* Copyright 2021 The MathWorks, Inc. */
#include "MW_dashboard_nanomsgClient.h"
#include "MW_JSONParser.h"

#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)
#define AT __FILE__ ":" TOSTRING(__LINE__)

static uint8_t ipcCreatedForSink = 0;
static uint8_t ipcCreatedForSource = 0;
static int pubSockID = 0;
static int subSockID = 0;

int MW_dashboardnanomsgClientPubInit() {
    if (!ipcCreatedForSink) {
        char url[255];
        sprintf(url, "ipc:///tmp/%s_dashblockSink.ipc", TOSTRING(MODEL));
        //printf("Pub URL = %s\n", url);
        int sock = nn_socket(AF_SP, NN_PUB);
        assert(sock >= 0);
        assert(nn_bind(sock, url) >= 0);

        ipcCreatedForSink = 1;
        pubSockID = sock;
    }
    return (pubSockID);
}

int MW_dashboardnanomsgClientSubInit() {
    if (!ipcCreatedForSource) {
        char url[255];
        sprintf(url, "ipc:///tmp/%s_dashblockSource.ipc", TOSTRING(MODEL));
        //printf("Sub URL = %s\n", url);
        int sock = nn_socket(AF_SP, NN_SUB);
        assert(sock >= 0);
        assert(nn_setsockopt(sock, NN_SUB, NN_SUB_SUBSCRIBE, "", 0) >= 0);
        assert(nn_connect(sock, url) >= 0);
        
        ipcCreatedForSource = 1;
        subSockID = sock;        
    }
    return (subSockID);
}

void MW_dashboardnanomsgClientRecv(int sock, char *blocklabelWithID, char** blockIDStr, double *data) {
    // Holding buffer
    static char* buf = NULL;
    char* blockLabelWithIDStr = NULL;
    static uint8_T isInitialized = 0;
    char* tmpBuf = NULL;
    char labelIDbufjson[32],labelIDbufsys[32];
    double tmpData;

    //printf("MW_dashboardnanomsgClientRecv called \n");
    int bytes = nn_recv(sock, &tmpBuf, NN_MSG, NN_DONTWAIT);
    if (bytes > 0) {
        // new data
        //printf("CLIENT (%s): RECEIVED %s\n", "webPub", tmpBuf);
        buf = tmpBuf; // update holding buffer to maintain state
        nn_freemsg(tmpBuf);
        isInitialized = 1;
    }
    if(isInitialized) {
        tmpData = MW_getDashboardSourceData(buf, blockIDStr, &blockLabelWithIDStr);
        if(!(blockLabelWithIDStr == NULL)) {
            sprintf(labelIDbufjson,"%s",blockLabelWithIDStr);
            //printf("LABELWITHIDJSON: %s\n",labelIDbufjson);
            snprintf(labelIDbufsys,strlen(labelIDbufjson)+1,"%s",blocklabelWithID);
            //printf("LABELWITHIDSYS: %s\n",labelIDbufsys);
            if(strcmp(labelIDbufjson,labelIDbufsys) == 0) {
                *data = tmpData;
            }
        }
    }
}

void MW_dashboardnanomsgClientSend(int sock, char* msg) {
    int sz_msg = strlen(msg); // '\0' too
    //printf ("SERVER Sock = %u: PUBLISHING Data  %s\n",sock,  msg);
    int bytes = nn_send(sock, msg, sz_msg, 0);
    assert(bytes == sz_msg);
}

void MW_dashboardnanomsgClientShutdown(int sock) {
    nn_close(sock);
}