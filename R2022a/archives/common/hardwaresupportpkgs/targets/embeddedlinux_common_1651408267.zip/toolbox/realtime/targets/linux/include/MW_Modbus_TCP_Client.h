/*
 * @filename: MW_Modbus_TCP_Client.h 
 *
 * @description: MODBUS TCP Client/Master for Linux targets
 *               Based on libmodbus library 
 *
 * @copyright: Copyright 2020 The MathWorks, Inc. 
 */

#ifndef _MW_MODBUS_TCP_CLIENT_H_
#define _MW_MODBUS_TCP_CLIENT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) || defined(RSIM_WITH_SL_SOLVER))
/* This will be run in Rapid Accelerator Mode */
#define MW_Modbus_Client_ReadCoil(server_ip, addr, data, status) (0)
#define MW_Modbus_Client_ReadInput(server_ip, addr, data, status) (0)
#define MW_Modbus_Client_ReadInputRegister(server_ip, addr, data, status) (0)
#define MW_Modbus_Client_ReadHoldingRegister(server_ip, addr, data, status) (0)
#define MW_Modbus_Client_ReadMultipleCoils(server_ip, addr, nb, data, status) (0)
#define MW_Modbus_Client_ReadMultipleInputs(server_ip, addr, nb, data, status) (0)
#define MW_Modbus_Client_ReadMultipleInputRegister(server_ip, addr, nb, data, status) (0)
#define MW_Modbus_Client_ReadMultipleHoldingRegister(server_ip, addr, nb, data, status) (0)
#define MW_Modbus_Client_WriteCoil(server_ip, addr, data, status) (0)
#define MW_Modbus_Client_WriteHoldingRegister(server_ip, addr, data, status) (0)
#define MW_Modbus_Client_WriteMultipleCoils(server_ip, addr, nb, data, status) (0)
#define MW_Modbus_Client_WriteMultipleHoldingRegister(server_ip, addr, nb, data, status) (0)
#define MW_Modbus_Client_InitializeClient(server_ip) (0)
#define MW_Modbus_Client_TerminateClient(server_ip) (0)
#else

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <modbus/modbus.h>
    
#ifdef __MW_TARGET_USE_HARDWARE_RESOURCES_H__
#include "MW_target_hardware_resources.h"
#endif

typedef struct _mb_client_connection_t
{
    char ip_address[16];
    int port;
    int is_connected;
    modbus_t *ctx;
} mb_client_connection_t;

void MW_Modbus_Client_ReadCoil(char *server_ip, uint16_t addr, uint8_t *data, int8_t *status);
void MW_Modbus_Client_ReadInput(char *server_ip, uint16_t addr, uint8_t *data, int8_t *status);
void MW_Modbus_Client_ReadInputRegister(char *server_ip, uint16_t addr, uint16_t *data, int8_t *status);
void MW_Modbus_Client_ReadHoldingRegister(char *server_ip, uint16_t addr, uint16_t *data, int8_t *status);
void MW_Modbus_Client_ReadMultipleCoils(char *server_ip, uint16_t addr, uint8_t nb, uint8_t *data, int8_t *status);
void MW_Modbus_Client_ReadMultipleInputs(char *server_ip, uint16_t addr, uint8_t nb, uint8_t *data, int8_t *status);
void MW_Modbus_Client_ReadMultipleInputRegister(char *server_ip, uint16_t addr, uint8_t nb, uint16_t *data, int8_t *status);
void MW_Modbus_Client_ReadMultipleHoldingRegister(char *server_ip, uint16_t addr, uint8_t nb, uint16_t *data, int8_t *status);
void MW_Modbus_Client_WriteCoil(char *server_ip, uint16_t addr, uint8_t *data, int8_t *status);
void MW_Modbus_Client_WriteHoldingRegister(char *server_ip, uint16_t addr, uint16_t *data, int8_t *status);
void MW_Modbus_Client_WriteMultipleCoils(char *server_ip, uint16_t addr, uint8_t nb, uint8_t *data, int8_t *status);
void MW_Modbus_Client_WriteMultipleHoldingRegister(char *server_ip, uint16_t addr, uint8_t nb, uint16_t *data, int8_t *status);
void MW_Modbus_Client_InitializeClient(char *server_ip);
void MW_Modbus_Client_TerminateClient(char *server_ip);
#endif

#ifdef __cplusplus
}
#endif
#endif //_MW_MODBUS_TCP_CLIENT_H_
