function [outData] = iotlibForwarding(inData)
    % IOTLIBFORWARDING maps parameters/values in old raspberrypi IOT library blocks to corresponding
    % parameter/values in new blocks.
    
    % Copyright 2021 The MathWorks, Inc.

    outData.NewBlockPath = '';
    outData.NewInstanceData = [];
    
    instanceData = inData.InstanceData;
    % Get the old block field type 'Name' from instanceData
    [ParameterNames{1:length(instanceData)}] = instanceData.Name;
    
    % If custom thingspeak URL is used, change to supported one.
    urlPropIndex = find(matches(ParameterNames,'UpdateURL'));
    if ~isempty(urlPropIndex)
        supportedURL = 'https://api.thingspeak.com/update';
        if ~matches(instanceData(urlPropIndex).Value,supportedURL)
            warning(message('linux:utils:ThingspeakWriteURLNotSupported'));
            instanceData(urlPropIndex).Value = supportedURL;
        end
    end
    outData.NewInstanceData = instanceData;
end