classdef ServoBase < handle
    %
    % Servo base class for linux targets.
    %
    
    % Copyright 2021 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCA>
    
    properties 
        Channel = 0;
        PulseDuration = [1000e-6 2000e-6];
    end
    
    methods
        % Constructor
        function obj = ServoBase(varargin)
            coder.allowpcode('plain');
            narginchk(1,2);

            if nargin == 1
                obj.setChannel(varargin{1});
            elseif nargin == 2
                obj.setPulseDuration(varargin{2});
            end
        end
        
        function setChannel(obj,value)
            validateattributes(value, {'numeric'},...
                {'real','nonnegative','integer','scalar'},'','PinNumber');
            obj.Channel = value;
        end

        function setPulseDuration(obj,value)
            validateattributes(value,{'numeric'},{'nonnan','finite','2d','positive',...
                'numel',2},'','''Pulse duration''');
            obj.PulseDuration = value;
        end
    end

end

