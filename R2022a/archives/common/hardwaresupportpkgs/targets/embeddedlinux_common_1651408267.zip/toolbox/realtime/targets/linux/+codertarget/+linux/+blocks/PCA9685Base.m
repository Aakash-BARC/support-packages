classdef PCA9685Base < handle
    %
    % PCA9685 base class for linux targets.
    %
    
    % Copyright 2021 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCA>
    
    properties 
        PWMFrequency = 50;
    end
    
    properties(Constant)
        NChannels = 16;
        MinFrequency = 24;
        MaxFrequency = 1526;
    end
    
    methods
        % Constructor
        function obj = PCA9685Base(varargin)
            coder.allowpcode('plain');
            narginchk(1,1);
        end
    end

    methods (Access=protected)
        function startPWM(obj)
        end

        function setPWM(obj,value)
        end

        function stopPWM(obj)
        end
    end
end

