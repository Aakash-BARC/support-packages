/* Copyright 2021 The MathWorks, Inc. */
/* MW_SocketCAN.c*/

#include "MW_SocketCAN.h"

#if !( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
// Code generation

#define MW_STR_EXPAND(tok) #tok
#define MW_STR(tok) MW_STR_EXPAND(tok)
#define MW_MAX_SIZE 1000
#define INT(x) (x)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For read/write data using Berkeley Sockets
#include <sys/ioctl.h>
#include <net/if.h> // For ifreq, ifname, etc
#include <linux/socket.h> // For PF_CAN Sockets
#include <linux/can.h> // For CAN structures
#include <linux/can/error.h> // CAN Error Handling
#include <linux/can/raw.h> // CAN Raw Sockets
#include <assert.h> // For asserting error
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <ifaddrs.h>
#include <sys/types.h>

/*Setup IP Link Functions*/
void MW_executeCommand(char_T* cmd){
    system(cmd);
}

void MW_printError(char_T* errString){
    fprintf(stderr,errString);
}

int32_T MW_bitrate(char_T* bitRate){
    #ifdef MW_CAN_BITRATE
    sprintf(bitRate,MW_STR(MW_CAN_BITRATE));
    return strlen(bitRate);
    #else
    return 0;
    #endif
}

void MW_setupCANLink(char_T* cmd,const uint8_T isRealCAN){
    MW_executeCommand(cmd);
}

int32_T MW_checkIFStatus(char_T* canInterface){
    struct ifaddrs *ifaddr, *ifa;
    int n,ifExists=0,isUP=0;
    if (getifaddrs(&ifaddr) == -1) {
        perror("getifaddrs");
        exit(EXIT_FAILURE);
    }

    for (ifa = ifaddr, n = 0; ifa != NULL; ifa = ifa->ifa_next, n++) 
    {
        int isCAN = !strcmp(ifa->ifa_name,canInterface);
        if(isCAN)
        {
            ifExists=1;
            isUP = ifa->ifa_flags & IFF_UP;
            break;
        }
    }

    freeifaddrs(ifaddr);

    if(!ifExists)
    {
        return (int32_T)MW_CAN_NOIF;
    }
    else if(!isUP)
    {
        return (int32_T)MW_CAN_NOTUP;
    }
    return (int32_T)MW_CAN_UP;
}

/* Setup Socket Functions */
int32_T MW_createSocket(char_T* canInterface, int32_T* sockHandle){
    struct ifreq ifr;
    struct sockaddr_can addr;

    if((*sockHandle = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0)
    {
        fprintf(stderr,"Error creating socket for %s.\n",canInterface);
        return (int32_T)MW_SOCK_CREATE_ERROR;
    }


    // Set the CAN Interface
    assert(strlen(canInterface) < IFNAMSIZ); // To avoid Buffer-Overflow
    strcpy(ifr.ifr_name, canInterface);

    if((ioctl(*sockHandle, SIOCGIFINDEX, &ifr))!=0)
    {
        fprintf(stderr,"Error setting socket interface for %s.\n",canInterface);
        return (int32_T)MW_SOCK_IOCTL_ERROR;
    }

    // CAN Interface
    addr.can_family  = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    if((bind(*sockHandle, (struct sockaddr *)&addr, sizeof(addr))) < 0)
    {
        fprintf(stderr,"Error binding the socket for %s.\n",canInterface);
        return (int32_T)MW_SOCK_BIND_ERROR;
    }

    return (int32_T)MW_SOCK_STATUS_OK;
}

/* Cleanup Functions */
int32_T MW_clearSocket(int32_T* sockHandle, char_T* canInterface)
{
    if(close(*sockHandle) < 0)
    {
        fprintf(stderr,"Error closing the socket for %s.\n",canInterface);
        return (int32_T)MW_SOCK_CLOSE_ERROR;
    }

    return (int32_T)MW_SOCK_STATUS_OK;
}


/* Blocking mode */
double MW_getTimeNow()
{
    struct timeval timeNow;
    double timeInSeconds;

    if(gettimeofday(&timeNow,NULL)==-1)
    {
        fprintf(stderr,"Error in gettimeofday\n");
        return -1;
    }
    else
    {
        timeInSeconds = timeNow.tv_sec + (timeNow.tv_usec/1000000.0);

        return timeInSeconds;
    }
}

/*Transmit Raw Data MATLAB I/O workflow*/
int32_T MW_CAN_transmitRaw_MATLABIO(const uint32_T identifier,
                                    const uint8_T idType,
                                    const uint8_T length,
                                    const uint8_T* data,
                                    const char* canInterface)
{
    /*----------------------- Initializations -------------------------------*/
    // Common Variables
    int s,i;
    struct sockaddr_can addr;
    struct can_frame frame;
    struct ifreq ifr;
    ssize_t nbytes;

    /*---------------------  Transmit data Frames ---------------------------*/
    // Create transmit socket
    if((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
        return -1;
    }

    // Set CAN Interface
    assert(strlen(canInterface) < IFNAMSIZ); // To avoid Buffer-Overflow
    strcpy(ifr.ifr_name, canInterface);
    if(ioctl(s, SIOCGIFINDEX, &ifr))
        return -1;
    addr.can_family  = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    if(bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        return -1;
    }

    // Set the CAN ID, Length and data of the message
    if(!idType)
    {
        // Extended Frame Format
        frame.can_id  = identifier + CAN_EFF_FLAG;
    }
    else
    {
        // Standard Frame Format
        frame.can_id  = identifier;
    }
    frame.can_dlc = length;
    memcpy(frame.data, data, frame.can_dlc * sizeof(uint8_T));

    // Perform write operation and check for issues
    nbytes = write(s, &frame, sizeof(struct can_frame));
    if(nbytes==-1)
        return -1;

    /*---------------------------- Cleanup ------------------------------*/
    if (close(s) < 0) {
        return -1;
    }
    return 0;
}


/*Transmit Raw Data as a CAN Frame into CAN Bus*/
int32_T MW_CAN_transmitRaw(const char* canInterface,
                           const uint8_T idType,
                           const uint32_T ID,
                           const uint8_T Length,
                           uint8_T* data,
                           const uint8_T rtr,
                           uint8_T *status,
                           const uint8_T isblocking,
                           const double blockTimeout, 
                           int32_T sockHandleDataFrames, 
                           int32_T sockHandleErrorFrames, 
                           const uint8_T notFirstStep)
{
    /*----------------------- Initializations -------------------------------*/
    // Common Variables
    int i,s_recvErrors=0,recv_own_msgs,iMode=1;
    struct can_frame frame,frdup,frame_recv;
    int errCode = 0;
    struct can_filter rfilter_errorFrames[1];
    ssize_t nbytes;
    struct timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 1;
    
    double startTime,endTime;
    struct iovec iov;
    struct msghdr msg;
    char ctrlmsg[CMSG_SPACE(sizeof(struct timeval) + 3 * sizeof(struct timespec) + sizeof(__u32))];

    struct sockaddr_can addr1;
    struct ifreq ifr1;
    strcpy(ifr1.ifr_name, canInterface);

    memset(&addr1, 0, sizeof(addr1));
    addr1.can_family = AF_CAN;
    addr1.can_ifindex = ifr1.ifr_ifindex;

    /*---------------------  Transmit data Frames ---------------------------*/

    // Set the CAN ID, Length and data of the message
    if(!idType)
    {
        // Extended Frame Format
        if(rtr==0) // data Frame Request
        {
            frame.can_id  = ID + CAN_EFF_FLAG;
        }
        else // Remote Frame Request
        {
            frame.can_id  = ID + CAN_EFF_FLAG + CAN_RTR_FLAG;
        }
    }
    else
    {
        // Standard Frame Format
        if(rtr==0) // data Frame Request
        {
            frame.can_id  = ID;
        }
        else // Remote Frame Request
        {
            frame.can_id  = ID + CAN_RTR_FLAG;
        }
    }
    frame.can_dlc = Length;
    memcpy(frame.data, data, frame.can_dlc * sizeof(uint8_T));

    recv_own_msgs = 1;
    setsockopt(sockHandleDataFrames, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS,
               &recv_own_msgs, sizeof(recv_own_msgs));
    iov.iov_base = &frame_recv;
    msg.msg_name = &addr1;
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    msg.msg_control = &ctrlmsg;

    iov.iov_len = sizeof(frame_recv);
    msg.msg_namelen = sizeof(addr1);
    msg.msg_controllen = sizeof(ctrlmsg);
    msg.msg_flags = 0;


    *status = 0;
    
    // Set Non-blocking Mode in Socket
    ioctl(sockHandleDataFrames, FIONBIO, &iMode);

    if(isblocking==1 && notFirstStep==1) // Only block from second time step
    {
        // Wait Until Data Sent
        startTime = MW_getTimeNow();
        endTime = MW_getTimeNow();
        while(endTime-startTime < blockTimeout)
        {
            nbytes = recvmsg(sockHandleDataFrames, &msg, 0);
            if ((msg.msg_flags & MSG_CONFIRM)==MSG_CONFIRM)
            {
                break;
            }
            endTime = MW_getTimeNow();
        }
        nbytes = write(sockHandleDataFrames, &frame, sizeof(struct can_frame));
    }
    else
    {
        // Transmit irrespective of the status of previous transmission
        nbytes = write(sockHandleDataFrames, &frame, sizeof(struct can_frame));
    }

    /*---------------------  Output Status of the Transmission --------------*/


    // Allow only error frames and filter out the data frames
    rfilter_errorFrames[0].can_id = CAN_ERR_FLAG;
    rfilter_errorFrames[0].can_mask = ~CAN_ERR_MASK;
    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_errorFrames, sizeof(rfilter_errorFrames))==-1)
    {
        fprintf(stderr,"Error setting the socket filter for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_FILTER_ERROR;
    }


    // Error Mask for fetching error frames
    can_err_mask_t err_mask = CAN_ERR_MASK;
    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_ERR_FILTER, &err_mask, sizeof(err_mask))==-1)
    {
        fprintf(stderr,"Error setting the socket error mask for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_ERRMASK_ERROR;
    }

    // Set Non-blocking Mode in Socket
    ioctl(sockHandleErrorFrames, FIONBIO, &iMode);

    // Read Error Frames
    if(read(sockHandleErrorFrames, &frdup, sizeof(frdup)) != -1)
    {
        if (frdup.data[1] & CAN_ERR_CRTL_TX_WARNING == CAN_ERR_CRTL_TX_WARNING)
        {
            *status += 1<<TXWAR; // TXWAR bit
        }
        if (frdup.data[1] & CAN_ERR_CRTL_TX_PASSIVE == CAN_ERR_CRTL_TX_PASSIVE)
        {
            *status += 1<<TXEP; // TXEP bit
        }
        if (frdup.can_id & CAN_ERR_BUSOFF == CAN_ERR_BUSOFF) {
            *status += 1<<TXBO; // TXBO bit
        }
        if (frdup.data[1] & CAN_ERR_PROT_TX == CAN_ERR_PROT_TX)
        {
            *status += 1<<TXERR; // TXERR bit
        }
        if (frdup.can_id & CAN_ERR_LOSTARB == CAN_ERR_LOSTARB) {
            *status += 1<<MLOA; // MLOA bit
        }
    }
    return MW_SOCK_STATUS_OK;
}

/*Transmit CAN Msg structure as a CAN Frame into CAN Bus*/
int32_T MW_CAN_transmitCANMsg(const char* canInterface,
                              uint8_T idType,
                              uint32_T ID,
                              uint8_T Length,
                              uint8_T* data,
                              const uint8_T rtr,
                              uint8_T* status,
                              const uint8_T isblocking,
                              const double blockTimeout,
                              int32_T sockHandleDataFrames, 
                              int32_T sockHandleErrorFrames, 
                              const uint8_T notFirstStep)
{
    /*----------------------- Initializations ---------------------------*/
    // Common Variables
    int i,recv_own_msgs=0,iMode=1;
    struct can_frame frame,frdup,frame_recv;
    struct can_filter rfilter_errorFrames[1];
    ssize_t nbytes;
    struct timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 100;

    double startTime,endTime;
    struct iovec iov;
    struct msghdr msg;
    char ctrlmsg[CMSG_SPACE(sizeof(struct timeval) + 3 * sizeof(struct timespec) + sizeof(__u32))];

    struct sockaddr_can addr1;
    struct ifreq ifr1;
    strcpy(ifr1.ifr_name, canInterface);

    memset(&addr1, 0, sizeof(addr1));
    addr1.can_family = AF_CAN;
    addr1.can_ifindex = ifr1.ifr_ifindex;

    /*---------------------  Transmit Data Frames ---------------------------*/

    // Set the CAN ID, Length and Data of the message
    if(!idType)
    {
        // Extended Frame Format
        if(rtr==0) // Data Frame Request
        {
            frame.can_id  = ID + CAN_EFF_FLAG;
        }
        else // Remote Frame Request
        {
            frame.can_id  = ID + CAN_EFF_FLAG + CAN_RTR_FLAG;
        }
    }
    else
    {
        // Standard Frame Format
        if(rtr==0) // Data Frame Request
        {
            frame.can_id  = ID;
        }
        else // Remote Frame Request
        {
            frame.can_id  = ID + CAN_RTR_FLAG;
        }
    }
    frame.can_dlc = Length;
    memcpy(frame.data, data, frame.can_dlc*sizeof(uint8_T));

    recv_own_msgs = 1;
    setsockopt(sockHandleDataFrames, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS,
               &recv_own_msgs, sizeof(recv_own_msgs));
    iov.iov_base = &frame_recv;
    msg.msg_name = &addr1;
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    msg.msg_control = &ctrlmsg;

    iov.iov_len = sizeof(frame_recv);
    msg.msg_namelen = sizeof(addr1);
    msg.msg_controllen = sizeof(ctrlmsg);
    msg.msg_flags = 0;
    
    // Set Non-blocking Mode in Socket
    ioctl(sockHandleDataFrames, FIONBIO, &iMode);

    *status = 0;
    if(isblocking==1 && notFirstStep==1) // Only block from second time step
    {
        // Wait Until Data Sent
        startTime = MW_getTimeNow();
        endTime = MW_getTimeNow();
        while(endTime-startTime < blockTimeout)
        {
            nbytes = recvmsg(sockHandleDataFrames, &msg, 0);
            if ((msg.msg_flags & MSG_CONFIRM)==MSG_CONFIRM)
            {
                break;
            }
            endTime = MW_getTimeNow();
        }
        nbytes = write(sockHandleDataFrames, &frame, sizeof(struct can_frame));
    }
    else
    {
        // Transmit irrespective of the status of previous transmission
        nbytes = write(sockHandleDataFrames, &frame, sizeof(struct can_frame));
    }

    /*----------------------- Output Status of the Transmission -------------*/


    // Filter out the data frames
    rfilter_errorFrames[0].can_id = CAN_ERR_FLAG;
    rfilter_errorFrames[0].can_mask = ~CAN_ERR_MASK;
    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_errorFrames, sizeof(rfilter_errorFrames))==-1)
    {
        fprintf(stderr,"Error setting the socket filter for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_FILTER_ERROR;
    }

    // Set Error Mask
    can_err_mask_t err_mask = CAN_ERR_MASK;
    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_ERR_FILTER, &err_mask, sizeof(err_mask))==-1)
    {
        fprintf(stderr,"Error setting the socket error mask for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_ERRMASK_ERROR;
    }

    // Set Non-blocking Mode in Socket
    ioctl(sockHandleErrorFrames, FIONBIO, &iMode);

    // Read Error Frames
    if(read(sockHandleErrorFrames, &frdup, sizeof(frdup))!=-1)
    {
        if (frdup.data[1] & CAN_ERR_CRTL_TX_WARNING == CAN_ERR_CRTL_TX_WARNING)
        {
            *status += 1<<TXWAR; // TXWAR bit
        }
        if (frdup.data[1] & CAN_ERR_CRTL_TX_PASSIVE == CAN_ERR_CRTL_TX_PASSIVE)
        {
            *status += 1<<TXEP; // TXEP bit
        }
        if (frdup.can_id & CAN_ERR_BUSOFF == CAN_ERR_BUSOFF) {
            *status += 1<<TXBO; // TXBO bit
        }
        if (frdup.data[1] & CAN_ERR_PROT_TX == CAN_ERR_PROT_TX)
        {
            *status += 1<<TXERR; // TXERR bit
        }
        if (frdup.can_id & CAN_ERR_LOSTARB == CAN_ERR_LOSTARB) {
            *status += 1<<MLOA; // MLOA bit
        }
    }

    return MW_SOCK_STATUS_OK;
}

/*Receive for MATLAB I/O*/
int32_T MW_CAN_receiveRawMATLAB(const uint32_T numMessages,
                                const char_T* canInterface, uint8_T* data)
{
    // Initialization
    int s,i;
    ssize_t nbytes;
    int status;
    struct sockaddr_can addr;
    struct ifreq ifr;
    struct can_frame frame[numMessages];
    uint8_T index;
    struct can_filter rfilter_allowAllExceptRemoteFrames[1];

    // CAN Filter for MATLAB I/O allows all Messages except Remote Frames
    rfilter_allowAllExceptRemoteFrames[0].can_id = CAN_RTR_FLAG + CAN_INV_FILTER;
    rfilter_allowAllExceptRemoteFrames[0].can_mask = CAN_RTR_FLAG;

    // Create Socket
    if((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
        perror("socket");
        return 1;
    }

    strcpy(ifr.ifr_name, canInterface);

    if (ioctl(s, SIOCGIFINDEX, &ifr) < 0)
    {
        perror("SIOCGIFINDEX");
        return 1;
    }

    memset(&addr, 0, sizeof(addr));
    addr.can_family  = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    if(bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind error");
        return 1;
    }

    setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_allowAllExceptRemoteFrames, sizeof(rfilter_allowAllExceptRemoteFrames));

    // Fetch Error message
    can_err_mask_t err_mask = CAN_ERR_MASK;
    if(setsockopt(s, SOL_CAN_RAW, CAN_RAW_ERR_FILTER, &err_mask, sizeof(err_mask))==-1)
        return -1;

    // Set timeout to read between successive CAN frames
    struct timeval timeout;
    timeout.tv_sec = 1;
    timeout.tv_usec = 0;
    if(setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout))==-1)
        return -1;

    for(index=0;index<numMessages;index++)
    {
        nbytes = read(s, &frame[index], sizeof(struct can_frame));

        if ((nbytes < 0) || (nbytes < sizeof(struct can_frame)))
        {
            perror("Read error: either no frame or incomplete frame");
            return -1;
        }

        *(uint32_T *)data = frame[index].can_id;
        data = data+sizeof(uint32_T);

        *data = (uint8_T)frame[index].can_dlc;
        data++;

        for (uint8_T i = 0; i < frame[index].can_dlc; i++)
        {
            *data = frame[index].data[i];
            data++;
        }
    }

    if (close(s) < 0) {
        perror("SocketClose");
        return -1;
    }

    return 0;
}

/*Receive a CAN Frame as Raw Data from CAN Bus*/
int32_T MW_CAN_receiveRawSimulink(const char* canInterface,
                                  const uint32_T id,
                                  uint8_T* data,
                                  const uint8_T dataLength,
                                  uint8_T* status,
                                  const uint8_T extended,
                                  uint8_T* remote, uint8_T* error,
                                  int32_T sockHandleDataFrames, 
                                  int32_T sockHandleErrorFrames)
{
    /*----------------------- Initializations -------------------------------*/
    // Common Variables
    int i,recvCriteria1=0,recvCriteria2=0,iMode = 1;
    ssize_t nbytes;
    struct sockaddr_can addr1;
    struct can_frame frame,frameError;
    struct ifreq ifr1;
    struct timeval timeout_data;
    timeout_data.tv_sec = 0;
    timeout_data.tv_usec = 1;

    struct timeval timeout_error;
    timeout_error.tv_sec = 0;
    timeout_error.tv_usec = 1;

    /*----------------------- Output Data Frames ----------------------------*/

    // Set up the filtering environment for the Socket
    #ifdef MW_CAN_ALLOWALLMSGS
    if(MW_CAN_ALLOWALLMSGS==1)
    {
        // Allow all messages
        struct can_filter rfilter_allowAll[1];
        if(extended)
        {
            //Extended Frame Format Filter
            rfilter_allowAll[0].can_id   = id | CAN_EFF_FLAG;
            rfilter_allowAll[0].can_mask = (CAN_EFF_FLAG |CAN_EFF_MASK);
        }
        else
        {
            //Standard Frame Format Filter
            rfilter_allowAll[0].can_id   = id;
            rfilter_allowAll[0].can_mask = (CAN_EFF_FLAG | CAN_SFF_MASK);
        }
        if(setsockopt(sockHandleDataFrames, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_allowAll, sizeof(rfilter_allowAll))==-1)
        {
            fprintf(stderr,"Error setting the socket filter for %s.\n",canInterface);
            return MW_SOCK_SETSOCKOPT_FILTER_ERROR;
        }
    }
    else
    {
        // Allow Only some Messages
        struct can_filter rfilter_notAll[4];

        // CAN Filter 1
        #ifdef MW_CAN_IDTYPE0
        if(MW_CAN_IDTYPE0==0)
        {
            if(MW_CAN_INVFILTER0==1)
                rfilter_notAll[0].can_id = MW_CAN_ACCEPTANCEFILTER0 + CAN_INV_FILTER;
            else
                rfilter_notAll[0].can_id = MW_CAN_ACCEPTANCEFILTER0;
            rfilter_notAll[0].can_mask = MW_CAN_ACCEPTANCEMASK0 | CAN_EFF_FLAG; 
        }
        else
        {
            if(MW_CAN_INVFILTER0==1)
                rfilter_notAll[0].can_id   = MW_CAN_ACCEPTANCEFILTER0 | CAN_EFF_FLAG + CAN_INV_FILTER;
            else
                rfilter_notAll[0].can_id   = MW_CAN_ACCEPTANCEFILTER0 | CAN_EFF_FLAG;
            rfilter_notAll[0].can_mask = MW_CAN_ACCEPTANCEMASK0 | CAN_EFF_FLAG; 
        }
        #endif

        // CAN Filter 2
        #ifdef MW_CAN_IDTYPE1
        if(MW_CAN_IDTYPE1==0)
        {
            if(MW_CAN_INVFILTER1==1)
                rfilter_notAll[1].can_id = MW_CAN_ACCEPTANCEFILTER1 + CAN_INV_FILTER;
            else
                rfilter_notAll[1].can_id = MW_CAN_ACCEPTANCEFILTER1;
            rfilter_notAll[1].can_mask = MW_CAN_ACCEPTANCEMASK1 | CAN_EFF_FLAG; 
        }
        else
        {
            if(MW_CAN_INVFILTER1==1)
                rfilter_notAll[1].can_id   = MW_CAN_ACCEPTANCEFILTER1 | CAN_EFF_FLAG + CAN_INV_FILTER;
            else
                rfilter_notAll[1].can_id   = MW_CAN_ACCEPTANCEFILTER1 | CAN_EFF_FLAG;
            rfilter_notAll[1].can_mask = MW_CAN_ACCEPTANCEMASK1 | CAN_EFF_FLAG; 
        }
        #endif

        // CAN Filter 3
        #ifdef MW_CAN_IDTYPE2
        if(MW_CAN_IDTYPE2==0)
        {
            if(MW_CAN_INVFILTER2==1)
            {
                rfilter_notAll[2].can_id = MW_CAN_ACCEPTANCEFILTER2 + CAN_INV_FILTER;
            }
            else
                rfilter_notAll[2].can_id = MW_CAN_ACCEPTANCEFILTER2;
            rfilter_notAll[2].can_mask = MW_CAN_ACCEPTANCEMASK2 | CAN_EFF_FLAG; 
        }
        else
        {
            if(MW_CAN_INVFILTER2==1)
            {
                rfilter_notAll[2].can_id   = MW_CAN_ACCEPTANCEFILTER2 | CAN_EFF_FLAG + CAN_INV_FILTER;
            }
            else
                rfilter_notAll[2].can_id   = MW_CAN_ACCEPTANCEFILTER2 | CAN_EFF_FLAG;
            rfilter_notAll[2].can_mask = MW_CAN_ACCEPTANCEMASK2 | CAN_EFF_FLAG; 
        }
        #endif

        // CAN Filter 4
        #ifdef MW_CAN_IDTYPE3
        if(MW_CAN_IDTYPE3==0)
        {
            if(MW_CAN_INVFILTER3==1)
                rfilter_notAll[3].can_id = MW_CAN_ACCEPTANCEFILTER3 + CAN_INV_FILTER;
            else
                rfilter_notAll[3].can_id = MW_CAN_ACCEPTANCEFILTER3;
            rfilter_notAll[3].can_mask = MW_CAN_ACCEPTANCEMASK3 | CAN_EFF_FLAG; 
        }
        else
        {
            if(MW_CAN_INVFILTER3==1)
                rfilter_notAll[3].can_id   = MW_CAN_ACCEPTANCEFILTER3 | CAN_EFF_FLAG + CAN_INV_FILTER;
            else
                rfilter_notAll[3].can_id   = MW_CAN_ACCEPTANCEFILTER3 | CAN_EFF_FLAG;
            rfilter_notAll[3].can_mask = MW_CAN_ACCEPTANCEMASK3 | CAN_EFF_FLAG; 
        }
        #endif

        if(setsockopt(sockHandleDataFrames, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_notAll, sizeof(rfilter_notAll))==-1)
        {
            fprintf(stderr,"Error setting the socket filter for %s.\n",canInterface);
            return MW_SOCK_SETSOCKOPT_FILTER_ERROR;
        }
    }
    #endif
    
    // Set Non-blocking Mode in Socket
    ioctl(sockHandleDataFrames, FIONBIO, &iMode);

    // Read a data frame
    nbytes = read(sockHandleDataFrames, &frame, sizeof(struct can_frame));
    if(nbytes==-1 || nbytes<sizeof(struct can_frame))
    {
        *status = 0;
        for(i=0;i<8;i++)
            data[i] = 0;
    }
    else
    {
        recvCriteria1 = (extended==1) && ((frame.can_id==id+CAN_EFF_FLAG) || (frame.can_id==id+CAN_EFF_FLAG+CAN_RTR_FLAG));
        recvCriteria2 = (extended==0) && ((frame.can_id==id) || (frame.can_id==id+CAN_RTR_FLAG));
        if(recvCriteria1==1 || recvCriteria2==1)
        {
            *status = 1;
            memcpy(data, frame.data, sizeof(frame.data));
        }
        else
        {
            *status = 0;
            for(i=0;i<8;i++)
                data[i] = 0;
        }
    }

    /*----------------------- Output Remote ---------------------------------*/

    // Output Remote
    if(*status==1)
        remote[0] = (uint8_T)((frame.can_id & ( 1 << 30 )) >> 30);
    else
        remote[0] = 0;

    /*----------------------- Output Error ----------------------------------*/

    // Error Frames
    struct can_filter rfilter_errorFrames[1];

    rfilter_errorFrames[0].can_id   = CAN_ERR_FLAG;
    rfilter_errorFrames[0].can_mask = ~CAN_ERR_MASK;

    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_errorFrames, sizeof(rfilter_errorFrames))==-1)
    {
        fprintf(stderr,"Error setting socket filter for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_FILTER_ERROR;
    }

    // Fetch Error message
    can_err_mask_t err_mask = CAN_ERR_MASK;
    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_ERR_FILTER, &err_mask, sizeof(err_mask))==-1)
    {
        fprintf(stderr,"Error setting socket error mask for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_ERRMASK_ERROR;
    }

    // Set Non-blocking Mode in Socket
    ioctl(sockHandleErrorFrames, FIONBIO, &iMode);

    nbytes = read(sockHandleErrorFrames, &frameError,sizeof(struct can_frame));

    *error = 0;
    if(nbytes==-1 || nbytes<sizeof(struct can_frame))
    {
        *error = 0;
    }
    else
    {
        // Error bit check
        if(frameError.data[1] & CAN_ERR_CRTL_RX_OVERFLOW )
        {
            *error += 1<<0;
        }
        if(frameError.data[1] & CAN_ERR_CRTL_RX_PASSIVE )
        {
            *error += 1<<1;
        }
        if(frameError.data[1] & CAN_ERR_CRTL_RX_WARNING )
        {
            *error += 1<<2;
        }
    }

    return MW_SOCK_STATUS_OK;
}

/*Receive a CAN Frame as CAN Msg structure from CAN Bus*/
int32_T MW_CAN_receiveCANMsg(const char* canInterface, uint32_T* id, 
                             uint8_T* data, uint8_T* dataLength, 
                             uint8_T* status, uint8_T* extended, 
                             uint8_T* remote, uint8_T* error, 
                             int32_T sockHandleDataFrames,
                             int32_T sockHandleErrorFrames)
{
        /*----------------------- Initializations -------------------------------*/
    int i,iMode=1;
    ssize_t nbytes;
    struct sockaddr_can addr1;
    struct can_frame frame,frameError;
    frame.can_dlc = 8;
    struct ifreq ifr1;

    // Time out for no message state, non-blocking mode
    assert(strlen(canInterface) < IFNAMSIZ); // To avoid Buffer-Overflow
    struct timeval timeout_data;
    timeout_data.tv_sec = 0;
    timeout_data.tv_usec = 190000;

    struct timeval timeout_error;
    timeout_error.tv_sec = 0;
    timeout_error.tv_usec = 100;

    /*----------------------- Output Data Frames ----------------------------*/
    
    // SFF and EFF, CAN Filters
    #ifdef MW_CAN_ALLOWALLMSGS
    if(MW_CAN_ALLOWALLMSGS==0)
    {
        // Allow Only some Messages
        struct can_filter rfilter_notAll[4];
        #ifdef MW_CAN_IDTYPE0
        if(MW_CAN_IDTYPE0==0)
        {
            #ifdef MW_CAN_INVFILTER0
            if(MW_CAN_INVFILTER0==1)
                rfilter_notAll[0].can_id = MW_CAN_ACCEPTANCEFILTER0 + CAN_INV_FILTER;
            else
                rfilter_notAll[0].can_id = MW_CAN_ACCEPTANCEFILTER0;
            #endif
            rfilter_notAll[0].can_mask = MW_CAN_ACCEPTANCEMASK0 | CAN_EFF_FLAG;
        }
        else
        {
            #ifdef MW_CAN_INVFILTER0
            if(MW_CAN_INVFILTER0==1)
                rfilter_notAll[0].can_id   = MW_CAN_ACCEPTANCEFILTER0 | CAN_EFF_FLAG + CAN_INV_FILTER;
            else
                rfilter_notAll[0].can_id   = MW_CAN_ACCEPTANCEFILTER0 | CAN_EFF_FLAG;
            #endif
            rfilter_notAll[0].can_mask = (MW_CAN_ACCEPTANCEMASK0 | CAN_EFF_FLAG);
        }
        #endif

        #ifdef MW_CAN_IDTYPE1
        if(MW_CAN_IDTYPE1==0)
        {
            #ifdef MW_CAN_INVFILTER1
            if(MW_CAN_INVFILTER1==1)
                rfilter_notAll[1].can_id = MW_CAN_ACCEPTANCEFILTER1 + CAN_INV_FILTER;
            else
                rfilter_notAll[1].can_id = MW_CAN_ACCEPTANCEFILTER1;
            #endif
            rfilter_notAll[1].can_mask = MW_CAN_ACCEPTANCEMASK1 | CAN_EFF_FLAG;
        }
        else
        {
            #ifdef MW_CAN_INVFILTER1
            if(MW_CAN_INVFILTER1==1)
                rfilter_notAll[1].can_id   = MW_CAN_ACCEPTANCEFILTER1 | CAN_EFF_FLAG + CAN_INV_FILTER;
            else
                rfilter_notAll[1].can_id   = MW_CAN_ACCEPTANCEFILTER1 | CAN_EFF_FLAG;
            #endif
            rfilter_notAll[1].can_mask = (MW_CAN_ACCEPTANCEMASK1 | CAN_EFF_FLAG);
        }
        #endif

        #ifdef MW_CAN_IDTYPE2
        if(MW_CAN_IDTYPE2==0)
        {
            #ifdef MW_CAN_INVFILTER2
            if(MW_CAN_INVFILTER2==1)
            {
                rfilter_notAll[2].can_id = MW_CAN_ACCEPTANCEFILTER2 + CAN_INV_FILTER;
            }
            else
                rfilter_notAll[2].can_id = MW_CAN_ACCEPTANCEFILTER2;
            #endif
            rfilter_notAll[2].can_mask = MW_CAN_ACCEPTANCEMASK2 | CAN_EFF_FLAG;
        }
        else
        {
            #ifdef MW_CAN_INVFILTER2
            if(MW_CAN_INVFILTER2==1)
            {
                rfilter_notAll[2].can_id   = MW_CAN_ACCEPTANCEFILTER2 | CAN_EFF_FLAG + CAN_INV_FILTER;
            }
            else
                rfilter_notAll[2].can_id   = MW_CAN_ACCEPTANCEFILTER2 | CAN_EFF_FLAG;
            #endif
            rfilter_notAll[2].can_mask = (MW_CAN_ACCEPTANCEMASK2 | CAN_EFF_FLAG);// |CAN_EFF_MASK);
        }
        #endif

        #ifdef MW_CAN_IDTYPE3
        if(MW_CAN_IDTYPE3==0)
        {
            #ifdef MW_CAN_INVFILTER3
            if(MW_CAN_INVFILTER3==1)
                rfilter_notAll[3].can_id = MW_CAN_ACCEPTANCEFILTER3 + CAN_INV_FILTER;
            else
                rfilter_notAll[3].can_id = MW_CAN_ACCEPTANCEFILTER3;
            #endif
            rfilter_notAll[3].can_mask = MW_CAN_ACCEPTANCEMASK3 | CAN_EFF_FLAG;
        }
        else
        {
            #ifdef MW_CAN_INVFILTER3
            if(MW_CAN_INVFILTER3==1)
                rfilter_notAll[3].can_id   = MW_CAN_ACCEPTANCEFILTER3 | CAN_EFF_FLAG + CAN_INV_FILTER;
            else
                rfilter_notAll[3].can_id   = MW_CAN_ACCEPTANCEFILTER3 | CAN_EFF_FLAG;
            #endif
            rfilter_notAll[3].can_mask = (MW_CAN_ACCEPTANCEMASK3 | CAN_EFF_FLAG);// |CAN_EFF_MASK);
        }
        #endif
        if(setsockopt(sockHandleDataFrames, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_notAll, sizeof(rfilter_notAll))==-1)
        {
            fprintf(stderr,"Error setting the socket filter for %s.\n",canInterface);
            return MW_SOCK_SETSOCKOPT_FILTER_ERROR;
        }
    }
    #endif


    // Set Non-blocking Mode in Socket
    ioctl(sockHandleDataFrames, FIONBIO, &iMode);

    // Perform read for a CAN Frame
    nbytes = read(sockHandleDataFrames, &frame, sizeof(struct can_frame));
    if (nbytes == -1 || nbytes<sizeof(struct can_frame)) {
        // No CAN Frame Received
        *status = 0;
    }
    else
    {
        // CAN Frame Received
        memcpy(data, frame.data, sizeof(frame.data));
        *status = 1;
    }

    // Get the CAN ID, Data length, Remote Flag and Extended Flag of the CAN Frame
    id[0] = frame.can_id;
    dataLength[0] = frame.can_dlc;
    remote[0] = (uint8_T)((id[0] & ( 1 << 30 )) >> 30);
    if(remote[0]==1)
    {
        // If it is a remote frame, force the data to be all zeros
        for(i=0;i<8;i++)
            data[i]=0;
    }
    extended[0] = (uint8_T)((id[0] & ( 1 << 31 )) >> 31);
    if(extended[0]==1)
        id[0] = id[0] - CAN_EFF_FLAG;

    /*----------------------- Output Error ---------------------------------*/
    // Error Frames
    struct can_filter rfilter_errorFrames[1];

    rfilter_errorFrames[0].can_id   = CAN_ERR_FLAG;
    rfilter_errorFrames[0].can_mask = ~CAN_ERR_MASK;

    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter_errorFrames, sizeof(rfilter_errorFrames))==-1)
    {
        fprintf(stderr,"Error setting the socket filter for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_FILTER_ERROR;
    }

    // Fetch Error message
    can_err_mask_t err_mask = CAN_ERR_MASK;
    if(setsockopt(sockHandleErrorFrames, SOL_CAN_RAW, CAN_RAW_ERR_FILTER, &err_mask, sizeof(err_mask))==-1)
    {
        fprintf(stderr,"Error setting the socket error mask for %s.\n",canInterface);
        return MW_SOCK_SETSOCKOPT_ERRMASK_ERROR;
    }

    // Set Non-blocking Mode in Socket
    ioctl(sockHandleErrorFrames, FIONBIO, &iMode);

    nbytes = read(sockHandleErrorFrames, &frameError,sizeof(struct can_frame));

    *error = 0;
    if(nbytes==-1 || nbytes<sizeof(struct can_frame))
    {
        *error = 0;
    }
    else
    {
        // Error bit check
        if(frameError.data[1] & CAN_ERR_CRTL_RX_OVERFLOW )
        {
            *error += 1<<0;
        }
        if(frameError.data[1] & CAN_ERR_CRTL_RX_PASSIVE )
        {
            *error += 1<<1;
        }
        if(frameError.data[1] & CAN_ERR_CRTL_RX_WARNING )
        {
            *error += 1<<2;
        }
    }

    return MW_SOCK_STATUS_OK;
}


#endif
/* [EOF] */