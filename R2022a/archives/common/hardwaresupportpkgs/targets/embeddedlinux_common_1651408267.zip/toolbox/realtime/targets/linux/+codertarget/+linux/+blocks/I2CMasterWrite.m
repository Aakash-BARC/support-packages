classdef I2CMasterWrite < matlabshared.svd.I2CMasterWrite ...
        & coder.ExternalDependency
    %I2CMasterWrite Write data to an I2C slave device or an I2C slave device register.
    %
    %The block accepts a 1-D array of type uint8.
    %
    % Copyright 2020 The MathWorks, Inc.
    %#codegen
    properties (Nontunable)
        %I2CModule I2C module
        I2CModule = '0';
    end
    
    methods
        function obj = I2CMasterWrite(varargin)
            obj.Logo = 'LINUX';
        end
    end
       
    methods(Static, Access=protected)
        function [groups, PropertyList] = getPropertyGroupsImpl
            [~, PropertyListOut] = matlabshared.svd.I2CBlock.getPropertyGroupsImpl;
            
            % Create mask display
            Group = matlab.system.display.Section(...
                'PropertyList',PropertyListOut);
            
            groups = Group;
            % Output property list if requested
            if nargout > 1
                PropertyList = PropertyListOut;
            end
        end
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'I2C Master Read';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context) %#ok<INUSD>
        end
    end
end
%[EOF]
