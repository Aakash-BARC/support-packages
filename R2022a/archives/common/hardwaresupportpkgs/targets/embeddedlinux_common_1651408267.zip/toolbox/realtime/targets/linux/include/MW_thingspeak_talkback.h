#ifndef _MW_THINGSPEAK_TALKBACK_H_
#define _MW_THINGSPEAK_TALKBACK_H_

#include "rtwtypes.h"

#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
//no includes required 
#else

#include <stdio.h>          // Required by IO like printf
#include <stdlib.h>         // Required by malloc  
#include <string.h>         // Required by strlen 
#include <pthread.h>        // Required by pthreads
#include <curl/curl.h>      // Required by libcurl
#include <json-c/json.h>    // Required by json parsing 

#endif //MATLAB_MEX_FILE

#ifdef __cplusplus
extern "C" {
#endif  
    
#define ADD_COMMAND 1
#define DELETE_COMMAND 2

#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
#define TBReadData_t void
    
#define MW_talkback_init(a,b,c,d) (0)
#define MW_talkBack_int2string(a,b) (0)
#define MW_talkBack_terminate(a) (0) 
    
#define MW_talkBack_readInit(a,b) (0)
#define MW_talkBack_readCommand(a,b,c) (0)

#define MW_talkBack_writeHandle(a,b,c,d,e) (0)
#define MW_talkBack_addCommand(a,b,c,d) (0)
#define MW_talkBack_deleteAll(a) (0)
    
#else
    
typedef struct {
    char *dataReceived;
    size_t size;
} TBReadChunk_t;    

typedef struct {
    CURL *curl_handle;
    boolean_T printDiagnosticMessages;
	TBReadChunk_t dataRead;
} TBReadData_t;
    
// Common API    
void MW_talkback_init(const char *talkBackApi, const char *talkBackID, const char *APIKey, const boolean_T printDiagnosticMessages);
void MW_talkBack_int2string(int channelNum, char *channelNumStr);
void MW_talkBack_terminate(TBReadData_t *TBReadDataPtr);
    
// TalkBack Read API       
TBReadData_t *MW_talkBack_readInit(const char *TBReadUrl, boolean_T printDiagnosticMessages);
int MW_talkBack_readCommand(TBReadData_t *TBReadDataPtr, uint8_T *command, int cmdLen);

        
// TalkBack Write API
TBReadData_t *MW_talkBack_writeHandle(const char* talkBackApi, const char* talkBackID, const char* APIKey, int cmdType,  boolean_T printDiagnosticMessages);
void MW_talkBack_addCommand(TBReadData_t *TBReadDataPtr, const char *APIKey, const char *position, const uint8_T *commandString);
void MW_talkBack_deleteAll(TBReadData_t *TBReadDataPtr);
    
#endif //MATLAB_MEX_FILE
    
#ifdef __cplusplus
}
#endif

#endif // _MW_THINGSPEAK_TALKBACK_H_