/*
 * @filename: MW_Modbus_TCP_Server.h 
 *
 * @description: MODBUS TCP Server/Slave for Linux targets
 *               Based on libmodbus library 
 *
 * @copyright: Copyright 2020-2021 The MathWorks, Inc. 
 */

#ifndef _MW_MODBUS_TCP_SERVER_H_
#define _MW_MODBUS_TCP_SERVER_H_

#ifdef __cplusplus
extern "C"
{
#endif

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) || defined(RSIM_WITH_SL_SOLVER))
/* This will be run in Rapid Accelerator Mode */
#define MW_Modbus_Server_ReadCoil(addr, data, status) (0)
#define MW_Modbus_Server_ReadInput(addr, data, status) (0)
#define MW_Modbus_Server_ReadInputRegister(addr, data, status) (0)
#define MW_Modbus_Server_ReadHoldingRegister(addr, data, status) (0)
#define MW_Modbus_Server_WriteCoil(addr, data, status) (0)
#define MW_Modbus_Server_WriteInput(addr, data, status) (0)
#define MW_Modbus_Server_WriteHoldingReg(addr, data, status) (0)
#define MW_Modbus_Server_WriteInputReg(addr, data, status) (0)
#define MW_Modbus_Server_WriteHoldingReg(addr, data, status) (0)
#define MW_Modbus_Server_WriteInputReg(addr, data, status) (0)
#define MW_Modbus_Server_InitializeServer() (0)
#define MW_Modbus_Server_TerminateServer() (0)
#else

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <modbus/modbus.h>

#ifdef __MW_TARGET_USE_HARDWARE_RESOURCES_H__
#include "MW_target_hardware_resources.h"
#endif


void MW_Modbus_Server_ReadCoil(uint16_t addr, uint8_t *data, int8_t *status);
void MW_Modbus_Server_ReadInput(uint16_t addr, uint8_t *data, int8_t *status);
void MW_Modbus_Server_ReadInputRegister(uint16_t addr, uint16_t *data, int8_t *status);
void MW_Modbus_Server_ReadHoldingRegister(uint16_t addr, uint16_t *data, int8_t *status);
void MW_Modbus_Server_WriteCoil(uint16_t addr, uint8_t *data, int8_t *status);
void MW_Modbus_Server_WriteInput(uint16_t addr, uint8_t *data, int8_t *status);
void MW_Modbus_Server_WriteHoldingReg(uint16_t addr, uint16_t *data, int8_t *status);
void MW_Modbus_Server_WriteInputReg(uint16_t addr, uint16_t *data, int8_t *status);
void MW_Modbus_Server_InitializeServer();
void MW_Modbus_Server_TerminateServer();
#endif

#ifdef __cplusplus
}
#endif
#endif //_MW_MODBUS_TCP_SERVER_H_