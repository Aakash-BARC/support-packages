/* Copyright 2019-2021 The MathWorks, Inc. */
#include<stdio.h>
#include <json-c/json.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include "MW_JSONParser.h"

uint8_t MW_getSignalStr(char* jsonstr, char** SigStr)
{
    json_object *parsed_json;
    json_object *Signals;
    int keyExists;
    uint8_t status;
    parsed_json = json_tokener_parse(jsonstr);
    keyExists=json_object_object_get_ex(parsed_json, "Signal", &Signals);
    if (keyExists==false)
    {
        status = 0;
    }else
    {
        *SigStr =  json_object_to_json_string(Signals);
        status = 1;
    }
    
    return(status);
}

double MW_getDashboardSourceData(char* jsonstr, char** BlockIDStr, char **BlockLabelStr)
{
    json_object *parsed_json;
    json_object *blockID;
    json_object *data;
    json_object *blocklabelWithID;
    int keyExists;
    
    parsed_json = json_tokener_parse(jsonstr);
    
    keyExists = json_object_object_get_ex(parsed_json, "labelWithId", &blocklabelWithID);
    *BlockLabelStr = json_object_get_string(blocklabelWithID);
    //printf("blocklabel - %s\n",*BlockLabelStr);

    keyExists = json_object_object_get_ex(parsed_json, "targetId", &blockID);
    *BlockIDStr = json_object_get_string(blockID);
    //printf("blockID - %s\n",*BlockIDStr);

    keyExists = json_object_object_get_ex(parsed_json, "value", &data);
    //printf("value - %f\n",json_object_get_double(data));
    
    return(json_object_get_double(data));
}
        
uint8_t MW_getPortData(char* dataStr, uint8_t port, double* data, uint16_t size)
{
    json_object *parsed_json;
    json_object *Signal;
    
    json_object *Values;
    json_object *Value;
    uint8_t portIndex;
    char dataType[1024];
    double *dataOut;
    uint8_t status;
    int keyExists;
    int i;
    int i_val;
    
    portIndex = port-1;
    dataOut = (double*)malloc(size * sizeof(double));
    parsed_json = json_tokener_parse(dataStr);
    int numSignals = json_object_array_length(parsed_json);
    if (portIndex <= numSignals)
    {
        Signal = json_object_array_get_idx(parsed_json, portIndex);
        
        keyExists = json_object_object_get_ex(Signal, "Value", &Values);
        if (keyExists == false)
        {
            for (i=0; i< size; ++i)
            {
                data[i]=0;
            }            
            status = 0;
        }else
        {
            int numValues = json_object_array_length(Values);
            
            if (numValues != size)
            {
                for (i=0; i< size; ++i)
                {
                    data[i]=0;
                }                
                status = 0;
            }else
            {
                
                for (i_val = 0; i_val < size; ++i_val)
                {
                    Value = json_object_array_get_idx(Values, i_val);
                    data[i_val] = json_object_get_double(Value);
                }                
                status = 1;
            }
        }
    }else
    {
        for (i=0; i< size; ++i)
        {
            data[i]=0;
        }
        
        status = 0;
    }
    
    
    return(status);
    
}