classdef webPublish < matlab.System & coder.ExternalDependency
    
    % Send data to online service ThingSpeak.
    %
    
    %   Copyright 2014-2020 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        %Block Label
        UniqueBlockID = 'webPub 1';
        % IP Address
        IPAddress = '127.0.0.1';
        % Port
        Port = 9000;
        %Number of Signals
        NumberOfSignals = '1';
        %Block Index
        webSocketId = '';
        
        %Block Platform
        BlockPlatform = 'LINUX';
    end
    
     properties (Constant, Hidden)
         NumberOfSignalsSet = matlab.system.StringSet({'1', '2', '3', '4', '5', '6', '7', '8', '9', '10'});
     end
    
    properties(Nontunable, Constant, Hidden)
        %Protocol
        Protocol = 'WebSocket'
    end
    
    properties(Hidden)  
        nanomsgSock
    end
    
    methods
        % Constructor
        function obj = webPublish(varargin)
            %This would allow the code generation to proceed with the
            %p-files in the installed location of the support package.
            coder.allowpcode('plain');
            
            % Support name-value pair arguments when constructing the object.
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.Port(obj, val)
             % Validate portNumber.
            validateattributes(val,{'numeric'}, {'>=',  1, '<=',  65535, 'scalar','real', 'positive', 'integer', 'nonnan', 'nonnegative', 'finite'}, ' ', 'Port');
            obj.Port = val;
        end
            
        function set.IPAddress(obj,val)
            attributes = {'nonempty'};
            paramName = 'IP Address';
            ipVal = convertStringsToChars(val);
            validateattributes(ipVal,{'char'},attributes,'',paramName);            
            if isempty(coder.target)
                ip_expr = '25[0-5]\.|2[0-4][0-9]\.|1[0-9][0-9]\.|[1-9][0-9]\.|[1-9]\.|0\.';
                [match] = regexp([ipVal '.'], ip_expr, 'match');
                if ( length(match) ~= 4 )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                ipStr = [match{1} match{2} match{3} match{4}(1:end-1)];
                if ( ~strcmp(ipStr, ipVal) )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                
                if strcmp(ipVal,'0.0.0.0')
                    error(message('linux:utils:InvalidIPAddress'));
                end
            end
            obj.IPAddress = ipVal;
        end
        
    end
    
    methods (Access = protected)
        %% Common functions
        function setupImpl(obj, varargin)
            % Implement tasks that need to be performed only once,
            % such as pre-computed constants.
            coder.extrinsic('realtime.internal.getWebSocketID');
            if coder.target('Rtw')
                websocketIntID = coder.const(realtime.internal.getWebSocketID(obj.webSocketId,'linux'));
                coder.cinclude('MW_nanomsgClient.h');
                coder.cinclude('MW_JSONParser.h');
                sock = uint8(0);
                sock = coder.ceval('MW_nanomsgClientPubInit',uint8(websocketIntID));
                obj.nanomsgSock = sock;
            end
        end
        
        function validateInputsImpl(obj, varargin)
            for k = 1: str2double(obj.NumberOfSignals)
                validateattributes(varargin{k}, {'numeric', 'logical'}, ...
                    {'nonnan', 'finite', 'vector'}, '', ['Signal' num2str(k)]);
            end
        end
        
        function stepImpl(obj, varargin)
            % Implement algorithm. Calculate y as a function of
            % input u and discrete states.
            if coder.target('Rtw')
                jsonStr = ''; %#ok<NASGU>
                coder.varsize('jsonStr',[1,2^21]); %2^21 bytes are needed to support handling image data of 640x480
                jsonStr = jsonEncode(obj,varargin{:});
                coder.ceval('MW_nanomsgClientSend',uint8(obj.nanomsgSock),coder.rref(jsonStr));
            end
            
        end
        
        function releaseImpl(obj)
            % Release resources, such as file handles
            if coder.target('Rtw')
                coder.ceval('MW_nanomsgClientShutdown', uint8(obj.nanomsgSock));
            end
                   
        end
        
        %Dummy definition to avoid the error in gecko 1159213
        function getOutputDataTypeImpl(~)
            
        end
        
        function N = getNumInputsImpl(obj)
            % Specify number of System inputs
            N = str2double(obj.NumberOfSignals);
        end
        
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 0;
        end
        
        
        
        function jsonString = jsonEncode(obj,varargin)
            coder.varsize('jsonString');
            coder.varsize('signalStr');
            coder.varsize('dataStr');
            
            
            jsonString = '{';
            %Add block ID
            jsonString = [jsonString '"BlockLabel":"' obj.UniqueBlockID '",'];           
            %Add Signals
            jsonString = [jsonString '"Signal":' ];
            
            signalStr = '[';
            
            %Add Individual Signals
            for i = 1:length(varargin)
                signalStr = [signalStr '{']; %#ok<*AGROW>
                signalStr = [signalStr '"DataType":"' class(varargin{i}) '",']; %#ok<*AGROW>
                signalStr = [signalStr '"Value":[']; %#ok<*AGROW>
                for j = 1:(length(varargin{i}))
                    if (isa(varargin{i}, 'double') || isa(varargin{i},'single'))
                        signalStr = [signalStr sprintf('%f',double(varargin{i}(j)));];
                    else
                        signalStr = [signalStr sprintf('%s',string(varargin{i}(j)));];
                    end
                    if j ~= length(varargin{i})
                        signalStr = [signalStr ','];
                    end
                end
                signalStr = [signalStr ']'];
                signalStr = [signalStr '}'];
                if i ~= length(varargin)
                    signalStr = [signalStr ','];
                end
            end
            jsonString = [jsonString signalStr ']}' uint8(0)];
        end
        
         function maskDisplayCmds = getMaskDisplayImpl(obj)
             portLabel = [];
             for i = 1:str2double(obj.NumberOfSignals)
                  portLabel = [portLabel, 'port_label(''input'',' num2str(i) ',''Signal',num2str(i),''');', newline];
             end
              
             iconstr = ['Block ID:', obj.UniqueBlockID];   
            maskDisplayCmds = { ...
                ['color(''white'');', newline],...    % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);', newline],... % Drawing mask layout of the block
                ['plot([0,0,0,0],[0,0,0,0]);', newline],...
                ['color(''black'');', newline] ...  
                portLabel,...
                ['text(50, 12,''' iconstr ''', ''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline]...
                };
            
            labelSample = obj.BlockPlatform;
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(96, 90, ''' labelSample ''', ''horizontalAlignment'', ''right'');', newline],...
                ['color(''black'');', newline],...
                ['image(''webSocPublish.jpg'',''center'');', newline],...
                };
            maskDisplayCmds = [maskDisplayCmds maskDisplayCmdsTarget];
        end
        
    end
    
    methods(Static, Access = protected)
        
        
        %% Simulink customization functions
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header( ...
                'Title',message('linux:blockmask:WebSocketPublishMaskTitle').getString,...
                'Text', message('linux:blockmask:WebSocketPublishMaskDescription').getString,...
                'ShowSourceLink', false);
        end
        
        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function flag = showSimulateUsingImpl
            % Return false if simulation mode hidden in System block dialog
            flag = false;
        end
        
         function [groups, PropertyList] = getPropertyGroupsImpl 
            %BlockLabel Block Label
            BlockLabelProp = matlab.system.display.internal.Property('UniqueBlockID', 'Description', 'Block label');
            %ServerIPAddress Server IP address
            ServerIPProp = matlab.system.display.internal.Property('IPAddress', 'Description', 'Server IP address');
            %ServerportProp Server port 
            ServerportProp = matlab.system.display.internal.Property('Port', 'Description', 'Server port');
            %numInputsProp Number of inputs
            numInputsProp = matlab.system.display.internal.Property('NumberOfSignals', 'Description', 'Number of Inputs');
            %Block Index
            BlockIDProp = matlab.system.display.internal.Property('webSocketId', 'Description', 'Block ID','IsGraphical', false);
            % Block Platform
            BlockPlatformProp = matlab.system.display.internal.Property('BlockPlatform', 'Description', 'Block Platform','IsGraphical', false);
            
            % Property list
            PropertyList ={BlockLabelProp,ServerIPProp,ServerportProp, numInputsProp, BlockIDProp, BlockPlatformProp};
            
            % Create mask display
            Group = matlab.system.display.Section(...
                'Title','Parameters','PropertyList',PropertyList);
            
            groups = Group;

            % Return property list if required
            if nargout > 1
                PropertyList = PropertyListOut;
            end
        end
        
        
        
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'WebSocket Publish';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot;
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludeFiles(buildInfo, 'MW_nanomsgClient.h');
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    addSourcePaths(buildInfo, fullfile(rootDir, 'src'));
                    addSourceFiles(buildInfo, 'MW_nanomsgClient.c', fullfile(rootDir, 'src'), 'BlockModules');                    
                    addSourceFiles(buildInfo, 'MW_JSONParser.c', fullfile(rootDir, 'src'), 'BlockModules');                    
                    addLinkFlags(buildInfo,'-lnanomsg');
                    addLinkFlags(buildInfo,'-ljson-c');
                end
            end
        end
    end
end


% LocalWords:  online codertarget linux nanomsg Socket online codertarget
% LocalWords:  nanomsg Socket websocket Serverport lnanomsg Soccket
