/* Copyright 2021 The MathWorks, Inc. */
/* MW_SocketCAN.h*/
#ifndef _MW_SOCKETCAN_H_
#define _MW_SOCKETCAN_H_

#ifdef __cplusplus
extern "C" { /* sbcheck:ok:extern_c */
#endif

    #include "rtwtypes.h"


    #if (defined(MATLAB_MEX_FILE)  || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))
    // Rapid Accelerator Mode

    #define MW_createSocket(canInterface,sockHandle) 0
    #define MW_CAN_receiveRawSimulink(canInterface,id,data,dataLength,status,extended,remote,error,sockDataHandle,socketErrorHandle) 0
    #define MW_CAN_transmitRaw_MATLABIO(identifier,idType,length,data,canInterface) 0
    #define MW_CAN_transmitCANMsg(a,b,c,d,e,f,g,h,j,i,k,l) 0
    #define MW_CAN_transmitRaw(a,b,c,d,e,f,g,h,j,i,k,l) 0
    #define MW_CAN_receiveRawMATLAB(a,b,c) 0
    #define MW_CAN_receiveRaw(canInterface,id,data,dataLength,status,extended,remote,error,isMATLABWorkflow) 0
    #define MW_CAN_receiveCANMsg(canInterface,id,data,dataLength,status,extended,remote,error,sockDataHandle,sockErrorHandle) 0
  
    #define MW_printError(errString)
    #define MW_executeCommand(cmd)
    #define MW_loadCANModules(isRealCAN)
    #define MW_setupCANLink(cmd,isRealCAN)
    #define MW_checkIFStatus(canInterface) 0
    #define MW_bitrate(bitRate) 0
    #define MW_clearSocket(sockHandle,canInterface) 0

    #else

    #include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h> // For read/write data using Berkeley Sockets
    #include <string.h>
    #include <net/if.h> // For ifreq, ifname, etc
    #include <sys/socket.h> // Socket Address
    #include <sys/ioctl.h> // For ioctl
    #include <linux/can.h>
    #include <linux/can/raw.h> // CAN Raw Sockets

    // Define Error Codes
    #define MW_SOCK_STATUS_OK                       ( 0 )
    #define MW_SOCK_CREATE_ERROR                    ( 1 )
    #define MW_SOCK_IOCTL_ERROR                     ( 2 )
    #define MW_SOCK_BIND_ERROR                      ( 3 )
    #define MW_SOCK_SETSOCKOPT_FILTER_ERROR         ( 4 )
    #define MW_SOCK_SETSOCKOPT_TIMEOUT_ERROR        ( 5 )
    #define MW_SOCK_SETSOCKOPT_ERRMASK_ERROR        ( 6 )
    #define MW_SOCK_CLOSE_ERROR                     ( 7 )

    // CAN Interface check
    #define MW_CAN_UP                             ( 0 )
    #define MW_CAN_NOTUP                          ( 1 )
    #define MW_CAN_NOIF                           ( 2 )

    // Define Transmission Status
    #define TXWAR   ( 0 )
    #define TXEP    ( 1 )
    #define TXBO    ( 2 )
    #define TXERR   ( 3 )
    #define MLOA    ( 4 )
    #define ABTF    ( 5 )



    // Transmit functions
    int32_T MW_CAN_transmitCANMsg(const char* canInterface,
                                  uint8_T idType,
                                  uint32_T ID,
                                  uint8_T Length,
                                  uint8_T* data,
                                  const uint8_T rtr,
                                  uint8_T* status,
                                  const uint8_T isblocking,
                                  const double blockTimeout,
                                  int32_T sockHandleDataFrames,
                                  int32_T sockHandleErrorFrames,
                                  const uint8_T waitforInitialStep);
    int32_T MW_CAN_transmitRaw(const char* canInterface,
                               const uint8_T idType,
                               const uint32_T ID,
                               const uint8_T Length,
                               uint8_T* data,
                               const uint8_T rtr,
                               uint8_T *status,
                               const uint8_T isblocking,
                               const double blockTimeout,
                               int32_T sockHandleDataFrames,
                               int32_T sockHandleErrorFrames,
                               const uint8_T waitforInitialStep);
    int32_T MW_CAN_transmitRaw_MATLABIO(const uint32_T identifier,
                                        const uint8_T idType,
                                        const uint8_T length,
                                        const uint8_T* data,
                                        const char* canInterface);

    // Receive functions
    int32_T MW_CAN_receiveRawSimulink(const char* canInterface,
                                      const uint32_T id,
                                      uint8_T* data,
                                      const uint8_T dataLength,
                                      uint8_T* status,
                                      const uint8_T extended,
                                      uint8_T* remote, uint8_T* error,
                                      int32_T sockHandleDataFrames,
                                      int32_T sockHandleErrorFrames);
    int32_T MW_CAN_receiveRawMATLAB(const uint32_T numMessages,
                                    const char_T* interface, uint8_T* data);
    int32_T MW_CAN_receiveCANMsg(const char* canInterface, uint32_T* id,
                                 uint8_T* data, uint8_T* dataLength,
                                 uint8_T* status, uint8_T* extended,
                                 uint8_T* remote, uint8_T* error,
                                 int32_T sockHandleDataFrames,
                                 int32_T sockHandleErrorFrames);

    // Setup IP Link Functions
    void MW_executeCommand(char_T* cmd);
    int32_T MW_getBitrate(char_T* cmd_Bitrate,char_T* canInterface);
    void MW_loadCANModules(const uint8_T isRealCAN);
    void MW_setupCANLink(char_T* cmd,const uint8_T isRealCAN);
    int32_T MW_checkIFStatus(char_T* canInterface);

    // Setup Socket Functions
    int32_T MW_bitrate(char_T* bitRate);
    void MW_printError(char_T* errString);
    int32_T MW_createSocket(char_T* canInterface, int32_T* sockHandle);
    int32_T MW_clearSocket(int32_T* sockHandle, char_T* canInterface);

    #endif

#ifdef __cplusplus
}
#endif

#endif