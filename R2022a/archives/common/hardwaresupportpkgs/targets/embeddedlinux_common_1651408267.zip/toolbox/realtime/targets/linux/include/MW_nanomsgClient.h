//* Copyright 2019-2020 The MathWorks, Inc. */
#ifndef _MW_NANOMSGCLIENT_H_
#define _MW_NANOMSGCLIENT_H_
#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )

#else
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#endif
#include "rtwtypes.h"
#ifdef __cplusplus
extern "C"
{
#endif

#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
#define MW_nanomsgClientPubInit(url) 0
#define MW_nanomsgClientSubInit(url) 0
#define MW_nanomsgClientSend(sock,msg) 0
#define MW_nanomsgClientRecv(sock,SigStr) 0
#define MW_nanomsgClientShutdown(sock) 0
#else
// SpxAudioReader C-code interface
#ifdef _MATLABIO_
int MW_nanomsgClientPubInit(uint8_T blockIndex, char *mdlName);
#else
int MW_nanomsgClientPubInit(uint8_t blockIndex);
#endif
#ifdef _MATLABIO_
int MW_nanomsgClientSubInit(uint8_T blockIndex, char *mdlName);
#else
int MW_nanomsgClientSubInit(uint8_t blockIndex);
#endif
void MW_nanomsgClientSend(int sock,char *msg);
#ifdef _MATLABIO_
int MW_nanomsgClientRecv(int sock,  char** SigStr, int *bytes);
#else
int MW_nanomsgClientRecv(int sock,  char** SigStr);
#endif
void MW_nanomsgClientShutdown(int sock);
#endif 

#ifdef __cplusplus
}
#endif
#endif 