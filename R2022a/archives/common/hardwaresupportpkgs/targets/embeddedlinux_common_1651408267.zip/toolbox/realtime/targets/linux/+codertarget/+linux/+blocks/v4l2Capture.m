classdef v4l2Capture < matlab.System & coder.ExternalDependency

    % v4l2Capture - Capture images from a USB webcam attached to hardware board.
    % Copyright 2020-2021 The MathWorks, Inc.

    %#codegen

    properties(Nontunable)
        DeviceName  = '/dev/video0';
        Resolution  = '320x240';
        PixelFormat = 'RGB';
        CustomResolution = [320,240];
        SampleTime = 0.1;
        HorizontalFlip (1,1) logical = false
        VerticalFlip (1,1) logical = false
        EnableManualFocus (1,1) logical = true
    end

    properties
        Brightness     = 0.5;
        Saturation     = 0.5;
        Contrast       = 0.5;
        Sharpness      = 0.5;
        CameraZoom     = 0.5;
        ManualFocus    = 0.5;
        CameraPan      = 0;
        CameraTilt     = 0;
    end

    properties (Hidden, Access = private)
        BrightnessInternal        = 0.5;
        SaturationInternal        = 0.5;
        ContrastInternal          = 0.5;
        SharpnessInternal         = 0.5;
        CameraZoomInternal        = 0.5;
        ManualFocusInternal       = 0.5;
        CameraPanInternal         = 0;
        CameraTiltInternal        = 0;
        EnableManualFocusInternal = true
    end
    properties (Nontunable, Hidden)
        SLIOInfra;
        IOProtocol;
        SimulinkIO = false;
        DeviceNumber = uint8(0); % device numeric ID
        Initialized = false;
        ActualResolution = [320,420]; %this value gets passed to the driver
        PixelFormatID = 2; % RGB 2, YCbCr 1
    end

    properties (Nontunable)
        % The below properties were created for backward compatibility
        pixelOrder = 'planar';
        simOutput = 'Colorbars';
        imSizeSelection =  '320x240';
        imSize = '[640, 480]';
        roi = '[0, 0, 640, 480]';
        MultiThreadCoSim = 'auto';
        m_devName = '''/dev/video0''';
        blockPlatform = 'LINUX';
    end
    properties (Nontunable = false, Hidden, Access = private)
        FrameShifter = uint8(0);
    end

    properties(Constant, Hidden)
        ResolutionSet = matlab.system.StringSet({'160x120','320x240',...
            '640x480','800x600','custom'});
        PixelFormatSet = matlab.system.StringSet({'RGB','YCbCr 4:2:2'});
        V4L2TunableProperties = {'Brightness', 'Contrast', 'Saturation',...
            'Sharpness', 'CameraPan', 'CameraTilt', 'CameraZoom',...
            'EnableManualFocus', 'ManualFocus'};
    end

    properties (Hidden, Nontunable, SetAccess = private)
        ResolutionEnum = [320,240]
    end

    properties (Constant, Access = private)
        % Web camera requests
        REQUEST_WEBCAM_INIT         = hex2dec('0xF10C');
        REQUEST_WEBCAM_SNAPSHOT     = hex2dec('0xF10D');
        REQUEST_WEBCAM_TERMINATE    = hex2dec('0xF10E');
        REQUEST_WEBCAM_V4L2SETTINGS = hex2dec('0xF10F');
    end

    methods
        % Constructor
        function obj = v4l2Capture(varargin)
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end

        function set.SampleTime(obj,sampleTime)
            coder.extrinsic('error');
            coder.extrinsic('message');

            validateattributes(sampleTime,{'numeric'},...
                {'nonnan', 'finite'},...
                '','''Sample time''');

            % Sample time must be a real scalar value or 2 element array.
            if ~isreal(sampleTime(1)) || numel(sampleTime) > 2
                error(message('linux:utils:InvalidSampleTimeNeedScalar'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) > 0.0 && sampleTime(2) >= sampleTime(1)
                error(message('linux:utils:InvalidSampleTimeNeedSmallerOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == -1.0 && sampleTime(2) ~= 0.0
                error(message('linux:utils:InvalidSampleTimeNeedZeroOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == 0.0 && sampleTime(2) ~= 1.0
                error(message('linux:utils:InvalidSampleTimeNeedOffsetOne'));
            end
            if numel(sampleTime) ==1 && sampleTime(1) < 0 && sampleTime(1) ~= -1.0
                error(message('linux:utils:InvalidSampleTimeNeedPositive'));
            end
            obj.SampleTime = sampleTime;
        end

        function set.CustomResolution(obj,value)
            validateattributes(value,{'numeric'},...
                {'size',[1,2],'nonnegative','integer'},'','Resolution');
            if rem(value(1),2) ~= 0
                error('Invalid image resolution. Expected even pixels for width');
            end
            if value(1) <8
                error('Minimum image width cannot be less than 8 pixels')
            end
            obj.CustomResolution = value;
        end

        function set.DeviceName(obj,value)
            value = char(strtrim(value));
            if value(1)==char(39)  % char(39) is single quote
                value(1)='';
            end
            if value(end)==char(39)
                value(end)='';
            end
            upr = value <= char('9');
            lwr = value >= char('0');
            numIdx = find((upr.*lwr)==0,1,'last');
            if numel(value) == numIdx
                error ('Enter a valid video device')
            end
            obj.DeviceNumber = uint8(real(str2double(value(numIdx+1:end))));
            obj.DeviceName = value;
        end

        function ret = get.ActualResolution(obj)
            if strcmp(obj.Resolution,'custom')
                ret = obj.CustomResolution;
            else
                ret = obj.convertResolutionToDouble(obj.Resolution);
            end
        end

        function ret = get.PixelFormatID(obj)
            if strcmp(obj.PixelFormat,'YCbCr 4:2:2')
                ret = 1;
            else
                ret = 2; % RGB is 2
            end
        end
    end
    methods(Access = protected)
        function setupImpl(obj)
            if coder.target('Rtw')
                coder.cinclude('MW_availableWebcam.h');
                coder.cinclude('MW_v4l2_cam.h');
                coder.cinclude('<stdio.h>');
                %Populate the list of cameras
                coder.ceval('getCameraList');
                resolutionStatus = int8(0);
                resolutionStatus = coder.ceval('validateResolution',uint8(obj.DeviceNumber),uint16(obj.ActualResolution(1)),uint16(obj.ActualResolution(2)));
                if (resolutionStatus >= 0)
                    coder.ceval('EXT_webcamInit',...
                        uint8(0), ... %MATLAB Targeting flag set to false
                        uint8(obj.DeviceNumber),... %Device ID
                        int32(0),... %roiTop
                        int32(0),... %roiLeft
                        int32(0),... %roiWidth
                        int32(0),... %roiHeight
                        uint32(obj.ActualResolution(1)),...
                        uint32(obj.ActualResolution(2)),...
                        uint32(obj.PixelFormatID),... %pixelFormat
                        uint32(2),... %pixelOrder 2-> planar
                        uint32(1),...
                        obj.SampleTime);        % Frame rate
                else
                    % Resolution is not valid. Cannot proceed further.
                    errorMessage = 'Webcam cannot be initialized properly. Please check if the device supports the specified resolution.';
                    coder.ceval('perror',errorMessage);
                    coder.ceval('exit',int32(0));
                end
                % Initialize the camera with all the v4l2 settings by
                % making the forceUpdate variable to true
                updateV4L2Settings(obj, true);

            elseif coder.target('MATLAB')
                obj.SimulinkIO = matlabshared.svd.internal.isSimulinkIoEnabled();
                if obj.SimulinkIO
                    %handle to deploy and connect to IO server
                    obj.SLIOInfra=matlabshared.ioclient.DeployAndConnectHandle;
                    %get a connected IOclient object
                    obj.SLIOInfra.getConnectedIOClient();
                    obj.IOProtocol = obj.SLIOInfra.IoProtocol;
                    peripheralPayload = [typecast(uint32(obj.DeviceNumber), 'uint8'), typecast(uint32(obj.ActualResolution(1)), 'uint8'), typecast(uint32(obj.ActualResolution(2)), 'uint8'), uint8(obj.PixelFormatID)];
                    responsePeripheralPayloadSize = 4;
                    output = rawRead(obj.IOProtocol, obj.REQUEST_WEBCAM_INIT, peripheralPayload, responsePeripheralPayloadSize);
                    status = cast(typecast(uint8(output(1:4)), 'int32'), 'double');
                    if status ~= 0
                        EX = MException(message('linux:utils:WebCamInitFailure', obj.DeviceName));
                        throwAsCaller(EX);
                    end

                    % Initialize the camera with all the v4l2 settings by
                    % making the forceUpdate variable to true
                    updateV4L2SettingsIO(obj, true);

                else
                    % Nothing for non-SL IO workflows
                end
            end
        end

        function [y1,y2,y3] = stepImpl(obj)

            if coder.target('Rtw')
                coder.cinclude('MW_v4l2_cam.h');
                ts = double(0);
                if obj.PixelFormatID == 1 % YCbCr
                    y1 = coder.nullcopy(zeros(obj.ActualResolution(1),obj.ActualResolution(2),'uint8'));
                    y2 = coder.nullcopy(zeros(obj.ActualResolution(1)/2,obj.ActualResolution(2),'uint8'));
                    y3 = coder.nullcopy(zeros(obj.ActualResolution(1)/2,obj.ActualResolution(2),'uint8'));

                else
                    y1 = coder.nullcopy(zeros(obj.ActualResolution(1),obj.ActualResolution(2),'uint8'));
                    y2 = coder.nullcopy(zeros(obj.ActualResolution(1),obj.ActualResolution(2),'uint8'));
                    y3 = coder.nullcopy(zeros(obj.ActualResolution(1),obj.ActualResolution(2),'uint8'));
                end
                % React to any changes in the tunable parameters
                updateV4L2Settings(obj, false);

                coder.ceval('EXT_webcamCapture',uint8(0),uint8(obj.DeviceNumber),...
                    coder.wref(ts), ...
                    coder.wref(y1),...
                    coder.wref(y2),...
                    coder.wref(y3));
                if obj.HorizontalFlip && obj.VerticalFlip
                    y1 = flip(flip(y1,1),2);
                    y2 = flip(flip(y2,1),2);
                    y3 = flip(flip(y3,1),2);
                elseif obj.HorizontalFlip
                    y1 = flip(y1,2);
                    y2 = flip(y2,2);
                    y3 = flip(y3,2);
                elseif obj.VerticalFlip
                    y1 = flip(y1,1);
                    y2 = flip(y2,1);
                    y3 = flip(y3,1);
                end
            elseif coder.target('MATLAB')
                if obj.SimulinkIO
                    %% React to any changes in the tunable parameters
                    updateV4L2SettingsIO(obj, false)
                    %% Get snapshot
                    peripheralPayload = [typecast(uint32(obj.DeviceNumber), 'uint8'), typecast(uint32(obj.ActualResolution(1)), 'uint8'), typecast(uint32(obj.ActualResolution(2)), 'uint8'), uint8(obj.PixelFormatID)];
                    if obj.PixelFormatID == 1 % YCbCr422
                        responsePeripheralPayloadSize = obj.ActualResolution(1)*obj.ActualResolution(2)*2 +4 +8;
                    else % RGB
                        responsePeripheralPayloadSize = obj.ActualResolution(1)*obj.ActualResolution(2)*3 +4 +8;
                    end
                    output = uint8(rawRead(obj.IOProtocol, obj.REQUEST_WEBCAM_SNAPSHOT, peripheralPayload, responsePeripheralPayloadSize));
                    output = output';
                    status = cast(typecast(uint8(output(1:4)), 'int32'), 'double');
                    if status ~= 0
                        EX = MException(message('linux:utils:ErrorWebcamSnapshot'));
                        throwAsCaller(EX);
                    end
                    % First double datatype, i.e. 8 uint8 values will be timestamp
                    % Rest of the data will be frame buffer
                    data = typecast(output(13:end),'uint8');
                    imgSize = obj.ActualResolution(1)*obj.ActualResolution(2)*(1+obj.PixelFormatID);
                    pxWdHt = obj.ActualResolution(1)*obj.ActualResolution(2);

                    if length(data) ~= imgSize
                        EX = MException(message('linux:utils:ErrorWebcamSnapshot'));
                        throwAsCaller(EX);
                    end

                    y1 = reshape(data(1:pxWdHt),obj.ActualResolution(1),obj.ActualResolution(2));
                    y2 = reshape(data(pxWdHt+1:pxWdHt*((2+obj.PixelFormatID)/2)),obj.ActualResolution(1)*(obj.PixelFormatID/2),obj.ActualResolution(2));
                    y3 = reshape(data(pxWdHt*((2+obj.PixelFormatID)/2)+1:pxWdHt*(1+obj.PixelFormatID)),obj.ActualResolution(1)*(obj.PixelFormatID/2),obj.ActualResolution(2));
                    
                    %% Flip image if needed
                    if obj.HorizontalFlip && obj.VerticalFlip
                        y1 = flip(flip(y1,1),2);
                        y2 = flip(flip(y2,1),2);
                        y3 = flip(flip(y3,1),2);
                    elseif obj.HorizontalFlip
                        y1 = flip(y1,2);
                        y2 = flip(y2,2);
                        y3 = flip(y3,2);
                    elseif obj.VerticalFlip
                        y1 = flip(y1,1);
                        y2 = flip(y2,1);
                        y3 = flip(y3,1);
                    end
                else % Non Simulink IO workflows

                    if obj.PixelFormatID == 1 % YCbCr

                        colorBarResolution = floor(obj.ActualResolution(1)/8);
                        extraPixels = rem(obj.ActualResolution(1),8);

                        d1 = 255*uint8(repmat([ones(extraPixels,1); ones(colorBarResolution,1); ones(colorBarResolution,1);...
                            zeros(colorBarResolution,1); zeros(colorBarResolution,1); ones(colorBarResolution,1); ones(colorBarResolution,1); zeros(colorBarResolution,1); zeros(colorBarResolution,1)],1,obj.ActualResolution(2)));
                        d2 = 255*uint8(repmat([ones(extraPixels,1); ones(colorBarResolution,1); ones(colorBarResolution,1);...
                            ones(colorBarResolution,1); ones(colorBarResolution,1); zeros(colorBarResolution,1); zeros(colorBarResolution,1); zeros(colorBarResolution,1); zeros(colorBarResolution,1)],1,obj.ActualResolution(2)));
                        d2 = d2(1:2:end,:);
                        d3 = 255*uint8(repmat([ones(extraPixels,1); ones(colorBarResolution,1); zeros(colorBarResolution,1);...
                            ones(colorBarResolution,1); zeros(colorBarResolution,1); ones(colorBarResolution,1); zeros(colorBarResolution,1); ones(colorBarResolution,1); zeros(colorBarResolution,1)],1,obj.ActualResolution(2)));
                        d3 = d3(1:2:end,:);
                        obj.FrameShifter = obj.FrameShifter+1;
                        obj.FrameShifter = mod(obj.FrameShifter,8);
                        y1 = circshift(d1,obj.FrameShifter*colorBarResolution,1);
                        y2 = circshift(d2,obj.FrameShifter*colorBarResolution,1);
                        y3 = circshift(d3,obj.FrameShifter*colorBarResolution,1);

                    else

                        colorBarResolution = floor(obj.ActualResolution(1)/8);
                        extraPixels = rem(obj.ActualResolution(1),8);

                        d1 = 255*uint8(repmat([ones(1,extraPixels), ones(1, colorBarResolution), ones(1, colorBarResolution),...
                            zeros(1, colorBarResolution), zeros(1, colorBarResolution), ones(1, colorBarResolution), ones(1, colorBarResolution), zeros(1, colorBarResolution), zeros(1, colorBarResolution)],obj.ActualResolution(2),1));
                        d2 = 255*uint8(repmat([ones(1,extraPixels), ones(1, colorBarResolution), ones(1, colorBarResolution),...
                            ones(1, colorBarResolution), ones(1, colorBarResolution), zeros(1, colorBarResolution), zeros(1, colorBarResolution), zeros(1, colorBarResolution), zeros(1, colorBarResolution)],obj.ActualResolution(2),1));
                        d3 = 255*uint8(repmat([ones(1,extraPixels), ones(1, colorBarResolution), zeros(1, colorBarResolution),...
                            ones(1, colorBarResolution), zeros(1, colorBarResolution),ones(1, colorBarResolution), zeros(1, colorBarResolution),ones(1, colorBarResolution), zeros(1, colorBarResolution)],obj.ActualResolution(2),1));
                        obj.FrameShifter = obj.FrameShifter+1;
                        obj.FrameShifter = mod(obj.FrameShifter,8);
                        y1 = circshift(d1,obj.FrameShifter*colorBarResolution,2)';
                        y2 = circshift(d2,obj.FrameShifter*colorBarResolution,2)';
                        y3 = circshift(d3,obj.FrameShifter*colorBarResolution,2)';

                    end
                end
            end
        end

        function releaseImpl(obj)
            % Release camera
            if coder.target('Rtw')
                coder.cinclude('MW_v4l2_cam.h');
                coder.ceval('EXT_webcamTerminate',uint8(0),uint8(obj.DeviceNumber));
            elseif coder.target('MATLAB')
                if obj.SimulinkIO
                    peripheralPayload = typecast(uint32(obj.DeviceNumber), 'uint8');
                    responsePeripheralPayloadSize = 4;
                    rawRead(obj.IOProtocol, obj.REQUEST_WEBCAM_TERMINATE, peripheralPayload, responsePeripheralPayloadSize);
                    % Do not throw errors/warnings on destruction
                    obj.SLIOInfra.deleteConnectedIOClient(); % Remove the IOProtocol client object
                end
            end
        end

        function ret = isTunableParameterChanged(obj, propName)
            if obj.(propName) ~= obj.([propName,'Internal'])
                ret = true;
            else
                ret = false;
            end
        end

        function updateV4L2Settings(obj, forceUpdate)
            % UPDATEV4L2SETTINGS - performs run-time update of the v4l2 parameters
            % "forceUpdate":  when set to true will update all the parameters
            % irrespective of whether the tunable property changed or not
            coder.cinclude('MW_v4l2_cam.h');
            status = uint8(0);
            for i=1:numel(obj.V4L2TunableProperties)
                if (isTunableParameterChanged(obj, obj.V4L2TunableProperties{i}) || forceUpdate)
                    obj.([obj.V4L2TunableProperties{i},'Internal']) = obj.(obj.V4L2TunableProperties{i});
                    coder.ceval('EXT_updateV4L2Control',cstring(obj.V4L2TunableProperties{i}),...
                        single(obj.(obj.V4L2TunableProperties{i})), uint8(obj.DeviceNumber), coder.wref(status));
                end
            end
        end

        function updateV4L2SettingsIO(obj, forceUpdate)
            % UPDATEV4L2SETTINGSIO - performs run-time update of the v4l2 parameters
            % "forceUpdate":  when set to true will update all the parameters
            % irrespective of whether the tunable property changed or not
            v4l2Struct = [];
            numSettingsUpdated = 0;

            for i=1:numel(obj.V4L2TunableProperties)
                if (isTunableParameterChanged(obj, obj.V4L2TunableProperties{i})  || forceUpdate)
                    obj.([obj.V4L2TunableProperties{i},'Internal']) = obj.(obj.V4L2TunableProperties{i});
                    v4l2Struct.(obj.V4L2TunableProperties{i}) = single(obj.(obj.V4L2TunableProperties{i}));
                    numSettingsUpdated = numSettingsUpdated+1;
                end
            end

            if (~isempty(v4l2Struct)) && (numSettingsUpdated>0)
                v4l2JsonData = cstring(jsonencode(v4l2Struct));
                peripheralPayload = [typecast(uint32(obj.DeviceNumber), 'uint8'), uint8(v4l2JsonData)];
                % expected response is an unit8 array of status(es)
                % for each v4l2 updated parameter
                responsePeripheralPayloadSize = numSettingsUpdated;

                output = uint8(rawRead(obj.IOProtocol, obj.REQUEST_WEBCAM_V4L2SETTINGS,...
                    peripheralPayload, responsePeripheralPayloadSize));
                output = output';

                if numel(output) == numSettingsUpdated
                    propNames = fieldnames(v4l2Struct);
                    if sum(output) ~= 0
                        for i=1:numSettingsUpdated
                            if output(i) ~=0
                                disp(['V4L2 Video Capture Block: "',propNames{i}, '" cannot be set for this webcam']);
                            end
                        end
                    end
                else
                    % Something went wrong in receiving the status
                    % values from target
                end
            end
        end
    end


    methods (Hidden,Access=protected,Static)
        function resEnum = convertResolutionToDouble(value)
            switch(value)
                case '160x120'
                    resEnum = [160, 120];
                case '320x240'
                    resEnum = [320, 240];
                case '640x480'
                    resEnum = [640, 480];
                case '800x600'
                    resEnum = [800, 600];
                case '1024x768'
                    resEnum = [1024, 768];
                case '1280x720'
                    resEnum = [1280, 720];
                case '1920x1080'
                    resEnum = [1920, 1080];
                otherwise
                    resEnum = [320, 240];
            end
        end
    end

    methods (Access=protected)
        %% Input properties
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 0;
        end

        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 3;
        end
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            portLabel = [];
            if obj.PixelFormatID==1 % YCbCr
                portLabel = [portLabel, 'port_label(''output'',' num2str(1) ',''Y'');', newline];
                portLabel = [portLabel, 'port_label(''output'',' num2str(2) ',''Cb'');', newline];
                portLabel = [portLabel, 'port_label(''output'',' num2str(3) ',''Cr'');', newline];
            else
                portLabel = [portLabel, 'port_label(''output'',' num2str(1) ',''R'');', newline];
                portLabel = [portLabel, 'port_label(''output'',' num2str(2) ',''G'');', newline];
                portLabel = [portLabel, 'port_label(''output'',' num2str(3) ',''B'');', newline];
            end
            maskDisplayCmds = { ...
                ['color(''white'');', newline],...    % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);', newline],... % Drawing mask layout of the block
                ['plot([0,0,0,0],[0,0,0,0]);', newline],...
                ['color(''black'');', newline] ...
                portLabel,...
                };

            labelSample = obj.blockPlatform;
            maskDisplayCmdsTarget = { ...
                ['image(''webcamLinux.png'',''center'');', newline],...
                ['color(''blue'');', newline],...
                ['text(120, 90, ''' labelSample ''', ''horizontalAlignment'', ''right'');', newline],...
                };
            maskDisplayCmds = [maskDisplayCmds maskDisplayCmdsTarget];
        end
    end
    %% Output properties
    methods (Access = protected)
        function varargout = isOutputFixedSizeImpl(~,~)
            varargout{1} = true;
            varargout{2} = true;
            varargout{3} = true;
        end

        function varargout = isOutputComplexImpl(~)
            varargout{1} = false;
            varargout{2} = false;
            varargout{3} = false;
        end

        function varargout = getOutputSizeImpl(obj)
            varargout{1} = [obj.ActualResolution(1), obj.ActualResolution(2)];
            if strcmp(obj.PixelFormat,'YCbCr 4:2:2')
                varargout{2} = [obj.ActualResolution(1)/2, obj.ActualResolution(2)];
                varargout{3} = [obj.ActualResolution(1)/2, obj.ActualResolution(2)];
            else
                varargout{2} = [obj.ActualResolution(1), obj.ActualResolution(2)];
                varargout{3} = [obj.ActualResolution(1), obj.ActualResolution(2)];
            end
        end

        function varargout = getOutputDataTypeImpl(~)
            varargout{1} = 'uint8';
            varargout{2} = 'uint8';
            varargout{3} = 'uint8';
        end

        function flag = isTunablePropertyDataTypeMutableImpl(~)
            flag = false;
        end

        function st = getSampleTimeImpl(obj)
            if obj.SampleTime == -1
                st = createSampleTime(obj, 'Type', 'Inherited');
            else
                st = createSampleTime(obj, 'Type', 'Discrete', 'SampleTime', obj.SampleTime);
            end
        end
    end

    %% Mask Properties
    methods (Static, Access=protected)

        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header( ...
                'Title',message('linux:blockmask:V4L2BlockMaskTitle').getString,...
                'Text', message('linux:blockmask:V4L2BlockMaskDescription').getString,...
                'ShowSourceLink', false);
        end

        function simMode = getSimulateUsingImpl(~)
            simMode = 'Interpreted execution';
        end

        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end

        function groups = getPropertyGroupsImpl
            %Block properties
            DeviceNameProp = matlab.system.display.internal.Property('DeviceName', 'Description', 'Device name');
            ResolutionProp = matlab.system.display.internal.Property('Resolution', 'Description', 'Image size');
            PixelFormatProp = matlab.system.display.internal.Property('PixelFormat', 'Description', 'Pixel format');
            CustomResolutionProp = matlab.system.display.internal.Property('CustomResolution','Description','Image size ([width, height])');
            SampleTimeProp = matlab.system.display.internal.Property('SampleTime', 'Description', 'Sample time');

            %Embdlinuxlib block's legacy properties
            pixelOrderProp = matlab.system.display.internal.Property('pixelOrder', 'Description', 'Pixel order');
            simOutputProp = matlab.system.display.internal.Property('simOutput', 'Description', 'Simulation output');
            imSizeSelectionProp =  matlab.system.display.internal.Property('imSizeSelection', 'Description', 'Image size selection');
            imSizeProp = matlab.system.display.internal.Property('imSize', 'Description', 'Image size ');
            roiProp = matlab.system.display.internal.Property('roi', 'Description', 'Region of interest');
            MultiThreadCoSimProp = matlab.system.display.internal.Property('MultiThreadCoSim', 'Description', 'MultiThreadCoSim');
            m_devNameProp = matlab.system.display.internal.Property('m_devName', 'Description', 'Device name');
            blockPlatformProp = matlab.system.display.internal.Property('blockPlatform', 'Description', 'blockPlatform');


            horizontalFlipProp = matlab.system.display.internal.Property('HorizontalFlip',...
                'Description', 'Flip image along horizontal axis');
            verticalFlipProp = matlab.system.display.internal.Property('VerticalFlip',...
                'Description', 'Flip image along vertical axis');
            % Main Property list
            mainPropertiesList ={DeviceNameProp ResolutionProp CustomResolutionProp PixelFormatProp SampleTimeProp pixelOrderProp ...
                simOutputProp imSizeSelectionProp imSizeProp roiProp MultiThreadCoSimProp m_devNameProp blockPlatformProp, horizontalFlipProp,verticalFlipProp };
            % Create section for Main properties
            mainSection = matlab.system.display.Section(...
                'PropertyList',mainPropertiesList);
            % Create Main Tab
            mainGroup = matlab.system.display.SectionGroup('Title','Main',...
                'Sections',mainSection);

            % Advanced properties


            brightnessProp = matlab.system.display.internal.Property('Brightness',...
                'Description', 'Brightness',...
                'StaticRange', [0, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider);
            saturationProp = matlab.system.display.internal.Property('Saturation',...
                'Description', 'Saturation',...
                'StaticRange', [0, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider,...
                'Row',matlab.system.display.internal.Row.current);
            contrastProp = matlab.system.display.internal.Property('Contrast',...
                'Description', 'Contrast',...
                'StaticRange', [0, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider);
            sharpnessProp = matlab.system.display.internal.Property('Sharpness',...
                'Description', 'Sharpness',...
                'StaticRange', [0, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider,...
                'Row',matlab.system.display.internal.Row.current);
            picturePropertiesList = {brightnessProp, saturationProp, contrastProp,...
                sharpnessProp};
            pictureSettingsSection = matlab.system.display.Section(...
                'Title','Image properties',...
                'PropertyList',picturePropertiesList,...
                'Type', matlab.system.display.SectionType.collapsiblepanel);

            cameraZoomProp = matlab.system.display.internal.Property('CameraZoom',...
                'Description', 'Zoom',...
                'StaticRange', [0, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider);
            cameraEnableManualFocusProp = matlab.system.display.internal.Property('EnableManualFocus',...
                'Description', 'Enable Manual focus');
            cameraManualFocusProp = matlab.system.display.internal.Property('ManualFocus',...
                'Description', 'Manual focus',...
                'StaticRange', [0, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider);
            cameraPanProp = matlab.system.display.internal.Property('CameraPan',...
                'Description', 'Pan',...
                'StaticRange', [-1, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider);
            cameraTiltProp = matlab.system.display.internal.Property('CameraTilt',...
                'Description', 'Tilt',...
                'StaticRange', [-1, 1],...
                'WidgetType', matlab.system.display.internal.WidgetType.slider,...
                'Row',matlab.system.display.internal.Row.current);

            cameraPropertiesList = { cameraPanProp, cameraTiltProp, cameraZoomProp, cameraEnableManualFocusProp,...
                cameraManualFocusProp};
            cameraSettingsSection = matlab.system.display.Section(...
                'Title', 'Device properties',...
                'PropertyList',cameraPropertiesList,...
                'Description',' Not all cameras support these properties',...
                'Type', matlab.system.display.SectionType.collapsiblepanel);


            % Create Advanced Tab

            advancedGroup = matlab.system.display.SectionGroup('Title','Advanced',...
                'Sections',[pictureSettingsSection, cameraSettingsSection]);

            groups = [mainGroup,advancedGroup];
        end
    end

    methods (Access=protected)
        function flag = isInactivePropertyImpl(obj,prop)

            switch (prop)
                case {'CustomResolution'}
                    if strcmp(obj.Resolution,'custom')
                        flag = false;
                    else
                        flag = true;
                    end
                case {'pixelOrder', 'simOutput', 'imSizeSelection' ...
                        , 'imSize', 'roi', 'MultiThreadCoSim','blockPlatform' ...
                        , 'm_devName'}
                    flag = true;
                case {'ManualFocus'}
                    if obj.EnableManualFocus
                        flag = false;
                    else
                        flag = true;
                    end
                otherwise
                    flag = false;
            end
        end

    end
    %% Build artifacts
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'V4L2 Video Capture';
        end

        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end

        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Add the v4l2 driver files

                rootDir = realtime.internal.getLinuxRoot;
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludeFiles(buildInfo,'MW_availableWebcam.h');
                addIncludeFiles(buildInfo,'MW_v4l2_cam.h');
                addSourceFiles(buildInfo,'MW_v4l2_cam.c',fullfile(rootDir,'src'));
                addSourceFiles(buildInfo,'MW_availableWebcam.c',fullfile(rootDir,'src'));
            end
        end
    end
end

%% local functions
% Put a C termination character '\0' at the end of MATLAB character vector
function y = cstring(x)
    y = [x char(0)];
end


% LocalWords:  linux dev Nx MATLABTGT Addr roi
