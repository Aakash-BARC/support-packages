classdef ModbusTCPMasterWrite < matlab.System & coder.ExternalDependency
    % MODBUSTCPMASTERWRITE - Provides functionality for Master/Client to
    % communicate with the Slave/Server
    
    %#codegen
    
    % Copyright 2020 The MathWorks, Inc.
    
    properties(Nontunable)
        %Server address
        serverIP = '127.0.0.1';
        %Modbus function
        Function = 'Write Coil';
        %Coil address
        CoilAddress = 0;
        %Holding Register address
        HoldingRegisterAddress = 0;
        %Number of Coil elements
        numElements_coil = 1;
        %Number of Holding register elements
        numElements_holdingReg = 1;
    end
    
    properties(Hidden, Constant)
        FunctionSet = matlab.system.StringSet({...
            'Write Coil',...
            'Write Holding register',...
            'Write Multiple Coils',...
            'Write Multiple Holding registers', ...
            });
    end
    
    properties(Hidden)
        FunctionEnum;
    end
    
    methods
        function obj = ModbusTCPMasterWrite(varargin)
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.serverIP(obj, val)
            attributes = {'nonempty'};
            paramName = 'IP Address';
            ipVal = convertStringsToChars(val);
            validateattributes(ipVal,{'char'},attributes,'',paramName);
            if isempty(coder.target)
                ip_expr = '25[0-5]\.|2[0-4][0-9]\.|1[0-9][0-9]\.|[1-9][0-9]\.|[1-9]\.|0\.';
                [match] = regexp([ipVal '.'], ip_expr, 'match');
                if ( length(match) ~= 4 )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                ipStr = [match{1} match{2} match{3} match{4}(1:end-1)];
                if ( ~strcmp(ipStr, ipVal) )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                
                if strcmp(ipVal,'0.0.0.0')
                    error(message('linux:utils:InvalidIPAddress'));
                end
            end
            obj.serverIP = cString(ipVal);
        end
        
        function set.CoilAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',65535},'','Coil Address');
            obj.CoilAddress = val;
        end
        function set.HoldingRegisterAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',65535},'','Holding Register Address');
            obj.HoldingRegisterAddress = val;
        end
        function set.numElements_coil(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',1,'<=',65535},'','Number of Coil Elements');
            obj.numElements_coil = val;
        end
        function set.numElements_holdingReg(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',1,'<=',65535},'','Number of Holding Register Elements');
            obj.numElements_holdingReg = val;
        end
        
        
        function val = get.FunctionEnum(obj)
            switch (obj.Function)
                case 'Write Coil'
                    val = 1;
                case 'Write Holding register'
                    val = 2;
                case 'Write Multiple Coils'
                    val = 3;
                case 'Write Multiple Holding registers'
                    val = 4;
            end
        end
        
        function val = getTargetName(obj) %#ok<MANU>
            val = 'LINUX';
        end
    end
    
    methods(Access = protected)
        function setupImpl(obj, varargin)
            if coder.target('Rtw')
                coder.cinclude('MW_Modbus_TCP_Client.h');
                coder.ceval('MW_Modbus_Client_InitializeClient',obj.serverIP);
            end
        end
        
        
        
        function varargout = stepImpl(obj, data)
            Mstatus = int8(0);
            if coder.target('Rtw')
                switch (obj.FunctionEnum)
                    case 1
                        coder.ceval('MW_Modbus_Client_WriteCoil', obj.serverIP, uint16(obj.CoilAddress), coder.ref(data), coder.ref(Mstatus));
                    case 2
                        coder.ceval('MW_Modbus_Client_WriteHoldingRegister', obj.serverIP, uint16(obj.HoldingRegisterAddress), coder.ref(data), coder.ref(Mstatus));
                    case 3
                        coder.ceval('MW_Modbus_Client_WriteMultipleCoils', obj.serverIP, uint16(obj.CoilAddress), uint8(obj.numElements_coil), coder.ref(data), coder.ref(Mstatus));
                    case 4
                        coder.ceval('MW_Modbus_Client_WriteMultipleHoldingRegister', obj.serverIP, uint16(obj.HoldingRegisterAddress), uint8(obj.numElements_holdingReg), coder.ref(data), coder.ref(Mstatus));
                end
            end
            varargout{1} = Mstatus;
        end
        
        
        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval('MW_Modbus_Client_TerminateClient', obj.serverIP);
            end
        end
        
        
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 1;
        end
        
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 0;
        end
        
        
        function flag = isInactivePropertyImpl(obj,prop)
            % Return false if property is visible based on object
            % configuration, for the command line and System block dialog
            switch prop
                case'serverIP'
                    flag = false;
                case'Function'
                    flag = false;
                case'CoilAddress'
                    if ((obj.FunctionEnum == 1) ||(obj.FunctionEnum == 3))
                        flag = false;
                    else
                        flag = true;
                    end
                case'HoldingRegisterAddress'
                    if ((obj.FunctionEnum == 2) ||(obj.FunctionEnum == 4))
                        flag = false;
                    else
                        flag = true;
                    end
                case'numElements_coil'
                    if (obj.FunctionEnum == 3)
                        flag = false;
                    else
                        flag = true;
                    end
                case'numElements_holdingReg'
                    if (obj.FunctionEnum == 4)
                        flag = false;
                    else
                        flag = true;
                    end
            end
        end
        
        function validateInputsImpl(obj,data)
            switch obj.FunctionEnum
                case 1
                    for k = 1:length(data)
                        validateattributes(data,{'logical'}, ...
                            {'nonnan', 'finite'}, '', 'input');
                    end
                case 2
                    for k = 1:length(data)
                        validateattributes(data,{'uint16'}, ...
                            {'nonnan', 'finite'}, '', 'input');
                    end
                case 3
                    for k = 1:length(data)
                        validateattributes(data,{'logical'}, ...
                            {'nonnan', 'finite', 'vector', 'numel', obj.numElements_coil}, '', 'input');
                    end
                case 4
                    for k = 1:length(data)
                        validateattributes(data,{'uint16'}, ...
                            {'nonnan', 'finite', 'vector', 'numel', obj.numElements_holdingReg}, '', 'input');
                    end
            end
            
            
        end
        
        
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            function_label = obj.Function;
            maskDisplayCmds = { ...
                'color(''white'');',...
                'plot([100,100,100,100]*1,[100,100,100,100]*1);',...
                'plot([100,100,100,100]*0,[100,100,100,100]*0);',...
                'color(''blue'');', ...
                ['text(99, 92, ''' getTargetName(obj) ''', ''horizontalAlignment'', ''right'');'],...
                'color(''black'');', ...
                'text(50,60,''\fontsize{12}\bfMODBUS TCP/IP'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');', ...
                'text(50,40,''\fontsize{10}\bfMaster Write'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',...
                ['text(50,15,''\fontsize{8}', function_label  '' ''',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');']...
                };
        end
    end
    
    methods(Static, Access = protected)
        %% Simulink customization functions
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', 'Modbus TCP/IP Master Write', 'Text', getString(message('linux:blockmask:ModbusTCPMasterWrite')), ...
                'ShowSourceLink', false);
        end
        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function flag = showSimulateUsingImpl
            % Return false if simulation mode hidden in System block dialog
            flag = false;
        end
        
        
        function [groups, PropertyList] = getPropertyGroupsImpl
            serverIPProp = matlab.system.display.internal.Property('serverIP', 'Description', 'Slave address');
            FunctionProp = matlab.system.display.internal.Property('Function', 'Description', 'Function');
            coilAddressProp = matlab.system.display.internal.Property('CoilAddress', 'Description', 'Coil Address');
            HoldingRegisterAddressProp = matlab.system.display.internal.Property('HoldingRegisterAddress', 'Description', 'Holding Register Address');
            numElementsCoilProp = matlab.system.display.internal.Property('numElements_coil', 'Description', 'Number of Coils');
            numElementsHoldingRegProp = matlab.system.display.internal.Property('numElements_holdingReg', 'Description', 'Number of Holding registers');
            
            % Property list
            PropertyList ={
                serverIPProp,...
                FunctionProp,...
                coilAddressProp, ...
                HoldingRegisterAddressProp,...
                numElementsCoilProp,...
                numElementsHoldingRegProp...
                };
            
            % Create mask display
            Group = matlab.system.display.Section(...
                'PropertyList',PropertyList);
            
            groups = Group;
            
            % Return property list if required
            if nargout > 1
                PropertyList = PropertyListOut;
            end
        end
        
    end
    
    methods (Static)
        function name = getDescriptiveName()
            name = 'Modbus TCP/IP Master Write';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                spkgRootDir =  realtime.internal.getLinuxRoot;
                % Include Paths
                addIncludePaths(buildInfo, fullfile(spkgRootDir, 'include'));
                % Source Files
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    addSourcePaths(buildInfo, fullfile(spkgRootDir, 'src'));
                    addSourceFiles(buildInfo, 'MW_Modbus_TCP_Client.c', fullfile(spkgRootDir, 'src'), 'BlockModules');
                    mb_linkflags = '`pkg-config --libs --cflags libmodbus`';
                    addLinkFlags(buildInfo,mb_linkflags,'SkipForSil');
                end
            end
        end
    end
end

% Local functions
function str = cString(str)
str = [str uint8(0)];
end
