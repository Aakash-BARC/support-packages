classdef linuxCANMsg
    %   linuxCANMsg Used for outputing CANMsg type data from the
    %   CAN Receive block

%   Copyright 2021 The MathWorks, Inc.
    
    properties        
        Extended = uint8(0);
        Length = uint8(0);
        Remote = uint8(0);
        Error = uint8(0);
        ID = uint32(0);
        Timestamp = double(0);
        Data(8,1) = uint8([0,0,0,0,0,0,0,0])
    end   
end
