/* Copyright 2016-2020 The MathWorks, Inc. */
#ifndef EXT_MODE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "MW_SDL2_video_display.h"

/* These are defined in the block mask */
typedef enum {
    MW_SDL_PIXEL_FORMAT_RGB = 1,
    MW_SDL_PIXEL_FORMAT_YUYV,
    MW_SDL_PIXEL_FORMAT_RESERVED
} MW_SDL_PIXEL_FORMAT;

typedef enum {
    MW_SDL_PIXEL_ORDER_PLANAR = 1,
    MW_SDL_PIXEL_ORDER_INTERLEAVED,
    MW_SDL_PIXEL_ORDER_RESERVED
} MW_SDL_PIXEL_ORDER;

/* Local defines */
#define MW_SDL_SCREEN_ORIGIN_X (100)
#define MW_SDL_SCREEN_ORIGIN_Y (100)
#define MAX_WINDOW_TITLE       (30)
#ifndef MW_SDL_MAX_NUM_WINDOWS
#define MW_SDL_MAX_NUM_WINDOWS        (20)
#endif
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
#define MW_SDL_RMASK (0xff000000)
#define MW_SDL_GMASK (0x00ff0000)
#define MW_SDL_BMASK (0x0000ff00)
#else
#define MW_SDL_RMASK (0x000000ff)
#define MW_SDL_GMASK (0x0000ff00)
#define MW_SDL_BMASK (0x00ff0000)
#endif

#ifdef __linux__ 
#if !HAVE_DECL_SETENV
extern int setenv (const char *, const char *, int);
#endif
#endif

/*#define _DEBUG (1)*/

/* Static window info structure */
typedef struct {
    SDL_Texture *texture;
    int pixelFormat;
    int pixelOrder;
    int rowMajor;
    int width;
    int height;
    char windowTitle[MAX_WINDOW_TITLE];
} WindowInfo_t;

typedef struct {
    volatile int enabled;
    volatile int isVideoModeSet;
    SDL_Event event;
    SDL_Window *sdlWindow;
    SDL_Renderer *renderer;
    Uint32 *myPixels;
    WindowInfo_t windowInfo;
} DisplayInfo_t;

/* The variable is initialized to 0 when DLL is loaded */
static DisplayInfo_t dispInfoArray[MW_SDL_MAX_NUM_WINDOWS];
static int displayInfoArrayIndex;
static int sdlWindowXYPos = 30;

/* Forward declarations */
static void MW_windowShutdown(int displayId);
static void MW_globalVideoShutdown(void);
static void MW_pollSDLEvent(int displayId);
void MW_SDLCleanup(void);

/* Initialize required SDL subsystems */
static int MW_globalVideoInit(void)
{
#ifdef __linux__
    /* Make sure that DISPLAY environment variable is defined. If not,
     * SDL does not start properly in X11 based implementations */
    char *tmp;
    
    tmp = getenv("DISPLAY");
#ifdef _DEBUG
    if (tmp != NULL) {
        printf("Using DISPLAY=%s\n", tmp);
    } else {
        printf("DISPLAY environment variable is not defined.\n");
    }
#endif /* _DEBUG */
    if (tmp == NULL) {
        if (setenv("DISPLAY", ":0.0", 0) == -1) {
            /* This is not an error condition. Just print out a warning.
             * SDL might be running without X11 */
            fprintf(stderr, "Unable to set DISPLAY to :0.0\n");
        }
        tmp = getenv("DISPLAY");
        if (tmp != NULL) {
            printf("DISPLAY set to '%s'\n", tmp);
        } else {
            printf("Could not set DISPLAY to ':0.0'.\n");
        }
    }
    fflush(stdout);
    fflush(stderr);
#endif
    
    /* Initialize video module only if it not initialized */
    if (!SDL_WasInit(SDL_INIT_VIDEO)) {
        /* SDL_INIT_NOPARACHUTE: don't catch fatal signals */
        /* SDL_INIT_VIDEO: initialize VIDEO subsystem */
        if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_NOPARACHUTE) < 0) {
            fprintf(stderr, "Unable to init SDL: %s\n", SDL_GetError());
            fflush(stderr);
            return -1;
        }
    }
    
#ifdef _DEBUG
    {
        SDL_version compiled;
        SDL_version linked;
        
        SDL_VERSION(&compiled);
        SDL_GetVersion(&linked);
        printf("We compiled against SDL version %d.%d.%d ...\n",
                compiled.major, compiled.minor, compiled.patch);
        printf("But we are linking against SDL version %d.%d.%d.\n",
                linked.major, linked.minor, linked.patch);
        fflush(stdout);
    }
#endif /* _DEBUG */
    
    return 0;
}

/* Handles QUIT event. We ignore all other events. If we catch
 * a QUIT event, we uninitialize the SDL surface and close SDL
 * screen. We return 0 to make sure SDL does not pass the event
 * to the main application (an issue in WINDOWS)
 */
static int MW_eventFilter(void* userData,
        const SDL_Event *event)
{
    if(event->type == SDL_QUIT) {
#if defined(MATLAB_MEX_FILE)
        MW_SDLCleanup();
#else
        return 1; /* This enables QUIT event to be caught in SDL_pollEvents */
#endif
    }
    
    /* Ignore all events. QUIT is handled above */
    return 0;
}


/* Initializes SDL screen */
static int MW_screenInit(int displayId) {
    char sdlEnvPos[40];
    WindowInfo_t *currWindow = &(dispInfoArray[displayId].windowInfo);
    
#ifndef __linux__  //TODO : check if this is required
    /* Set up the screen */
    /* "SDL_VIDEO_CENTERED=center", "SDL_VIDEO_WINDOW_POS=x,y" */
    sprintf(sdlEnvPos, "SDL_VIDEO_WINDOW_POS=%d,%d",
            MW_SDL_SCREEN_ORIGIN_X, MW_SDL_SCREEN_ORIGIN_Y);
    
    SDL_putenv(sdlEnvPos);
#endif
    
    dispInfoArray[displayId].sdlWindow = SDL_CreateWindow(currWindow->windowTitle,
            sdlWindowXYPos,
            sdlWindowXYPos,
            currWindow->width,
            currWindow->height,
            SDL_WINDOW_RESIZABLE);
    /*SDL library can handle if position exceeds available resolution*/
    sdlWindowXYPos += 20;
    
    if(dispInfoArray[displayId].sdlWindow == NULL) {
        fprintf(stderr, "Unable to create sdl window: %s\n", SDL_GetError());
        fflush(stderr);
        return -1;
    }
    
    dispInfoArray[displayId].renderer = SDL_CreateRenderer(dispInfoArray[displayId].sdlWindow, -1, SDL_RENDERER_SOFTWARE | SDL_RENDERER_TARGETTEXTURE);
    
    if(dispInfoArray[displayId].renderer == NULL) {
        fprintf(stderr, "Unable to create renderer: %s\n", SDL_GetError());
        fflush(stderr);
        return -1;
    }
    
    dispInfoArray[displayId].myPixels = (Uint32*)calloc((currWindow->width)*(currWindow->height),sizeof(Uint32));
    if(dispInfoArray[displayId].myPixels == NULL) {
        fprintf(stderr, "Unable to allocate mem for dispInfoArray[displayId].myPixels: %s\n");
        fflush(stderr);
        return -1;
    }
    
    /* Install an event filter to catch WM quit event */
    SDL_SetEventFilter(&MW_eventFilter,NULL);
    
    return 0;
}

/* Set the parameters of the video window */
static void MW_setWindowParams
        (
        int window,
        int pixelFormat,
        int pixelOrder,
        int rowMajor,
        int width,
        int height,
        char* windowTitle,
        int displayId
        )
{
    WindowInfo_t *currWindow = &(dispInfoArray[displayId].windowInfo);
    
    /* Sanity check on input parameters */
    assert((pixelFormat > 0) && (pixelFormat < MW_SDL_PIXEL_FORMAT_RESERVED));
    assert((pixelOrder > 0) && (pixelOrder < MW_SDL_PIXEL_ORDER_RESERVED));
    
    /* Set source and destination rectangles */
    currWindow->pixelFormat = pixelFormat;
    currWindow->pixelOrder  = pixelOrder;
    strncpy(&currWindow->windowTitle[0], windowTitle, MAX_WINDOW_TITLE);
    printf("Window title = %s\n",currWindow->windowTitle);
    //currWindow->ovl         = NULL;
    
    /* Set width & height of the SDL screen */
    if (currWindow->pixelOrder == MW_SDL_PIXEL_ORDER_INTERLEAVED) {
        /* Interleaved formats are assumed to be directly coming from
         * the input device, hence row major format */
        currWindow->rowMajor = 1;
    }
    else {
        currWindow->rowMajor = rowMajor;
    }
    if (currWindow->rowMajor) {
        if (currWindow->pixelOrder == MW_SDL_PIXEL_ORDER_INTERLEAVED) {
            if (currWindow->pixelFormat == MW_SDL_PIXEL_FORMAT_RGB) {
                assert((width % 3) == 0);
                currWindow->width  = width / 3; /* (1R + 1G + 1B)x(height) */
                currWindow->height = height;
            }
            else {
                assert((width & 0x1) == 0);
                currWindow->width  = width / 2; /* (1Y + 0.5Cb + 0.5Cr)x(height) */
                currWindow->height = height;
            }
        }
        else {
            currWindow->width  = width;
            currWindow->height = height;
        }
    }
    else {
        /* No interleaved format in column major */
        currWindow->width  = height;
        currWindow->height = width;
    }
}

/* Initialize an SDL surface representing Video Display window */
static int MW_windowInit(int displayId)
{
    WindowInfo_t *currWindow = &(dispInfoArray[displayId].windowInfo);
    
    /* Set source and destination rectangles */
    if (currWindow->pixelFormat == MW_SDL_PIXEL_FORMAT_RGB) {

        currWindow->texture = SDL_CreateTexture(dispInfoArray[displayId].renderer,
                SDL_PIXELFORMAT_RGB888,
                SDL_TEXTUREACCESS_STATIC,//SDL_TEXTUREACCESS_STREAMING,
                currWindow->width,
                currWindow->height);
        
        if (currWindow->texture == NULL) {
            fprintf(stderr, "Unable to create texture from surface: %s\n", SDL_GetError());
            return -1;
        }
        
    } else {
        currWindow->texture = SDL_CreateTexture(dispInfoArray[displayId].renderer,
                SDL_PIXELFORMAT_YV12,
                SDL_TEXTUREACCESS_STREAMING,
                currWindow->width,
                currWindow->height);
        if (currWindow->texture == NULL) {
            fprintf(stderr, "Unable to create texture for YCrCb %s\n", SDL_GetError());
            return -1;
        }
    }
    
    return 0;
}

/* Free SDL surface allocated for displaying video */
static void MW_windowShutdown(int displayId)
{
    WindowInfo_t *currWindow = &(dispInfoArray[displayId].windowInfo);
    
    if (SDL_WasInit(SDL_INIT_VIDEO)) {
        if (currWindow->pixelFormat == MW_SDL_PIXEL_FORMAT_RGB) {
            //SDL_FreeSurface(dispInfoArray[displayId].windowInfo[0].image);
            //dispInfoArray[displayId].windowInfo[0].image = NULL;
        }
        else {
//             SDL_FreeYUVOverlay(dispInfo.windowInfo[window].ovl);
// 			dispInfo.windowInfo[window].ovl = NULL;
        }
    }
}

/* Destroy the SDL screen */
static void MW_globalVideoShutdown(void)
{
    if (SDL_WasInit(SDL_INIT_VIDEO)) {
        SDL_QuitSubSystem(SDL_INIT_VIDEO);
    }
}

/* Callback function for MEX exit events */
void MW_SDLCleanup(void)
{
//TODO
//     MW_windowShutdown(0);
// 	   MW_globalVideoShutdown();
//     dispInfo.enabled = 0;
}

/* Polls for SDL events. Closes the SDL screen if QUIT event is
 * detected
 */
static void MW_pollSDLEvent(int displayId)
{
    if (dispInfoArray[displayId].enabled) {
        while (SDL_PollEvent(&(dispInfoArray[displayId].event))) {
            if (dispInfoArray[displayId].event.type == SDL_QUIT) {
                MW_SDLCleanup(); /* Modifies dispInfo.enabled */
            }
        }
    }
}

/* Draw a YUYV overlay onto the screen */
static void MW_drawYUV(int displayId, const Uint8 *yPtr, const Uint8 *uPtr, const Uint8 *vPtr)
{
    WindowInfo_t *currWindow = &(dispInfoArray[displayId].windowInfo);
    
    if (currWindow->pixelOrder == MW_SDL_PIXEL_ORDER_INTERLEAVED) {
// 		Uint8 *yuyvPtr;
// 		int i, lineSize = 2 * (currWindow->ovl->w); /* 1Y + 0.5Cb + 0.5Cr */
//
// 		/* There is no distinction between row/column major in interleaved formats */
// 		yuyvPtr = currWindow->ovl->pixels[0];
// 		if ((currWindow->ovl->pitches[0] - lineSize) != 0) {
// 			/* Copy one line at a time */
// 			for (i = 0; i < currWindow->ovl->h; i++) {
// 				memcpy(yuyvPtr, yPtr, lineSize);
// 				yuyvPtr += currWindow->ovl->pitches[0];
// 				yPtr    += lineSize;
// 			}
// 		}
// 		else {
// 			/* Copy entire image frame */
// 			memcpy(yuyvPtr, yPtr, lineSize * (currWindow->ovl->h));
// 		}
        printf("TODO: Y CrCb MW_SDL_PIXEL_ORDER_INTERLEAVED \n");
    }
    else {
        
        SDL_UpdateYUVTexture(currWindow->texture,
                NULL,
                yPtr,
                currWindow->width,
                uPtr,
                currWindow->width/2,
                vPtr,
                currWindow->width/2);
        
        
    }    
    
    SDL_RenderClear(dispInfoArray[displayId].renderer);
    SDL_RenderCopy(dispInfoArray[displayId].renderer, currWindow->texture, NULL, NULL);
    SDL_RenderPresent(dispInfoArray[displayId].renderer);
}

/* Draws an RGB image to SDL screen */
static void MW_drawRGB(int displayId, const Uint8 *rPtr, const Uint8 *gPtr, const Uint8 *bPtr)
{
    WindowInfo_t *currWindow = &(dispInfoArray[displayId].windowInfo);
    Uint32 *imgPtr;
    Uint8 Rshift, Gshift, Bshift;
    SDL_Surface *image;
    int i;
    
    /* Draw according to pixel format */
    if (currWindow->pixelOrder == MW_SDL_PIXEL_ORDER_INTERLEAVED) {
        printf("TODO: MW_SDL_PIXEL_ORDER_INTERLEAVED \n");
    }
    else {
        imgPtr = (Uint32 *)(dispInfoArray[displayId].myPixels);
        Uint32 NumLoops = currWindow->width * currWindow->height;
        if (currWindow->rowMajor) {
            for (i = 0; i < (currWindow->width * currWindow->height); i++)
            {
                *(imgPtr + i) = (*(rPtr + i) << (16)) | (*(gPtr + i) << (8)) | (*(bPtr + i) << (0));
            }
        }
        else { /* Column major */
            int j;
            Uint32 *imgPtrStart = dispInfoArray[displayId].myPixels;
            
            for (i = 0; i < currWindow->width; i++) {
                for (j = 0; j < currWindow->height; j++) {
                    *imgPtr = (*rPtr++ << (16)) |
                            (*gPtr++ << (8)) |
                            (*bPtr++ << (0));
                    imgPtr += currWindow->width;
                }
                imgPtr = ((Uint32 *)(imgPtrStart)) + i;
            }
            
        }
    }
    
    /* Draw onto the screen */
    SDL_UpdateTexture(currWindow->texture, NULL, dispInfoArray[displayId].myPixels, currWindow->width * 4);
    SDL_RenderClear(dispInfoArray[displayId].renderer);
    SDL_RenderCopy(dispInfoArray[displayId].renderer, currWindow->texture, NULL, NULL);
    SDL_RenderPresent(dispInfoArray[displayId].renderer);
}

/* Draws an image frame to SDL display screen */
void MW_drawFrame(int displayId, const Uint8 *pln0, const Uint8 *pln1, const Uint8 *pln2)
{
    WindowInfo_t *currWindow = &(dispInfoArray[displayId].windowInfo);
    
    if (currWindow->pixelFormat == MW_SDL_PIXEL_FORMAT_RGB) {
        MW_drawRGB(displayId, pln0, pln1, pln2);
    }
    else {
        MW_drawYUV(displayId, pln0, pln1, pln2);
    }
}


/* SIMULINK interface functions */
/* Simulink interface for START function */
int MW_SDL_videoDisplayInit
        (
        int pixelFormat,
        int pixelOrder,
        int rowMajor,
        int width,
        int height,
        char* windowTitle
        )
{
    /* Initialize to enabled */
    int displayId = displayInfoArrayIndex++;
    dispInfoArray[displayId].enabled = 1;
    dispInfoArray[displayId].isVideoModeSet = 0;
    
    /* Store video window parameters */
    MW_setWindowParams(0, pixelFormat, pixelOrder,
            rowMajor, width, height,windowTitle,displayId);
    if (MW_globalVideoInit() < 0) {
        dispInfoArray[displayId].enabled = 0;
        perror("Error in global video init \n");
        return -1;
    }
#ifdef MATLAB_MEX_FILE
    /* Register cleanup-function */
    mexAtExit(MW_SDLCleanup);
#endif
    return displayId;
}

/* Simulink interface for OUTPUT function */
void MW_SDL_videoDisplayOutput(const Uint8 *pln0, const Uint8 *pln1, const Uint8 *pln2, const int displayId)
{
    /* SDL_pollEvent can only be called from the thread that sets the video
     * mode. Hence we do the video mode initialization here. */
    if (dispInfoArray[displayId].isVideoModeSet == 0) {
        dispInfoArray[displayId].isVideoModeSet = 1;
        if ((MW_screenInit(displayId) < 0) || (MW_windowInit(displayId) < 0)) {
            MW_globalVideoShutdown();
            dispInfoArray[displayId].enabled = 0;
        }
        else {
            dispInfoArray[displayId].enabled = 1;
            
            /* Process first few WM events */
            MW_pollSDLEvent(displayId);
        }
    }
    
    /* If window is closed, do not update */
    if (dispInfoArray[displayId].enabled) {
        MW_drawFrame(displayId, pln0, pln1, pln2);
        MW_pollSDLEvent(displayId);
    }
}

void MW_SDL_videoDisplayTitle(char* title, int32_T displayId)
{
    SDL_Window *window = dispInfoArray[displayId].sdlWindow;
    SDL_SetWindowTitle(window, title);
}

/* Simulink interface for TERMINATE function */
void MW_SDL_videoDisplayTerminate(int width, int height, int displayId)
{
    dispInfoArray[displayId].isVideoModeSet = 0;
    if (dispInfoArray[displayId].enabled) {
#ifdef MATLAB_MEX_FILE
        /* In simulation, stop event does not close the screen.
         * We just destroy the surface created to draw images. */
        MW_windowShutdown(displayId);
#else
        /* Destroy the SDL surfaces and the screen. */
        /* Note that this call modifies dispInfo.screen */
        MW_SDLCleanup();
#endif
    }
}
#endif
/* EOF */