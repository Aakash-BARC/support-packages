//* Copyright 2021 The MathWorks, Inc. */
#ifndef _MW_DASHBOARD_NANOMSGCLIENT_H_
#define _MW_DASHBOARD_NANOMSGCLIENT_H_
#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )

#else
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <nanomsg/nn.h>
#include <nanomsg/pubsub.h>
#endif
#include "rtwtypes.h"
#ifdef __cplusplus
extern "C"
{
#endif

#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )

#define MW_dashboardnanomsgClientPubInit() 0
#define MW_dashboardnanomsgClientSubInit() 0
#define MW_dashboardnanomsgClientSend(sock,msg) 0
#define MW_dashboardnanomsgClientRecv(sock,labelwithid,wid,data) 0
#define MW_dashboardnanomsgClientShutdown(sock) 0

#else

int MW_dashboardnanomsgClientPubInit();
int MW_dashboardnanomsgClientSubInit();
void MW_dashboardnanomsgClientSend(int sock,char *msg);
void MW_dashboardnanomsgClientRecv(int sock, char *blocklabelWithID, char** blockIDStr, double *data);
void MW_dashboardnanomsgClientShutdown(int sock);

#endif

#ifdef __cplusplus
}
#endif
#endif 