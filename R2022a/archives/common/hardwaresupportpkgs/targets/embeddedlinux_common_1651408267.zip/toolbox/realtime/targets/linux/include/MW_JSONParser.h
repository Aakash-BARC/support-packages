/* Copyright 2019-2021 The MathWorks, Inc. */
#ifndef _MW_JSONPARSER_H_
#define _MW_JSONPARSER_H_
#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )

#else
#include<stdio.h>
#include <json-c/json.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#endif
#include "rtwtypes.h"
#ifdef __cplusplus
extern "C"
{
#endif

#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
#define MW_getSignalStr(filename, valuestr) 0
#define MW_getDashboardSourceData(filename, valuestr, labelstr) 0
#define MW_getPortData(dataStr, portIndex, data, size) 0
#else
uint8_t MW_getSignalStr(char* jsonstr, char** valStr);
double MW_getDashboardSourceData(char* jsonstr, char** valStr, char** labelStr);
uint8_t MW_getPortData(char* dataStr, uint8_t portIndex, double* data, uint16_t size);


#endif 

#ifdef __cplusplus
}
#endif
#endif 