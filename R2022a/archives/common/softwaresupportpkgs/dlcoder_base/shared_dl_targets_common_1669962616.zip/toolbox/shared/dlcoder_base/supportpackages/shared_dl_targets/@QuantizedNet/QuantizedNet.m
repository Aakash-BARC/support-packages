classdef QuantizedNet < handle
    %% QuantizedNet class holds on to SeriesNet and quantization related artifacts associated with the network 
    
    % Copyright 2019 The MathWorks, Inc.
    
    properties(SetAccess=private)
        Net; % SeriesNet or DAGNetwork
        
        CalibrationStatistics; % table object containing calibration data 
        
        SkipLayers; % layer names to ignore quantization
    end
    methods(Access=?dlquantizer)
        function obj = QuantizedNet(net, calibrationData, skipLayers)
            % Constructor for QuantizedNetwork 
            
            obj.Net = net; 
            obj.CalibrationStatistics = calibrationData; 
            obj.SkipLayers = skipLayers;
        end
    end
end
