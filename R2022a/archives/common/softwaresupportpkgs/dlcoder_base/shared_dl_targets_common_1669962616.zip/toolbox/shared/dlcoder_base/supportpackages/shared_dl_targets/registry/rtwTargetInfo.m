function rtwTargetInfo(tr)
%RTWTARGETINFO Register toolchain
 
% Copyright 2013-2019 The MathWorks, Inc.

% Register GNU Tools for ARM Embedded Processors toolchain
tr.registerTargetInfo(@loc_createToolchain);
end

%--------------------------------------------------------------------------
function config = loc_createToolchain
config = coder.make.ToolchainInfoRegistry; % initialize
spkgroot =  dlcoder_base.internal.getSpkgRoot('arm_neon');
if isempty(spkgroot)
    spkgroot =  dlcoder_base.internal.getSpkgRoot('arm_mali');
end
assert(~isempty(spkgroot));

    if strcmpi(computer('arch'), 'win64')
        config(1)                       = coder.make.ToolchainInfoRegistry;
        config(end).Name                = 'GNU Tools for ARM_COMPUTE ';
        config(end).FileName            = fullfile(spkgroot,'shared_dl_targets','registry', 'gnu_gcc_gmake_win64.mat');
        config(end).TargetHWDeviceType	= {'*'};
        config(end).Platform            = {'win64'};
    elseif strcmpi(computer('arch'), 'win32') 
        config(1)                       = coder.make.ToolchainInfoRegistry;
        config(end).Name                = 'GNU Tools for ARM_COMPUTE ';
        config(end).FileName            = fullfile(spkgroot,'shared_dl_targets','registry', 'gnu_gcc_gmake_win32.mat');
        config(end).TargetHWDeviceType	= {'*'};
        config(end).Platform            = {'win32'};
        
    elseif strcmpi(computer('arch'), 'glnxa64')
        config(1)                       = coder.make.ToolchainInfoRegistry;
        config(end).Name                = 'GNU Tools for ARM_COMPUTE ';
        config(end).FileName            = fullfile(spkgroot,'shared_dl_targets','registry', 'gnu_gcc_gmake_glnxa64.mat');
        config(end).TargetHWDeviceType	= {'*'};
        config(end).Platform            = {'glnxa64'};
    end
end

% [EOF]
