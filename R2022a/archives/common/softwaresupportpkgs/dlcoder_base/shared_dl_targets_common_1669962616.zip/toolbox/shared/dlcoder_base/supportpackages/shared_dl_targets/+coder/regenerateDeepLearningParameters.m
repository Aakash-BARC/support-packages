function networkFileNames = regenerateDeepLearningParameters(net, paramsInfoDirectory, nameValueArgs)
%   CODER.REGENERATEDEEPLEARNINGPARAMETERS regenerates files storing network learnables and states parameters
%
%   NETWORKFILENAMES = CODER.REGENERATEDEEPLEARNINGPARAMETERS(NET, PARAMSINFODIRECTORY) returns a cell-array of 
%   the filenames containing network learnables and states parameters after regenerating these files based on the 
%   learnables and states of the input network NET. NET is a valid dlnetwork, DAGNetwork, or SeriesNetwork object. 
%   PARAMSINFODIRECTORY is the path to the directory containing the network parameter information file.
%
%   NETWORKFILENAMES = CODER.REGENERATEDEEPLEARNINGPARAMETERS(__, Name, Value) specifies additional parameters 
%   using one or more name-value pair arguments.
%
%   Possible name-value pairs include:
%
%   'NetworkName'               Specify the name of the C++ class for the network in the generated code. 
%   'OverrideParameterFiles'    Boolean indicating whether parameter files in code generation
%                               directory should be overridden if PARAMSINFODIRECTORY is different 
%                               from code generation directory for MEX code generation. 
%                               This NVP is ignored for standalone code generation.
%
%   See also CODER.LOADDEEPLEARNINGNETWORK

%   Copyright 2021-2022 The MathWorks, Inc.

arguments
    net (1, 1) {mustBeValidNetwork(net)}
    paramsInfoDirectory {mustBeTextScalar, mustBeFolder}
    nameValueArgs.NetworkName {mustBeTextScalar} = ''
    nameValueArgs.OverrideParameterFiles (1, 1) {mustBeA(nameValueArgs.OverrideParameterFiles, 'logical')} = false
end

try
    networkFileNames = dltargets.internal.sharedNetwork.regenerateDeepLearningParameters(net, ...
        paramsInfoDirectory, nameValueArgs.NetworkName, nameValueArgs.OverrideParameterFiles);
catch err
    throwAsCaller(err);
end

end

function mustBeValidNetwork(net)
    
if ~(isa(net, 'dlnetwork') || isa(net, 'DAGNetwork') || isa(net, 'SeriesNetwork'))
    eid = 'dlcoder_spkg:postCodegenUpdate:InvalidNetworkInput';
    msg = getString(message(eid));
    throwAsCaller(MException(eid,msg))
end

end
